package com.zyz4.gkme.input

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.MotionEvent
import com.zyz4.gkme.haptic.HapticSource
import com.zyz4.gkme.haptic.PhoneHdHaptics
import com.zyz4.gkme.input.usb.AbstractController
import com.zyz4.gkme.input.usb.DualSenseController
import com.zyz4.gkme.input.usb.DualSenseOutputReport
import com.zyz4.gkme.input.usb.GkmeBridge
import com.zyz4.gkme.input.usb.UsbDriverListener
import com.zyz4.gkme.input.usb.UsbDriverService
import com.zyz4.gkme.model.GamepadState
import com.zyz4.gkme.model.PhysicalInputs
import com.zyz4.gkme.model.TouchPoint
import com.zyz4.gkme.model.VibrationDevice
import com.zyz4.gkme.model.VibrationDeviceType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Physical-controller backend built on the ported "Axixi2233的USB驱动".
 *
 * It binds to [UsbDriverService], decodes raw USB HID reports for DualSense /
 * DualShock 4 / Xbox / Switch Pro controllers, and exposes the same state surface
 * as the SDL3 backend. It additionally supports voice-coil PCM and controller
 * audio output through the controller's USB audio endpoint.
 */
class UsbPhysicalControllerBackend(private val context: Context) : PhysicalControllerBackend, UsbDriverListener {

    private val _isConnected = MutableStateFlow(false)
    override val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _controllerState = MutableStateFlow(PhysicalControllerState())
    override val controllerState: StateFlow<PhysicalControllerState> = _controllerState.asStateFlow()

    private val _connectedControllers = MutableStateFlow<List<ControllerInfo>>(emptyList())
    override val connectedControllers: StateFlow<List<ControllerInfo>> = _connectedControllers.asStateFlow()

    private val _gyroData = MutableStateFlow(FloatArray(3))
    override val gyroData: StateFlow<FloatArray> = _gyroData.asStateFlow()

    private val _accelData = MutableStateFlow(FloatArray(3))
    override val accelData: StateFlow<FloatArray> = _accelData.asStateFlow()

    @Volatile
    override var controllerGyroEnabled: Boolean = false

    @Volatile
    override var controllerHasGyro: Boolean = false

    @Volatile
    override var inputControllerIndex: Int = 0
        set(value) {
            if (field == value) return
            field = value
            resetInputState()
        }

    @Volatile
    override var gyroControllerIndex: Int = 0
        set(value) {
            if (field == value) return
            field = value
            _gyroData.value = floatArrayOf(0f, 0f, 0f)
            _accelData.value = floatArrayOf(0f, 0f, 0f)
        }

    @Volatile
    override var gameVibrationDevice: VibrationDevice = VibrationDevice.PHONE
        set(value) {
            val previous = field
            field = value
            if (previous != value) stopVibrationForDevice(previous)
        }

    @Volatile
    override var swapPhoneMotors: Boolean = false

    @Volatile
    override var swapControllerMotors: Boolean = false

    override var onPointerCaptureNeeded: ((Boolean) -> Unit)? = null
    override var isPointerCaptureActive: Boolean = false

    // ── USB service plumbing ───────────────────────────────

    private var binder: UsbDriverService.UsbDriverBinder? = null
    private var bound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val driverBinder = service as? UsbDriverService.UsbDriverBinder ?: return
            binder = driverBinder
            driverBinder.setListener(this@UsbPhysicalControllerBackend)
            driverBinder.start()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            binder = null
        }
    }

    // ── Controller bookkeeping ─────────────────────────────

    private val lock = Any()
    private val controllers = LinkedHashMap<Int, AbstractController>()
    private var controllerList: List<AbstractController> = emptyList()

    // Touchpad state of the active controller (normalized 0..1). Two stable slots
    // preserve a finger's position when the other finger lifts; pointerSlots maps
    // the driver's contact id onto its assigned slot.
    private val touchSlots = arrayOfNulls<TouchPoint>(2)
    private val pointerSlots = HashMap<Int, Int>()
    private var touchX = 0f
    private var touchY = 0f

    // Motion state of the active controller.
    private var gyro = FloatArray(3)
    private var accel = FloatArray(3)

    // ── Lifecycle ──────────────────────────────────────────

    override fun start() {
        if (bound) return
        val intent = Intent(context, UsbDriverService::class.java)
        bound = try {
            context.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        } catch (_: Exception) {
            false
        }
    }

    override fun stop() {
        binder?.setListener(null)
        binder?.stop()
        binder = null
        if (bound) {
            try {
                context.unbindService(serviceConnection)
            } catch (_: Exception) {
            }
            bound = false
        }
        synchronized(lock) {
            controllers.clear()
            controllerList = emptyList()
        }
        _connectedControllers.value = emptyList()
        _isConnected.value = false
        controllerHasGyro = false
        resetInputState()
        _gyroData.value = floatArrayOf(0f, 0f, 0f)
        _accelData.value = floatArrayOf(0f, 0f, 0f)
    }

    override fun onControllerGyroSettingChanged(enabled: Boolean) {
        controllerGyroEnabled = enabled
    }

    override fun ensureGyroRegistered() {
        // USB controllers are polled directly; nothing to register.
    }

    override fun handleKeyEvent(event: KeyEvent): Boolean = false

    override fun handleMotionEvent(event: MotionEvent): Boolean = false

    override fun setCapturedTouchpadState(
        normalizedX: Float, normalizedY: Float,
        touches: List<TouchPoint>, touchpadTouch: Boolean, touchpadClick: Boolean,
    ) {
        // USB controllers report their own touchpad; Android-captured events are ignored.
    }

    // ── UsbDriverListener ──────────────────────────────────

    override fun deviceAdded(controller: AbstractController) {
        synchronized(lock) {
            controllers[controller.getControllerId()] = controller
            rebuildControllerListLocked()
        }
        publishControllers()
    }

    override fun deviceRemoved(controller: AbstractController) {
        synchronized(lock) {
            controllers.remove(controller.getControllerId())
            rebuildControllerListLocked()
        }
        publishControllers()
    }

    override fun reportControllerState(
        controllerId: Int, buttonFlags: Int,
        leftStickX: Float, leftStickY: Float,
        rightStickX: Float, rightStickY: Float,
        leftTrigger: Float, rightTrigger: Float,
    ) {
        val active = activeInputController() ?: return
        if (active.getControllerId() != controllerId) return
        updateInputState(buttonFlags, leftStickX, leftStickY, rightStickX, rightStickY, leftTrigger, rightTrigger)
    }

    override fun reportControllerMotion(controllerId: Int, motionType: Byte, motionX: Float, motionY: Float, motionZ: Float) {
        val active = activeInputController() ?: return
        if (active.getControllerId() != controllerId) return
        when (motionType) {
            // USB 驱动返回的 gyro 单位是 deg/s，统一转为 rad/s 后输出
            GkmeBridge.LI_MOTION_TYPE_GYRO -> {
                val degToRad = Math.PI / 180.0
                gyro = floatArrayOf(
                    motionX * degToRad.toFloat(),
                    motionY * degToRad.toFloat(),
                    motionZ * degToRad.toFloat()
                )
            }
            GkmeBridge.LI_MOTION_TYPE_ACCEL -> accel = floatArrayOf(motionX, motionY, motionZ)
        }
        if (controllerGyroEnabled) {
            _gyroData.value = gyro.copyOf()
            _accelData.value = accel.copyOf()
        } else {
            _gyroData.value = floatArrayOf(0f, 0f, 0f)
            _accelData.value = floatArrayOf(0f, 0f, 0f)
        }
    }

    override fun reportControllerTouchpadEvent(
        controllerId: Int, eventType: Byte, pointerId: Int,
        x: Float, y: Float, pressure: Float,
    ) {
        val active = activeInputController() ?: return
        if (active.getControllerId() != controllerId) return
        synchronized(lock) {
            when (eventType) {
                GkmeBridge.LI_TOUCH_EVENT_CANCEL_ALL, GkmeBridge.LI_TOUCH_EVENT_CANCEL -> {
                    touchSlots.fill(null)
                    pointerSlots.clear()
                }
                GkmeBridge.LI_TOUCH_EVENT_UP -> {
                    val slot = pointerSlots.remove(pointerId)
                    if (slot != null) touchSlots[slot] = null
                }
                // 触摸板点击（BUTTON_ONLY）仅通过按钮位派生，不更新坐标也不分配 slot。
                GkmeBridge.LI_TOUCH_EVENT_BUTTON_ONLY -> Unit
                GkmeBridge.LI_TOUCH_EVENT_DOWN, GkmeBridge.LI_TOUCH_EVENT_MOVE,
                GkmeBridge.LI_TOUCH_EVENT_HOVER -> {
                    val nx = x.coerceIn(0f, 1f)
                    val ny = y.coerceIn(0f, 1f)
                    touchX = nx
                    touchY = ny
                    var slot = pointerSlots[pointerId]
                    if (slot == null) {
                        slot = touchSlots.indexOfFirst { it == null }
                        if (slot >= 0) pointerSlots[pointerId] = slot
                    }
                    if (slot >= 0) {
                        touchSlots[slot] = TouchPoint(
                            id = slot,
                            x = (nx * 1919f).toInt().coerceIn(0, 1919),
                            y = (ny * 942f).toInt().coerceIn(0, 942),
                            active = true,
                        )
                    }
                }
            }
            val current = _controllerState.value
            _controllerState.value = current.copy(
                touchpadX = touchX,
                touchpadY = touchY,
                touchpadTouch = touchSlots.any { it != null },
                touches = touchSlots.mapIndexed { i, tp -> tp ?: TouchPoint(id = i, active = false) },
            )
        }
    }

    // ── State assembly ─────────────────────────────────────

    private fun updateInputState(
        flags: Int, lsx: Float, lsy: Float, rsx: Float, rsy: Float, lt: Float, rt: Float,
    ) {
        val buttons = mapButtons(flags, lt, rt)
        val dpad = (if ((flags and USB_UP) != 0) GamepadState.DPAD_UP else 0) or
                (if ((flags and USB_DOWN) != 0) GamepadState.DPAD_DOWN else 0) or
                (if ((flags and USB_LEFT) != 0) GamepadState.DPAD_LEFT else 0) or
                (if ((flags and USB_RIGHT) != 0) GamepadState.DPAD_RIGHT else 0)

        // Digital (non-analog) triggers are thresholded to 0/255, analog ones stay continuous.
        val analogTriggers = activeInputController()?.let {
            (it.getCapabilities().toInt() and GkmeBridge.LI_CCAP_ANALOG_TRIGGERS.toInt()) != 0
        } ?: true
        val left = if (analogTriggers) (lt * 255f).toInt().coerceIn(0, 255) else (if (lt > 0.5f) 255 else 0)
        val right = if (analogTriggers) (rt * 255f).toInt().coerceIn(0, 255) else (if (rt > 0.5f) 255 else 0)

        _controllerState.value = PhysicalControllerState(
            buttons = buttons,
            leftStickX = (lsx * 32767f).toInt().coerceIn(-32768, 32767).toShort(),
            leftStickY = (lsy * 32767f).toInt().coerceIn(-32768, 32767).toShort(),
            rightStickX = (rsx * 32767f).toInt().coerceIn(-32768, 32767).toShort(),
            rightStickY = (rsy * 32767f).toInt().coerceIn(-32768, 32767).toShort(),
            leftTrigger = left,
            rightTrigger = right,
            dpad = dpad,
            touchpadX = touchX,
            touchpadY = touchY,
            touchpadTouch = touchSlots.any { it != null },
            touchpadClick = (buttons and GamepadState.TOUCHPAD_CLICK.toUInt()) != 0u,
            touches = touchSlots.mapIndexed { i, tp -> tp ?: TouchPoint(id = i, active = false) },
        )
    }

    private fun mapButtons(flags: Int, lt: Float, rt: Float): UInt {
        var b = 0
        if (flags and USB_A != 0) b = b or GamepadState.A
        if (flags and USB_B != 0) b = b or GamepadState.B
        if (flags and USB_X != 0) b = b or GamepadState.X
        if (flags and USB_Y != 0) b = b or GamepadState.Y
        if (flags and USB_LB != 0) b = b or GamepadState.LB
        if (flags and USB_RB != 0) b = b or GamepadState.RB
        if (lt > TRIGGER_DIGITAL_THRESHOLD) b = b or GamepadState.LT
        if (rt > TRIGGER_DIGITAL_THRESHOLD) b = b or GamepadState.RT
        if (flags and USB_BACK != 0) b = b or GamepadState.SELECT
        if (flags and USB_PLAY != 0) b = b or GamepadState.START
        if (flags and USB_LS != 0) b = b or GamepadState.L3
        if (flags and USB_RS != 0) b = b or GamepadState.R3
        if (flags and USB_UP != 0) b = b or GamepadState.DPAD_BIT_UP
        if (flags and USB_DOWN != 0) b = b or GamepadState.DPAD_BIT_DOWN
        if (flags and USB_LEFT != 0) b = b or GamepadState.DPAD_BIT_LEFT
        if (flags and USB_RIGHT != 0) b = b or GamepadState.DPAD_BIT_RIGHT
        if (flags and USB_SPECIAL != 0) b = b or GamepadState.HOME
        if (flags and USB_TOUCHPAD != 0) b = b or GamepadState.TOUCHPAD_CLICK
        if (flags and USB_MISC != 0) b = b or GamepadState.MIC_MUTE
        // GameSir G7 "M" button also acts as microphone mute.
        if (flags and USB_M_BUTTON != 0) b = b or GamepadState.MIC_MUTE
        // Back paddles: same physical-only bits the SDL3 backend emits (PhysicalInputs.PADDLE_*),
        // so the shared remapping path treats USB and SDL controllers identically.
        if (flags and USB_PADDLE1 != 0) b = b or PhysicalInputs.PADDLE_R1
        if (flags and USB_PADDLE2 != 0) b = b or PhysicalInputs.PADDLE_R2
        if (flags and USB_PADDLE3 != 0) b = b or PhysicalInputs.PADDLE_L1
        if (flags and USB_PADDLE4 != 0) b = b or PhysicalInputs.PADDLE_L2
        return b.toUInt()
    }

    private fun resetInputState() {
        synchronized(lock) {
            touchSlots.fill(null)
            pointerSlots.clear()
            touchX = 0f
            touchY = 0f
        }
        gyro = FloatArray(3)
        accel = FloatArray(3)
        _controllerState.value = PhysicalControllerState()
        _gyroData.value = floatArrayOf(0f, 0f, 0f)
        _accelData.value = floatArrayOf(0f, 0f, 0f)
    }

    private fun rebuildControllerListLocked() {
        controllerList = controllers.values.toList()
    }

    private fun publishControllers() {
        val list: List<AbstractController>
        synchronized(lock) { list = controllerList }
        val infos = list.map { c ->
            val capabilities = c.getCapabilities().toInt()
            val supportedButtons = if ((capabilities and GkmeBridge.LI_CCAP_TOUCHPAD.toInt()) != 0) {
                PhysicalInputs.STANDARD_BUTTON_MASK
            } else {
                PhysicalInputs.STANDARD_BUTTON_MASK and GamepadState.TOUCHPAD_CLICK.inv()
            }
            val allSupportedButtons = if (c.hasPaddleSupport()) {
                supportedButtons or PhysicalInputs.PADDLE_MASK
            } else {
                supportedButtons
            }
            ControllerInfo(
                id = c.getControllerId(),
                name = displayName(c),
                motorCount = if ((capabilities and GkmeBridge.LI_CCAP_RUMBLE.toInt()) != 0) 2 else 0,
                hasTriggerRumble = (capabilities and GkmeBridge.LI_CCAP_TRIGGER_RUMBLE.toInt()) != 0,
                hasAdaptiveTrigger = c.hasAdaptiveTriggerSupport(),
                hasGyro = (capabilities and GkmeBridge.LI_CCAP_GYRO.toInt()) != 0,
                hasAnalogTrigger = (capabilities and GkmeBridge.LI_CCAP_ANALOG_TRIGGERS.toInt()) != 0,
                hasTouchpad = (capabilities and GkmeBridge.LI_CCAP_TOUCHPAD.toInt()) != 0,
                supportedButtons = allSupportedButtons,
            )
        }
        _connectedControllers.value = infos
        _isConnected.value = infos.isNotEmpty()
        if (infos.isEmpty()) {
            controllerHasGyro = false
            resetInputState()
        } else {
            val active = activeInputController()
            controllerHasGyro = active != null &&
                (active.getCapabilities().toInt() and GkmeBridge.LI_CCAP_GYRO.toInt()) != 0
        }
    }

    private fun activeInputController(): AbstractController? {
        if (inputControllerIndex < 0) return null
        synchronized(lock) {
            return controllerList.getOrNull(inputControllerIndex)
        }
    }

    // ── LED / vibration ────────────────────────────────────

    override fun setLedColor(color: Int, playerLed: Int) {
        when (gameVibrationDevice.type) {
            VibrationDeviceType.CONTROLLER -> {
                _lastLedColor = color
                _lastPlayerLed = playerLed
                synchronized(this) { sendCombinedReport() }
            }
            else -> {
                synchronized(this) {
                    val list: List<AbstractController>
                    synchronized(lock) { list = controllerList }
                    if (list.isEmpty()) return
                    val r = ((color shr 16) and 0xFF).toByte()
                    val g = ((color shr 8) and 0xFF).toByte()
                    val b = (color and 0xFF).toByte()
                    val playerPattern = if (playerLed != 0) {
                        PLAYER_LED_PATTERNS[(Integer.bitCount(playerLed) - 1).coerceIn(0, 4)]
                    } else {
                        0
                    }
                    for (c in list) {
                        c.setControllerLED(r, g, b)
                        c.setPlayerIndicator(playerPattern.toByte())
                    }
                }
            }
        }
    }

    @Volatile
    private var _voiceCoilLeftAmp = 0

    @Volatile
    private var _voiceCoilRightAmp = 0

    @Volatile
    private var _lastVoiceCoilActivityNs = 0L

    // Controller whose grip is currently driven by the adaptive-trigger voice-coil PCM
    // (-1 = none). While set, its combined reports must omit the compatible-vibration motor
    // flags, otherwise the DualSense leaves audio-haptics mode and the tone cuts off.
    @Volatile
    private var adaptiveVoiceCoilIndex = -1

    override fun setVoiceCoilMotorOutput(leftAmp: Int, rightAmp: Int) {
        _voiceCoilLeftAmp = leftAmp
        _voiceCoilRightAmp = rightAmp
        _lastVoiceCoilActivityNs = System.nanoTime()
    }

    override fun setAdaptiveVoiceCoilActive(controllerIndex: Int, active: Boolean) {
        adaptiveVoiceCoilIndex = if (active) controllerIndex else -1
    }

    // Adaptive-trigger / voice-coil motor contribution, kept separate from the game
    // rumble so the two never overwrite each other on the same pad. Values are
    // already output-oriented (the caller applied its own swap). Max-combined with
    // the game rumble when driving the actuators.
    private val auxMotorLock = Any()
    private val auxMotors = HashMap<Int, IntArray>()
    private val ZERO_MOTOR = intArrayOf(0, 0)

    private fun auxMotorFor(controllerIndex: Int): IntArray =
        synchronized(auxMotorLock) { auxMotors[controllerIndex] } ?: ZERO_MOTOR

    private fun setAuxMotor(controllerIndex: Int, left: Int, right: Int) {
        synchronized(auxMotorLock) {
            if (left == 0 && right == 0) auxMotors.remove(controllerIndex)
            else auxMotors[controllerIndex] = intArrayOf(left, right)
        }
    }

    override fun setControllerMotorsVibration(controllerIndex: Int, leftIntensity: Int, rightIntensity: Int) {
        val left = leftIntensity.coerceIn(0, 255)
        val right = rightIntensity.coerceIn(0, 255)
        setAuxMotor(controllerIndex, left, right)

        val isGameTarget = gameVibrationDevice.type == VibrationDeviceType.CONTROLLER &&
            gameVibrationDevice.controllerIndex == controllerIndex

        synchronized(this) {
            val controller = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return

            // A DualSense carrying both rumble and trigger/LED must go through the single
            // combined report (which max-combines the aux contribution) so the two never
            // clobber each other.
            if (isGameTarget && controller.hasAdvancedAudioHapticsSupport()) {
                sendCombinedReport()
                return
            }

            // Otherwise fold the (possibly zero) game rumble of this pad into the write
            // so the two sources are felt together and a later game-rumble update cannot
            // erase this contribution.
            val baseLeft = if (isGameTarget) _lastRumbleLow else 0
            val baseRight = if (isGameTarget) _lastRumbleHigh else 0
            val outLeft = maxOf(left, baseLeft)
            val outRight = maxOf(right, baseRight)

            if (controller.hasAdvancedAudioHapticsSupport() && controller.isAdvancedAudioHapticsActive()) {
                val timeSinceLastActivity = System.nanoTime() - _lastVoiceCoilActivityNs
                val isStale = _lastVoiceCoilActivityNs == 0L || timeSinceLastActivity > VOICE_COIL_SILENCE_TIMEOUT_NS
                val vcLeft = _voiceCoilLeftAmp
                val vcRight = _voiceCoilRightAmp
                if (!isStale && (vcLeft > 1 || vcRight > 1)) return
            }

            if (outLeft == 0 && outRight == 0) {
                controller.rumble(0, 0)
            } else {
                controller.rumble(
                    (outLeft * 257).toShort(),
                    (outRight * 257).toShort(),
                )
            }
        }
    }

    override fun rumble(lowFreqMotor: Int, highFreqMotor: Int) {
        val low = lowFreqMotor.coerceIn(0, 255)
        val high = highFreqMotor.coerceIn(0, 255)
        
        if (gameVibrationDevice.type == VibrationDeviceType.CONTROLLER) {
            _lastRumbleLow = low
            _lastRumbleHigh = high
            synchronized(this) { sendCombinedReport() }
        } else if (low != 0 || high != 0) {
            synchronized(this) { doRumble(low, high) }
        } else {
            vibratePhone(0)
        }
    }

    private fun doRumble(lowFreqMotor: Int, highFreqMotor: Int) {
        val low = lowFreqMotor.coerceIn(0, 255)
        val high = highFreqMotor.coerceIn(0, 255)
        when (gameVibrationDevice.type) {
            VibrationDeviceType.PHONE -> vibratePhoneMotors(low, high, swapPhoneMotors)
            VibrationDeviceType.CONTROLLER -> {
                val controller = synchronized(lock) {
                    controllerList.getOrNull(gameVibrationDevice.controllerIndex)
                } ?: return
                // On a DualSense the compatible-vibration HID report and the
                // audio-haptics PCM are mutually exclusive: the HID report
                // (HAPTICS_SELECT) switches the pad out of audio-haptics mode.
                // When voice-coil channels are silent (no audio playing or
                // channels muted) base rumble is allowed to play through the
                // HID report; otherwise the voice-coil path carries the
                // vibration and HID rumble is skipped to avoid conflict.
                // If no PCM activity has been seen for >200ms, the PC has
                // likely stopped sending audio, so fall back to base rumble.
                if (controller.hasAdvancedAudioHapticsSupport() && controller.isAdvancedAudioHapticsActive()) {
                    val timeSinceLastActivity = System.nanoTime() - _lastVoiceCoilActivityNs
                    val isStale = _lastVoiceCoilActivityNs == 0L || timeSinceLastActivity > VOICE_COIL_SILENCE_TIMEOUT_NS
                    val vcLeft = _voiceCoilLeftAmp
                    val vcRight = _voiceCoilRightAmp
                    if (!isStale && (vcLeft > 1 || vcRight > 1)) return
                }
                val motor0 = if (swapControllerMotors) high else low
                val motor1 = if (swapControllerMotors) low else high
                controller.rumble((motor0 * 257).toShort(), (motor1 * 257).toShort())
            }
            VibrationDeviceType.NONE -> {}
        }
    }

    private fun stopVibrationForDevice(device: VibrationDevice) {
        when (device.type) {
            VibrationDeviceType.PHONE -> vibratePhone(0)
            VibrationDeviceType.CONTROLLER -> {
                val controller = synchronized(lock) { controllerList.getOrNull(device.controllerIndex) }
                // A zero HID rumble would knock an audio-haptics pad out of the
                // voice-coil path, so leave it alone.
                if (controller != null && !controller.hasAdvancedAudioHapticsSupport()) {
                    controller.rumble(0, 0)
                }
            }
            VibrationDeviceType.NONE -> {}
        }
    }

    override fun stopAllVibration() {
        val list: List<AbstractController>
        synchronized(lock) { list = controllerList }
        for (controller in list) {
            try { controller.rumble(0, 0) } catch (_: Exception) {}
            try { controller.rumbleTriggers(0, 0) } catch (_: Exception) {}
        }
        synchronized(auxMotorLock) { auxMotors.clear() }
        _lastRumbleLow = 0
        _lastRumbleHigh = 0
        adaptiveVoiceCoilIndex = -1
        vibratePhone(0)
    }

    // ── Controller audio / voice coil ──────────────────────

    override fun controllerSupportsVoiceCoilPcm(controllerIndex: Int): Boolean {
        val controller = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return false
        return controller.hasAdvancedAudioHapticsSupport()
    }

    override fun controllerSupportsAudio(controllerIndex: Int): Boolean =
        controllerSupportsVoiceCoilPcm(controllerIndex)

    override fun submitVoiceCoilFrame(controllerIndex: Int, frame: ByteArray): Boolean {
        _lastVoiceCoilActivityNs = System.nanoTime()
        val controller = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return false
        return controller.submitNativeAudioHapticsFrame(frame)
    }

    override fun submitControllerAudioFrame(controllerIndex: Int, frame: ByteArray): Boolean =
        submitVoiceCoilFrame(controllerIndex, frame)

    override fun controllerSupportsHdRumble(controllerIndex: Int): Boolean {
        val controller = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return false
        return controller.hasHdRumbleSupport()
    }

    override fun setControllerHdRumble(
        controllerIndex: Int,
        leftHighFreq: Float, leftHighAmp: Float, leftLowFreq: Float, leftLowAmp: Float,
        rightHighFreq: Float, rightHighAmp: Float, rightLowFreq: Float, rightLowAmp: Float,
    ) {
        val controller = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return
        controller.setHdRumble(
            leftHighFreq, leftHighAmp, leftLowFreq, leftLowAmp,
            rightHighFreq, rightHighAmp, rightLowFreq, rightLowAmp,
        )
    }

    // ── Compact frame merging: rumble + triggers + LED in one HID report ─

    // Last-known state, always merged into a single 0x02 HID report so that a
    // trigger- or LED-only update keeps the current rumble running instead of
    // interrupting it with a separate bulkTransfer.
    @Volatile private var _lastRumbleLow = 0
    @Volatile private var _lastRumbleHigh = 0
    @Volatile private var _lastTriggerTypeL: Byte = 0
    @Volatile private var _lastTriggerTypeR: Byte = 0
    @Volatile private var _lastTriggerDataL: ByteArray? = null
    @Volatile private var _lastTriggerDataR: ByteArray? = null
    // Trigger flag bits (0x04 right / 0x08 left) still owed to the pad. They are folded
    // into the next combined report and cleared once transmitted, so a report caused by
    // rumble/LED alone does not re-write triggers that have not changed.
    @Volatile private var _pendingTriggerFlags = 0
    @Volatile private var _lastLedColor = 0
    @Volatile private var _lastPlayerLed = 0

    /** Builds and sends a combined rumble + trigger + LED report in one bulkTransfer. */
    private fun sendCombinedReport() {
        val controller = synchronized(lock) {
            controllerList.getOrNull(gameVibrationDevice.controllerIndex)
        } ?: return

        // On a DualSense the compatible-vibration HID report and the audio-haptics
        // PCM are mutually exclusive. While the voice coil is actively carrying the
        // vibration, zero the motors but still forward triggers/LED so adaptive
        // trigger and lightbar updates are not lost.
        val adaptiveVoiceCoilActive = adaptiveVoiceCoilIndex >= 0 &&
            adaptiveVoiceCoilIndex == gameVibrationDevice.controllerIndex
        val voiceCoilActive = adaptiveVoiceCoilActive || (controller.hasAdvancedAudioHapticsSupport() &&
            controller.isAdvancedAudioHapticsActive() &&
            _lastVoiceCoilActivityNs != 0L &&
            System.nanoTime() - _lastVoiceCoilActivityNs <= VOICE_COIL_SILENCE_TIMEOUT_NS &&
            (_voiceCoilLeftAmp > 1 || _voiceCoilRightAmp > 1))

        val aux = auxMotorFor(gameVibrationDevice.controllerIndex)
        val low = _lastRumbleLow
        val high = _lastRumbleHigh
        // The game rumble is swapped by the controller-motor setting; the aux
        // contribution is already output-oriented, so combine after the swap.
        val gameMotor0 = if (swapControllerMotors) high else low
        val gameMotor1 = if (swapControllerMotors) low else high
        val motor0 = if (voiceCoilActive) 0 else maxOf(gameMotor0, aux[0]) * 257
        val motor1 = if (voiceCoilActive) 0 else maxOf(gameMotor1, aux[1]) * 257

        val r = ((_lastLedColor shr 16) and 0xFF).toByte()
        val g = ((_lastLedColor shr 8) and 0xFF).toByte()
        val b = (_lastLedColor and 0xFF).toByte()
        val playerPattern = if (_lastPlayerLed != 0) {
            PLAYER_LED_PATTERNS[(Integer.bitCount(_lastPlayerLed) - 1).coerceIn(0, 4)]
        } else 0

        val report = DualSenseOutputReport.compactFrame(
            motor0, motor1,
            _lastTriggerTypeL, _lastTriggerTypeR,
            _lastTriggerDataL, _lastTriggerDataR,
            _pendingTriggerFlags.toByte(), r, g, b, playerPattern,
            // While the voice coil is streaming, the report must not carry the
            // motor flags: that would switch the DS5 back to compatible-vibration
            // mode and cut off audio haptics (the audio/rumble ping-pong).
            !voiceCoilActive,
        )
        _pendingTriggerFlags = 0
        controller.sendCommand(report)
    }

    // ── Adaptive triggers / trigger rumble (reserved) ──────

    override fun setAdaptiveTriggerEffects(
        controllerIndex: Int, eventFlags: Byte, typeLeft: Byte, typeRight: Byte,
        left: ByteArray?, right: ByteArray?,
    ) {
        val combined = gameVibrationDevice.type == VibrationDeviceType.CONTROLLER &&
            gameVibrationDevice.controllerIndex == controllerIndex
        if (combined) {
            _lastTriggerTypeL = typeLeft
            _lastTriggerTypeR = typeRight
            _lastTriggerDataL = left
            _lastTriggerDataR = right
            _pendingTriggerFlags = _pendingTriggerFlags or (eventFlags.toInt() and TRIGGER_FLAG_MASK)
            synchronized(this) { sendCombinedReport() }
        } else {
            synchronized(this) {
                val ctrl = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return
                ctrl.setAdaptiveTriggerEffects(eventFlags, typeLeft, typeRight, left, right)
            }
        }
    }

    override fun setTriggerRumble(controllerIndex: Int, leftTrigger: Int, rightTrigger: Int) {
        synchronized(this) {
            val controller = synchronized(lock) { controllerList.getOrNull(controllerIndex) } ?: return
            controller.rumbleTriggers(
                (leftTrigger.coerceIn(0, 255) * 257).toShort(),
                (rightTrigger.coerceIn(0, 255) * 257).toShort(),
            )
        }
    }

    // ── Phone vibration (mirrors the SDL backend) ──────────

    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private var lastPhoneAmp = -1

    /** 普通振动是否已被 HD 通路接管（用于切换时取消残留的普通波形）。 */
    private var phoneHdOwned = false

    private fun vibratePhoneMotors(low: Int, high: Int, swap: Boolean) {
        val motor0 = if (swap) high else low
        val motor1 = if (swap) low else high
        if (PhoneHdHaptics.playMotors(motor0, motor1, source = HapticSource.GAME_RUMBLE)) {
            if (!phoneHdOwned) {
                phoneHdOwned = true
                // HD 接管前清掉普通/多马达通路，避免旧波形残留。
                try { phoneVibratorManager()?.cancel() } catch (_: Exception) {}
                try { vibrator.cancel() } catch (_: Exception) {}
            }
            lastPhoneAmp = maxOf(motor0, motor1)
            return
        }
        phoneHdOwned = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = phoneVibratorManager()
            val ids = vm?.vibratorIds
            if (vm != null && ids != null && ids.size >= 2) {
                vibrateMultiMotor(vm, ids, intArrayOf(motor0, motor1))
                return
            }
        }
        vibratePhone(maxOf(motor0, motor1))
    }

    private fun vibrateMultiMotor(vm: VibratorManager, ids: IntArray, amps: IntArray) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        try {
            var hasActive = false
            val combo = android.os.CombinedVibration.startParallel()
            for (i in ids.indices) {
                val amp = amps.getOrElse(i) { 0 }
                if (amp > 0) {
                    // VibrationEffect 不接受 0 幅度；0 幅度马达从组合中剔除即可关闭。
                    combo.addVibrator(ids[i], VibrationEffect.createOneShot(60000, amp.coerceIn(1, 255)))
                    hasActive = true
                }
            }
            if (!hasActive) {
                vm.cancel()
                return
            }
            // 非 0 时直接 vibrate：新组合会替换上一个效果，无需先 cancel（避免高频流下残留）。
            vm.vibrate(combo.combine())
        } catch (_: Exception) {
        }
    }

    private fun phoneVibratorManager(): VibratorManager? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        }
        return null
    }

    private fun vibratePhone(amp: Int) {
        val clamped = amp.coerceIn(0, 255)
        if (clamped < 1) {
            phoneHdOwned = false
            PhoneHdHaptics.stop(HapticSource.GAME_RUMBLE)
            // 多马达路径在 VibratorManager 上启动：必须 manager.cancel() 才能停掉全部马达，
            // 只 cancel 默认马达会遗漏其余马达直到 60s one-shot 过期。
            try { phoneVibratorManager()?.cancel() } catch (_: Exception) {}
            try { vibrator.cancel() } catch (_: Exception) {}
            lastPhoneAmp = -1
            return
        }
        if (clamped == lastPhoneAmp) return
        lastPhoneAmp = clamped
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.cancel()
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(50), intArrayOf(clamped), 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(60000)
            }
        } catch (_: Exception) {
        }
    }

    private fun displayName(controller: AbstractController): String {
        return when (controller.javaClass.simpleName) {
            "DualSenseController" -> "DualSense"
            "Dualshock4Controller" -> "DualShock 4"
            "XboxOneController" -> "Xbox One"
            "Xbox360Controller" -> "Xbox 360"
            "ProConController" -> "Switch Pro"
            "ProCon2Controller" -> "Switch Pro 2"
            "GameSirG7Controller" -> "GameSir G7"
            "Hid8BitdoController" -> "8BitDo"
            else -> when (controller.getType()) {
                GkmeBridge.LI_CTYPE_XBOX -> "Controle Xbox"
                GkmeBridge.LI_CTYPE_PS -> "Controle PlayStation"
                GkmeBridge.LI_CTYPE_NINTENDO -> "Controle Switch"
                else -> controller.javaClass.simpleName
            }
        }
    }

    companion object {
        private const val TRIGGER_DIGITAL_THRESHOLD = 0.5f
        private const val VOICE_COIL_SILENCE_TIMEOUT_NS = 200_000_000L // 200ms

        // DualSense VALID_FLAG0 trigger bits (mirror DualSenseOutputReport).
        private const val TRIGGER_FLAG_RIGHT = 0x04
        private const val TRIGGER_FLAG_LEFT = 0x08
        private const val TRIGGER_FLAG_MASK = TRIGGER_FLAG_LEFT or TRIGGER_FLAG_RIGHT

        // Sunshine / Limelight button flags produced by the USB driver.
        private const val USB_UP = 0x0001
        private const val USB_DOWN = 0x0002
        private const val USB_LEFT = 0x0004
        private const val USB_RIGHT = 0x0008
        private const val USB_PLAY = 0x0010
        private const val USB_BACK = 0x0020
        private const val USB_LS = 0x0040
        private const val USB_RS = 0x0080
        private const val USB_LB = 0x0100
        private const val USB_RB = 0x0200
        private const val USB_SPECIAL = 0x0400
        private const val USB_A = 0x1000
        private const val USB_B = 0x2000
        private const val USB_X = 0x4000
        private const val USB_Y = 0x8000
        private const val USB_TOUCHPAD = 0x100000
        private const val USB_MISC = 0x200000
        private const val USB_PADDLE1 = 0x010000
        private const val USB_PADDLE2 = 0x020000
        private const val USB_PADDLE3 = 0x040000
        private const val USB_PADDLE4 = 0x080000
        private const val USB_M_BUTTON = 0x2000000

        private val PLAYER_LED_PATTERNS = intArrayOf(0x04, 0x0A, 0x15, 0x1B, 0x1F)
    }

    override fun sendCompactFrame(
        rumbleLow: Int, rumbleHigh: Int,
        triggerTypeLeft: Byte, triggerTypeRight: Byte,
        triggerDataLeft: ByteArray?, triggerDataRight: ByteArray?,
        ledColor: Int, playerLed: Int,
        eventFlags: Byte,
    ) {
        when (gameVibrationDevice.type) {
            VibrationDeviceType.CONTROLLER -> {
                _lastRumbleLow = rumbleLow.coerceIn(0, 255)
                _lastRumbleHigh = rumbleHigh.coerceIn(0, 255)
                _lastTriggerTypeL = triggerTypeLeft
                _lastTriggerTypeR = triggerTypeRight
                _lastTriggerDataL = triggerDataLeft
                _lastTriggerDataR = triggerDataRight
                if (triggerTypeLeft.toInt() != 0 || triggerTypeRight.toInt() != 0 ||
                    triggerDataLeft != null || triggerDataRight != null) {
                    _pendingTriggerFlags = _pendingTriggerFlags or (eventFlags.toInt() and TRIGGER_FLAG_MASK)
                }
                _lastLedColor = ledColor
                _lastPlayerLed = playerLed
                synchronized(this) { sendCombinedReport() }
            }
            VibrationDeviceType.PHONE -> {
                rumble(rumbleLow, rumbleHigh)
                if (ledColor != 0 || playerLed != 0) setLedColor(ledColor, playerLed)
            }
            VibrationDeviceType.NONE -> {}
        }
    }
}
