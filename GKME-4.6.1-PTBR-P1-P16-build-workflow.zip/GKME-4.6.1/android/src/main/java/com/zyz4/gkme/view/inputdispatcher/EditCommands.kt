package com.zyz4.gkme.view.inputdispatcher

import com.zyz4.gkme.model.ButtonPosition

// ================================================================
// Constants used by multiple files in this module
// ================================================================

const val SETTINGS_BUTTON_ID = "btnSettings"

// ================================================================
// Utility functions
// ================================================================

fun isTouchpadId(id: String): Boolean = id.substringBefore("_") == "touchpad"

fun screenGridSize(pos: ButtonPosition): Pair<Int, Int> {
    val isSwapped = !pos.lockAspect && (pos.rotation == 90 || pos.rotation == 270)
    return if (isSwapped) pos.height to pos.width else pos.width to pos.height
}

fun sanitizeSettingsButton(
    pos: ButtonPosition,
    gridX: Int = pos.x,
    gridY: Int = pos.y,
): ButtonPosition {
    return pos.copy(x = gridX, y = gridY)
}

/** Shrink touchpad so it fits inside follow-area rectangle. */
fun shrinkTouchpadToArea(pos: ButtonPosition, oldPos: ButtonPosition): ButtonPosition {
    if (!isTouchpadId(pos.id) || !pos.followAreaEnabled) return pos
    val (sw, sh) = screenGridSize(pos)
    val nw = minOf(sw, (pos.followAreaX + pos.followAreaW - pos.x).coerceAtLeast(1))
    val nh = minOf(sh, (pos.followAreaY + pos.followAreaH - pos.y).coerceAtLeast(1))
    if (nw == sw && nh == sh) return pos
    val isSwapped = !pos.lockAspect && (pos.rotation == 90 || pos.rotation == 270)
    val width = if (isSwapped) nh else nw
    val height = if (isSwapped) nw else nh
    return pos.copy(width = width, height = height)
}

// ================================================================
// EditCommand sealed interface
// ================================================================

/**
 * Edit-mode commands. Pure data — applyTo returns a new list, no side effects.
 *
 * Only gesture-recognised operations become commands. UI-control-triggered
 * operations (rotation slider, opacity seekbar, curve editor, delete,
 * duplicate) remain as onButtonUpdated callbacks in FloatingEditorPanel.
 *
 * Open-closed: new command types can be added without modifying existing code.
 */
sealed interface EditCommand {
    fun applyTo(current: List<ButtonPosition>): List<ButtonPosition>

    data class MoveButton(
        val id: String,
        val gridX: Int,
        val gridY: Int,
    ) : EditCommand {
        override fun applyTo(current: List<ButtonPosition>): List<ButtonPosition> {
            val idx = current.indexOfFirst { it.id == id }
            if (idx < 0) return current
            val sanitized = if (id == SETTINGS_BUTTON_ID) {
                sanitizeSettingsButton(current[idx], gridX, gridY)
            } else {
                current[idx].copy(x = gridX, y = gridY)
            }
            return current.toMutableList().also { it[idx] = sanitized }
        }
    }

    data class ResizeButton(
        val id: String,
        val gridWidth: Int,
        val gridHeight: Int,
    ) : EditCommand {
        override fun applyTo(current: List<ButtonPosition>): List<ButtonPosition> {
            val idx = current.indexOfFirst { it.id == id }
            if (idx < 0) return current
            var updated = current[idx].copy(width = gridWidth, height = gridHeight)
            if (id == SETTINGS_BUTTON_ID) {
                updated = sanitizeSettingsButton(updated)
            }
            return current.toMutableList().also { it[idx] = updated }
        }
    }

    data class MoveFollowArea(
        val id: String,
        val newX: Int,
        val newY: Int,
    ) : EditCommand {
        override fun applyTo(current: List<ButtonPosition>): List<ButtonPosition> {
            val idx = current.indexOfFirst { it.id == id }
            if (idx < 0) return current
            val updated = current[idx].copy(followAreaX = newX, followAreaY = newY)
            if (!isTouchpadId(id) || !updated.followAreaEnabled) {
                return current.toMutableList().also { it[idx] = updated }
            }
            val (sw, sh) = screenGridSize(updated)
            var btnX = updated.x
            var btnY = updated.y
            if (btnX < updated.followAreaX) btnX = updated.followAreaX
            if (btnY < updated.followAreaY) btnY = updated.followAreaY
            if (btnX + sw > updated.followAreaX + updated.followAreaW) {
                btnX = updated.followAreaX + updated.followAreaW - sw
            }
            if (btnY + sh > updated.followAreaY + updated.followAreaH) {
                btnY = updated.followAreaY + updated.followAreaH - sh
            }
            if (btnX == updated.x && btnY == updated.y) {
                return current.toMutableList().also { it[idx] = updated }
            }
            return current.toMutableList().also { it[idx] = updated.copy(x = btnX, y = btnY) }
        }
    }

    data class ResizeFollowArea(
        val id: String,
        val newW: Int,
        val newH: Int,
    ) : EditCommand {
        override fun applyTo(current: List<ButtonPosition>): List<ButtonPosition> {
            val idx = current.indexOfFirst { it.id == id }
            if (idx < 0) return current
            val old = current[idx]
            var updated = old.copy(followAreaW = newW, followAreaH = newH)
            if (isTouchpadId(id) && old.followAreaEnabled) {
                updated = shrinkTouchpadToArea(updated, old)
            }
            return current.toMutableList().also { it[idx] = updated }
        }
    }
}