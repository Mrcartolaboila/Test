package com.zyz4.gkme.view

import android.view.View
import android.widget.Button
import android.view.ViewGroup
import com.zyz4.gkme.model.ButtonPosition
import com.zyz4.gkme.model.GyroOrientation

/**
 * Deep module: applies layout-time configuration to child Views.
 *
 * Responsibilities (from GamepadLayout.onLayout):
 * - Measure and layout each child based on ButtonPosition grid coords
 * - Set visibility (VISIBLE/GONE) based on position.visible flag
 * - Apply rotation, scale aspect swap for 90/270 degree rotation
 * - Set opacity (alpha) for idle/active states
 * - Configure JoystickView/DpadPadView/CustomKeypadView properties
 * - Set padding for adaptive content buttons
 * - Apply content text auto-fit cap
 * - Handle preview opacity mode in edit mode
 *
 * Interface: [applyLayout()] accepts layout params and child list,
 * mutates the children in place (standard ViewGroup pattern).
 * All data-driven decisions happen here.
 */
class GamepadLayoutApplier {

    /** 上次测量尺寸缓存：尺寸未变且控件未请求重新布局时跳过 measure，减少重复测量。 */
    private val lastMeasuredSize = java.util.WeakHashMap<View, Long>()

    /**
     * Apply layout configuration to all children of a GamepadLayout.
     *
     * This replaces the ~80-line for loop inside GamepadLayout.onLayout().
     * All configuration logic is self-contained here.
     */
    fun applyLayout(
        childCount: Int,
        getChildAt: (index: Int) -> View,
        getButtonId: (View) -> String?,
        buttons: Map<String, ButtonPosition>,
        ctrlEntryBitMap: Map<String, Int>,
        cellW: Float,
        cellH: Float,
        selectedButtonId: String?,
        isEditMode: Boolean,
        previewOpacity: Boolean,
        previewButtonId: String?,
        previewIdleOpacity: Boolean,
        getPressedBits: () -> UInt,
        isAdaptiveContentButton: (String, View) -> Boolean,
        contentCapPx: (View, com.zyz4.gkme.model.AppSettings?) -> Int?,
        applyContentTextCap: (Button, Int) -> Unit,
        getRotation: (String) -> Int,
        appearanceSettings: com.zyz4.gkme.model.AppSettings?,
    ) {
        val pressedBits = getPressedBits()
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            val id = getButtonId(child) ?: continue
            val pos = buttons[id]
            if (pos == null) {
                child.visibility = View.GONE
                continue
            }

            if (!pos.visible) {
                if (child.visibility != View.GONE) child.visibility = View.GONE
                continue
            }
            if (child.visibility != View.VISIBLE) child.visibility = View.VISIBLE

            applyChildLayout(
                child, pos, id, cellW, cellH, getRotation,
                isAdaptiveContentButton, contentCapPx, applyContentTextCap, appearanceSettings,
            )

            if (isAdaptiveContentButton(id, child)) {
                // Note: child.width/height may be 0 at this point; caller handles this
            }

            applyChildOpacity(
                child, pos, ctrlEntryBitMap, pressedBits, isEditMode, previewOpacity,
                previewButtonId, previewIdleOpacity, selectedButtonId,
            )

            applyChildSpecialProperties(
                child, pos, id, isEditMode, selectedButtonId,
            )
        }
    }

    // ── Helpers ────────────────────────────────────────────

    private fun applyChildLayout(
        child: View,
        pos: ButtonPosition,
        id: String,
        cellW: Float,
        cellH: Float,
        getRotation: (String) -> Int,
        isAdaptiveContentButton: (String, View) -> Boolean,
        contentCapPx: (View, com.zyz4.gkme.model.AppSettings?) -> Int?,
        applyContentTextCap: (Button, Int) -> Unit,
        appearanceSettings: com.zyz4.gkme.model.AppSettings?,
    ) {
        val isSwapped = !pos.lockAspect && (pos.rotation == 90 || pos.rotation == 270)
        val childW = ((if (isSwapped) pos.height else pos.width) * cellW).toInt()
        val childH = ((if (isSwapped) pos.width else pos.height) * cellH).toInt()
        val left = (pos.x * cellW).toInt()
        val top = (pos.y * cellH).toInt()

        // 在测量之前先把自适应内边距与文本自适应上限设好，避免测量后 setPadding /
        // 重设 autosize 触发 requestLayout 导致多一次布局遍历（启动时会翻倍 onLayout 成本）。
        if (isAdaptiveContentButton(id, child)) {
            val pad = (minOf(childW, childH) * 0.1f).toInt()
            if (child.paddingLeft != pad || child.paddingTop != pad) {
                child.setPadding(pad, pad, pad, pad)
            }
        }
        if (child is Button && !child.text.isNullOrEmpty()) {
            val maxDim = maxOf(childW, childH).coerceAtLeast(1)
            val capPx = contentCapPx(child, appearanceSettings)
            val effectiveCap = capPx?.let { minOf(it, maxDim) } ?: maxDim
            applyContentTextCap(child, effectiveCap)
        }

        val sizeKey = (childW.toLong() shl 32) or (childH.toLong() and 0xFFFFFFFFL)
        if (child.isLayoutRequested || lastMeasuredSize[child] != sizeKey) {
            child.measure(
                View.MeasureSpec.makeMeasureSpec(childW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(childH, View.MeasureSpec.EXACTLY),
            )
            lastMeasuredSize[child] = sizeKey
        }
        child.layout(left, top, left + childW, top + childH)

        // Rotation
        if (child is JoystickView) {
            child.axisRotation = pos.rotation
        } else if (child is DpadPadView) {
            child.rotation = pos.rotation.toFloat()
        } else if (child is CustomKeypadView) {
            child.rotation = pos.rotation.toFloat()
        } else if (child is com.zyz4.gkme.view.RotatableButton) {
            child.textRotation = pos.rotation
        } else if (child is ViewGroup) {
            for (j in 0 until child.childCount) {
                child.getChildAt(j).rotation = pos.rotation.toFloat()
            }
        } else if (pos.lockAspect) {
            child.rotation = pos.rotation.toFloat()
        }
    }

    /**
     * Re-applies idle/active opacity in place, without running a full layout.
     *
     * Controls whose alpha is managed by their own touch handling (joysticks,
     * dpad pads, keypads, linear triggers, touchpads) are skipped, since their
     * gamepad-button transitions would otherwise clobber the alpha they set on
     * touch.
     */
    fun refreshButtonOpacity(
        childCount: Int,
        getChildAt: (index: Int) -> View,
        getButtonId: (View) -> String?,
        buttons: Map<String, ButtonPosition>,
        ctrlEntryBitMap: Map<String, Int>,
        pressedBits: UInt,
        isEditMode: Boolean,
        previewOpacity: Boolean,
        previewButtonId: String?,
        previewIdleOpacity: Boolean,
    ) {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            val id = getButtonId(child) ?: continue
            if (managesOwnOpacity(id, child)) continue
            val pos = buttons[id] ?: continue
            if (!pos.visible) continue
            applyChildOpacity(
                child, pos, ctrlEntryBitMap, pressedBits, isEditMode,
                previewOpacity, previewButtonId, previewIdleOpacity, null,
            )
        }
    }

    private fun managesOwnOpacity(id: String, child: View): Boolean =
        child is JoystickView || child is DpadPadView || child is CustomKeypadView ||
            child is LinearTriggerView || id.startsWith("touchpad") || id.startsWith("mousepad")

    private fun applyChildOpacity(
        child: View,
        pos: ButtonPosition,
        ctrlEntryBitMap: Map<String, Int>,
        pressedBits: UInt,
        isEditMode: Boolean,
        previewOpacity: Boolean,
        previewButtonId: String?,
        previewIdleOpacity: Boolean,
        selectedButtonId: String?,
    ) {
        if (isEditMode && previewOpacity && previewButtonId == child.tag) {
            val opacityVal = if (previewIdleOpacity) pos.idleOpacity else pos.activeOpacity
            child.alpha = opacityVal.coerceIn(0, 100) / 100f
        } else if (isEditMode) {
            child.alpha = 1f
        } else {
            val baseId = child.tag?.toString()?.substringBefore("_") ?: ""
            val bit = ctrlEntryBitMap[baseId] ?: 0
            val isDown = bit != 0 && (pressedBits and bit.toUInt()) != 0u
            val opacityVal = if (isDown) pos.activeOpacity else pos.idleOpacity
            child.alpha = opacityVal.coerceIn(0, 100) / 100f
        }
    }

    private fun applyChildSpecialProperties(
        child: View,
        pos: ButtonPosition,
        id: String,
        isEditMode: Boolean,
        selectedButtonId: String?,
    ) {
        if (child is JoystickView) {
            child.joystickSensitivity = pos.joystickSensitivity
            child.touchpadMode = pos.touchpadMode
            child.prediction = pos.prediction
            child.deadZone = pos.deadZone
            child.reverseDeadZone = pos.reverseDeadZone
            child.showDeadZoneIndicator = isEditMode && id == selectedButtonId
            child.forceFollowFinger = false
            child.idleOpacity = pos.idleOpacity.coerceIn(0, 100)
            child.activeOpacity = pos.activeOpacity.coerceIn(0, 100)
        } else if (child is DpadPadView) {
            child.forceFollowFinger = false
            child.centerShape = pos.centerShape
            child.idleOpacity = pos.idleOpacity.coerceIn(0, 100)
            child.activeOpacity = pos.activeOpacity.coerceIn(0, 100)
        } else if (child is CustomKeypadView) {
            child.forceFollowFinger = false
            child.centerShape = pos.centerShape
            child.idleOpacity = pos.idleOpacity.coerceIn(0, 100)
            child.activeOpacity = pos.activeOpacity.coerceIn(0, 100)
            child.eightWay = pos.keypadEightWay
            val kpBits = ButtonPosition.keypadBitsOf(pos)
            child.validDirs = ButtonPosition.keypadDirectionIndices(pos.keypadEightWay)
                .filter { kpBits.getOrNull(it)?.isNotEmpty() == true }
                .toSet()
        }
    }

    /** Returns [left, top, width, height] in grid coordinates for the visual extent. */
    fun visualBounds(pos: ButtonPosition): FloatArray {
        val isSwapped = !pos.lockAspect && (pos.rotation == 90 || pos.rotation == 270)
        val lw = if (isSwapped) pos.height else pos.width
        val lh = if (isSwapped) pos.width else pos.height
        return floatArrayOf(pos.x.toFloat(), pos.y.toFloat(), lw.toFloat(), lh.toFloat())
    }
}