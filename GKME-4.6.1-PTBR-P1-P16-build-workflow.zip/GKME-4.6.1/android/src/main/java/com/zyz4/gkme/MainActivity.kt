package com.zyz4.gkme

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.hardware.display.DisplayManager
import android.view.Display
import android.media.session.MediaSession
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.zyz4.gkme.controlled.GamepadInjector
import com.zyz4.gkme.controlled.HapticInjector
import com.zyz4.gkme.haptic.HapticSource
import com.zyz4.gkme.haptic.PhoneHdHaptics
import com.zyz4.gkme.model.AudioDevice
import com.zyz4.gkme.model.AdaptiveTriggerDevice
import com.zyz4.gkme.model.GamepadState
import com.zyz4.gkme.model.AppSettings
import com.zyz4.gkme.model.ConnectionMode
import com.zyz4.gkme.model.HapticEffect
import com.zyz4.gkme.model.VibrationType
import com.zyz4.gkme.service.ConnectionPhase
import com.zyz4.gkme.service.FloatingOverlayService
import com.zyz4.gkme.view.FloatingEditorPanel
import com.zyz4.gkme.view.GamepadLayout
import com.zyz4.gkme.view.LayoutGlobalSettingsPanel
import com.zyz4.gkme.input.AdaptiveTriggerHandler
import com.zyz4.gkme.input.PhysicalControllerHandler
import com.zyz4.gkme.input.SdlAudio
import com.zyz4.gkme.input.SdlPlatform
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    internal val viewModel: GkViewModel by viewModels()
    internal lateinit var gamepadLayout: GamepadLayout
    internal lateinit var floatingController: FloatingModeController
    internal val floatingEditor: FloatingEditorPanel by lazy { createFloatingEditor() }
    internal var layoutGlobalSettingsPanel: LayoutGlobalSettingsPanel? = null
    internal var curveZoomOverlay: com.zyz4.gkme.view.CurveZoomOverlay? = null
    internal val controlViews = mutableMapOf<String, View>()
    internal val touchpadLabels = mutableListOf<TextView>()
    internal val mousepadLabels = mutableListOf<TextView>()
    internal var discoverableRequested = false
    internal var vibrationPollingJob: kotlinx.coroutines.Job? = null
    internal var audioPollingJob: kotlinx.coroutines.Job? = null
    internal var shizukuPollingJob: kotlinx.coroutines.Job? = null
    internal var localStartPending = false
    /** 用户点击“启动服务”后因缺少蓝牙权限而挂起的蓝牙模式启动请求。 */
    internal var pendingBluetoothStart = false
    internal var lastAppliedSettings: AppSettings? = null
    internal var lastPresetInfos: Any? = null
    internal var lastPresetCurrentName: String? = null

    private var floatingStartedAt = 0L
    private var pendingFloatingStart = false
    private val FLOATING_RESUME_GUARD_MS = 2000L

    internal var audioControllerDeviceEntries: List<AudioDevice> = emptyList()
    internal var adaptiveTriggerDeviceEntries: List<AdaptiveTriggerDevice> = emptyList()
    internal var adaptiveTriggerUserSelecting = false

    private var mediaSession: MediaSession? = null

    /** 自适应扳机的手机马达是否已被 HD 通路接管。 */
    private var phoneHdAdaptiveOwned = false

    internal val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
    }

    internal val bluetoothPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.all { it.value }) {
            // 仅在“启动蓝牙模式”流程中申请：授权成功后继续启动服务。
            if (pendingBluetoothStart) {
                pendingBluetoothStart = false
                checkBluetoothOnAndStart()
            }
        } else {
            pendingBluetoothStart = false
            showToast("A permissão Bluetooth é necessária para usar o modo Bluetooth")
        }
    }

    /** 蓝牙运行时权限（Android 12+）是否已全部授予。低版本安装时即授予，无需申请。 */
    internal fun hasBluetoothRuntimePermissions(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return android.Manifest.permission.BLUETOOTH_CONNECT.let {
            ContextCompat.checkSelfPermission(this, it) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        } && android.Manifest.permission.BLUETOOTH_ADVERTISE.let {
            ContextCompat.checkSelfPermission(this, it) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * 启动蓝牙模式：应用启动时不申请蓝牙权限，只有用户启动蓝牙模式时才在此处按需申请；
     * 已授权则直接检查蓝牙开关并启动服务。
     */
    internal fun startBluetoothModeWithPermission() {
        if (hasBluetoothRuntimePermissions()) {
            checkBluetoothOnAndStart()
        } else {
            pendingBluetoothStart = true
            bluetoothPermissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.BLUETOOTH_CONNECT,
                    android.Manifest.permission.BLUETOOTH_ADVERTISE,
                )
            )
        }
    }

    internal val bluetoothEnableLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            viewModel.startServer()
        } else {
            showToast("Ative o Bluetooth para usar o modo Bluetooth")
        }
    }

    internal val discoverableLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> }

    internal val importPresetLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { importPresetFromUri(it) }
    }

    internal val exportPresetLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let { exportPresetToUri(it) }
    }

    internal val exportAppearanceLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        uri?.let { exportAppearanceToUri(it) }
    }

    internal val importAppearanceLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { importAppearanceFromUri(it) }
    }

    internal val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            continueEnterFloating()
        } else {
            showToast("A permissão de sobreposição é necessária para usar o modo flutuante")
        }
    }

    internal val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        if (pendingFloatingStart) {
            pendingFloatingStart = false
            startFloatingMode()
        }
    }

    private val displayManager by lazy { getSystemService(DISPLAY_SERVICE) as DisplayManager }

    internal lateinit var physicalControllerHandler: PhysicalControllerHandler

    internal val adaptiveTriggerHandler: AdaptiveTriggerHandler by lazy {
        AdaptiveTriggerHandler(
            physicalControllerHandler,
            phoneVibration = { left, right, leftFreqHz, rightFreqHz ->
                vibratePhoneForAdaptive(left, right, leftFreqHz, rightFreqHz)
            },
            controllerVibration = { index, left, right, leftFreqHz, rightFreqHz ->
                vibrateControllerForAdaptive(index, left, right, leftFreqHz, rightFreqHz)
            },
        )
    }

    internal val audioPlaybackService: com.zyz4.gkme.service.AudioPlaybackService
        get() = viewModel.connectionManager.audioPlaybackService

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY) return
            checkDeviceRotation()
        }
    }

    @Suppress("DEPRECATION")
    internal fun checkDeviceRotation() {
        val inverted = windowManager.defaultDisplay.rotation == Surface.ROTATION_270
        viewModel.setDeviceInverted(inverted)
        if (inSettings) updateGyroLandscapeInvertedNote(inverted)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableEdgeToEdge()
        hideSystemBars()
        gamepadLayout = findViewById(R.id.gamepadLayout)
        floatingController = FloatingModeController(this)
        physicalControllerHandler = PhysicalControllerHandler(this)
        setupMediaSession()
        setupGamepadLayoutListener()
        viewModel.onHapticFeedbackPress = { performHaptic(isPress = true) }
        viewModel.onHapticFeedbackRelease = { performHaptic(isPress = false) }
        gamepadLayout.applyAppearance(viewModel.settings.value)
        // Register the appearance image-picker launchers now (registration must happen before
        // the activity is resumed). The settings panel itself is inflated lazily on the first
        // showSettings(), and the inflation is also pre-scheduled off the startup path so the
        // first frame stays fast.
        setupAppearanceImageLaunchers()
        Handler(Looper.getMainLooper()).postDelayed({
            // 首帧之后再初始化 Shizuku 监听与 RichTap 预置资源，避免拖慢启动。
            // 注册 Shizuku 监听（本机模式使用），以便连接页正确显示授权条目状态。
            GamepadInjector.init(this)
            // 高清震动（HD）进程内 RichTap；本机不支持时自动回退普通震动。
            HapticInjector.init(this)
            physicalControllerHandler.start()
            ensureSettingsInflated()
        }, 500L)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    isScreenOff -> exitScreenOffMode()
                    previewZoomVisible -> hidePreviewZoom()
                    isCurveZoomVisible() -> hideCurveZoom()
                    layoutGlobalSettingsPanel?.isCurveOverlayVisible() == true -> layoutGlobalSettingsPanel?.hideCurveOverlay()
                    isLayoutGlobalSettingsVisible() -> hideLayoutGlobalSettings()
                    gamepadLayout.isEditModeActive() -> {
                        CustomDialog.showConfirm(
                            context = this@MainActivity,
                            title = "Sair da edição",
                            message = "Descartar as alterações?",
                            positiveText = "Descartar",
                            onPositive = {
                                gamepadLayout.discardToSnapshot()
                                gamepadLayout.exitEditMode()
                            }
                        )
                    }
                    inSettings -> hideSettings()
                }
            }
        })
        observeState()
        autoStartService()
        setupUsbAudioCallbacks()
        displayManager.registerDisplayListener(displayListener, null)
        checkDeviceRotation()
        // Bring up the SDL Java glue (without claiming USB HID) and the SDL audio
        // subsystem so the sound-device list is available even when the physical
        // controller is handled by the non-SDL driver. Failure is non-fatal: the
        // phone-speaker path then falls back to AudioTrack.
        runCatching { SdlPlatform.ensureCore(this) }
        SdlAudio.ensureInit()
    }

    private fun setupUsbAudioCallbacks() {
        val a = this
        a.audioPlaybackService.supportsVoiceCoilPcm = { index ->
            a.physicalControllerHandler.controllerSupportsVoiceCoilPcm(index)
        }
        a.audioPlaybackService.supportsControllerAudio = { index ->
            a.physicalControllerHandler.controllerSupportsAudio(index)
        }
        a.audioPlaybackService.onVoiceCoilPcm = { index, frame ->
            a.physicalControllerHandler.submitVoiceCoilFrame(index, frame)
        }
        a.audioPlaybackService.onControllerAudioPcm = { index, frame ->
            a.physicalControllerHandler.submitControllerAudioFrame(index, frame)
        }
        a.audioPlaybackService.supportsHdRumble = { index ->
            a.physicalControllerHandler.controllerSupportsHdRumble(index)
        }
        a.audioPlaybackService.onHdRumble = { index, bands ->
            a.physicalControllerHandler.setControllerHdRumble(
                index,
                bands.leftHighFreq, bands.leftHighAmp, bands.leftLowFreq, bands.leftLowAmp,
                bands.rightHighFreq, bands.rightHighAmp, bands.rightLowFreq, bands.rightLowAmp,
            )
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.navigationBars())
            window.insetsController?.systemBarsBehavior =
                WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    override fun onDestroy() {
        if (::floatingController.isInitialized && floatingController.isActive) {
            runCatching { floatingController.exit() }
            stopService(Intent(this, FloatingOverlayService::class.java))
        }
        physicalControllerHandler.stop()
        mediaSession?.release()
        displayManager.unregisterDisplayListener(displayListener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::floatingController.isInitialized && floatingController.isActive &&
            android.os.SystemClock.elapsedRealtime() - floatingStartedAt > FLOATING_RESUME_GUARD_MS
        ) {
            exitFloatingMode()
        }
    }

    /**
     * 本机模式下服务已启动时，用户每次最小化应用（Home / 最近任务）都自动进入悬浮模式，
     * 无需再手动点按悬浮按钮。切到本 App 内部页面或系统权限页不会触发
     * [onUserLeaveHint]，因此不会被误触发。
     */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        maybeAutoEnterFloating()
    }

    private fun maybeAutoEnterFloating() {
        if (viewModel.settings.value.connectionMode != ConnectionMode.LOCAL) return
        if (viewModel.connectionState.value.phase == ConnectionPhase.IDLE) return
        if (!::floatingController.isInitialized || floatingController.isActive) return
        // 悬浮启动的权限流程进行中时不再重复触发，避免权限对话框反复弹出。
        if (pendingFloatingStart) return
        // 缺少悬浮窗权限时 enterFloatingMode 会跳转授权页；这里不主动触发，避免
        // 每次最小化都弹出授权流程。授权后由启动服务/手动入口进入。
        if (!Settings.canDrawOverlays(this)) return
        if (gamepadLayout.isEditModeActive()) return
        enterFloatingMode()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(FloatingOverlayService.EXTRA_EXIT_FLOATING, false)) {
            exitFloatingMode()
        }
    }

    // ── Floating mode ──────────────────────────────────────

    internal fun enterFloatingMode() {
        if (::floatingController.isInitialized && floatingController.isActive) return
        if (gamepadLayout.isEditModeActive()) {
            showToast("Saia do modo de edição primeiro")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"),
            )
            overlayPermissionLauncher.launch(intent)
            return
        }
        continueEnterFloating()
    }

    private fun continueEnterFloating() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            pendingFloatingStart = true
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startFloatingMode()
    }

    private fun startFloatingMode() {
        if (floatingController.isActive) return
        if (isScreenOff) exitScreenOffMode()
        if (inSettings) hideSettings()
        ContextCompat.startForegroundService(this, Intent(this, FloatingOverlayService::class.java))
        floatingController.enter()
        floatingStartedAt = android.os.SystemClock.elapsedRealtime()
        moveTaskToBack(true)
        showToast("Modo flutuante ativado. Toque no botão flutuante para mostrar/ocultar")
    }

    internal fun exitFloatingMode() {
        if (!::floatingController.isInitialized || !floatingController.isActive) return
        runCatching { floatingController.exit() }
        stopService(Intent(this, FloatingOverlayService::class.java))
        showToast("Modo flutuante encerrado")
    }

    internal var pointerCaptureNeeded = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars()
            if (pointerCaptureNeeded) {
                Handler(Looper.getMainLooper()).postDelayed({
                    gamepadLayout.setTouchpadCaptureMode(true)
                }, 500)
            }
        }
    }

    // ── MediaSession (intercept volume keys before system) ──

    private fun setupMediaSession() {
        mediaSession = MediaSession(this, "GKME").apply {
            isActive = true
        }
    }

    // ── Dialog fields ──────────────────────────────────────

    internal var addDialog: Dialog? = null
    internal var addCounter = 0
    internal var inSettings = false
    internal var isScreenOff = false
    internal var currentSettingsCategory = 0
    internal var settingsInflated = false
    internal var outputPickerDialog: Dialog? = null
    internal val sidebarItemDrawables = mutableMapOf<Int, com.zyz4.gkme.view.SidebarItemDrawable>()
    internal val sidebarAnimators = mutableMapOf<Int, android.animation.AnimatorSet>()
    internal var settingsRevealAnimator: android.animation.Animator? = null

    internal var gameVibrationDeviceEntries: List<com.zyz4.gkme.model.VibrationDevice> =
        listOf(com.zyz4.gkme.model.VibrationDevice.PHONE, com.zyz4.gkme.model.VibrationDevice.NONE)

    /** Controller indices backing the physical-controller input spinner; -1 = 不使用手柄. */
    internal var inputControllerIndices: List<Int> = listOf(-1)

    /** True while the user is picking a physical-controller input from the spinner. */
    internal var inputControllerUserSelecting = false

    /** True while the user is picking the physical-controller driver from the spinner. */
    internal var controllerDriverUserSelecting = false

    /** Drivers backing the physical-controller driver spinner. */
    internal var controllerDriverEntries: List<com.zyz4.gkme.model.ControllerDriver> =
        com.zyz4.gkme.model.ControllerDriver.entries

    /** True while the user is picking a game-rumble device from the spinner. */
    internal var gameVibrationUserSelecting = false

    /** True while the user is picking a voice-coil device from the spinner. */
    internal var voiceCoilUserSelecting = false

    /** True while the user is picking a controller-audio device from the spinner. */
    internal var controllerAudioUserSelecting = false

    /** True while the user is picking a gyro source from the spinner. */
    internal var gyroSourceUserSelecting = false

    /** Devices backing the voice-coil spinner. */
    internal var voiceCoilDeviceEntries: List<com.zyz4.gkme.model.AudioDevice> =
        listOf(com.zyz4.gkme.model.AudioDevice.PHONE_MOTOR)

    /** Sources backing the gyro-source spinner. */
    internal var gyroSourceEntries: List<com.zyz4.gkme.model.GyroSource> =
        listOf(com.zyz4.gkme.model.GyroSource.PHONE, com.zyz4.gkme.model.GyroSource.NONE)

    // Appearance image pickers
    internal var bgImagePickerLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null
    internal var btnImagePickerLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null
    internal var joyBaseImagePickerLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null
    internal var joyCapImagePickerLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null
    internal var tpImagePickerLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null
    internal var padImagePickerLauncher: androidx.activity.result.ActivityResultLauncher<String>? = null

    // ── Input dispatch ─────────────────────────────────────

    private fun isPhysicalGamepadKey(code: Int): Boolean = code == KeyEvent.KEYCODE_BUTTON_1 ||
        code == KeyEvent.KEYCODE_DPAD_UP ||
        code == KeyEvent.KEYCODE_DPAD_DOWN ||
        code == KeyEvent.KEYCODE_DPAD_LEFT ||
        code == KeyEvent.KEYCODE_DPAD_RIGHT ||
        code == KeyEvent.KEYCODE_BUTTON_A ||
        code == KeyEvent.KEYCODE_BUTTON_B ||
        code == KeyEvent.KEYCODE_BUTTON_X ||
        code == KeyEvent.KEYCODE_BUTTON_Y ||
        code == KeyEvent.KEYCODE_BUTTON_L1 ||
        code == KeyEvent.KEYCODE_BUTTON_R1 ||
        code == KeyEvent.KEYCODE_BUTTON_L2 ||
        code == KeyEvent.KEYCODE_BUTTON_R2 ||
        code == KeyEvent.KEYCODE_BUTTON_SELECT ||
        code == KeyEvent.KEYCODE_BUTTON_START ||
        code == KeyEvent.KEYCODE_BUTTON_THUMBL ||
        code == KeyEvent.KEYCODE_BUTTON_THUMBR ||
        code == KeyEvent.KEYCODE_BUTTON_MODE ||
        code == KeyEvent.KEYCODE_MEDIA_RECORD

    /** True when [event] is a BACK key coming from a gamepad/joystick rather than the
     *  system back key or back gesture. Some controllers report their B button as
     *  KEYCODE_BACK, which would otherwise leave screen-off mode. */
    private fun isGamepadBackEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_BACK) return false
        val source = event.source
        if (source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) return true
        if (source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK) return true
        val device = InputDevice.getDevice(event.deviceId) ?: return false
        return device.sources and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD ||
            device.sources and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // In screen-off mode the gamepad is meant for gameplay: swallow controller
        // BACK events (e.g. the B button) so only the real back key/gesture exits.
        if (isScreenOff && isGamepadBackEvent(event)) return true
        if (isPhysicalGamepadKey(event.keyCode) &&
            physicalControllerHandler.handleKeyEvent(event)) {
            syncPhysicalControllerState()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && physicalControllerHandler.handleKeyEvent(event)) {
            syncPhysicalControllerState()
            return true
        }
        val preset = viewModel.currentPreset.value
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                if (preset.volumeUpBits.isNotEmpty()) {
                    viewModel.onVolumeKeyDown(preset.volumeUpBits)
                    return true
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (preset.volumeDownBits.isNotEmpty()) {
                    viewModel.onVolumeKeyDown(preset.volumeDownBits)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (event != null && physicalControllerHandler.handleKeyEvent(event)) {
            syncPhysicalControllerState()
            return true
        }
        val preset = viewModel.currentPreset.value
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                if (preset.volumeUpBits.isNotEmpty()) {
                    viewModel.onVolumeKeyUp(preset.volumeUpBits)
                    return true
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (preset.volumeDownBits.isNotEmpty()) {
                    viewModel.onVolumeKeyUp(preset.volumeDownBits)
                    return true
                }
            }
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent?): Boolean {
        if (event != null && physicalControllerHandler.handleMotionEvent(event)) {
            syncPhysicalControllerState()
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun dispatchTouchEvent(event: MotionEvent?): Boolean {
        if (event != null && event.device?.vendorId == 0x054c &&
            physicalControllerHandler.handleMotionEvent(event)) {
            syncPhysicalControllerState()
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    internal fun syncPhysicalControllerState() {
        val state = physicalControllerHandler.controllerState.value
        val connected = physicalControllerHandler.isConnected.value
        val stickX = if (connected) state.leftStickX else 0
        val stickY = if (connected) state.leftStickY else 0
        val rStickX = if (connected) state.rightStickX else 0
        val rStickY = if (connected) state.rightStickY else 0
        val lTrigger = if (connected) state.leftTrigger else 0
        val rTrigger = if (connected) state.rightTrigger else 0

        viewModel.onPhysicalControllerInput(
            state.buttons,
            stickX, stickY,
            rStickX, rStickY,
            lTrigger, rTrigger,
            state.dpad,
            state.touchpadX, state.touchpadY,
            state.touchpadTouch, state.touchpadClick,
            state.touches,
        )
    }

    // ── Toast ──────────────────────────────────────────────

    internal fun showToast(msg: String) {
        CustomDialog.showToast(this, msg)
    }

    // ── Screen off mode ────────────────────────────────────

    /** Enters screen-off mode: the screen is covered with pure black while the invisible
     *  touch gamepad keeps working. The settings button is disabled until the user leaves
     *  with the back key or back gesture. */
    internal fun enterScreenOffMode() {
        val a = this
        if (a.isScreenOff || a.gamepadLayout.isEditModeActive()) return
        if (a.inSettings) a.hideSettings()
        a.isScreenOff = true
        a.findViewById<View>(R.id.screenOffOverlay).visibility = View.VISIBLE
        a.setSettingsButtonEnabled(false)
        // Force the screen on while in screen-off mode, regardless of the user setting.
        a.window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        a.showToast("Use o botão ou gesto Voltar para sair")
    }

    internal fun exitScreenOffMode() {
        val a = this
        if (!a.isScreenOff) return
        a.isScreenOff = false
        a.findViewById<View>(R.id.screenOffOverlay).visibility = View.GONE
        a.setSettingsButtonEnabled(true)
        // Restore the user's own keep-screen-on preference.
        if (a.viewModel.settings.value.keepScreenOn) {
            a.window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            a.window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    internal fun setSettingsButtonEnabled(enabled: Boolean) {
        val a = this
        for (i in 0 until a.gamepadLayout.childCount) {
            val child = a.gamepadLayout.getChildAt(i)
            if (child.tag == GamepadLayout.SETTINGS_BUTTON_ID) {
                child.isEnabled = enabled
                child.isClickable = enabled
            }
        }
    }

    // ── Haptic ─────────────────────────────────────────────
internal fun performHaptic(isPress: Boolean) {
        val s = viewModel.settings.value
        val type = if (isPress) s.vibrationPressType else s.vibrationReleaseType
        when (type) {
            VibrationType.NONE -> return
            VibrationType.VIEW -> {
                val effect = if (isPress) s.vibrationPressViewEffect else s.vibrationReleaseViewEffect
                // 启用高清震动后，RichTap 动态效果会占用马达，导致系统 performHapticFeedback()
                // 失效；因此用 RichTap 预置效果（PrebakedEffect）替换系统效果，HD 不可用时回退。
                if (PhoneHdHaptics.playPrebaked(effect.prebakedId)) return
                gamepadLayout.performHapticFeedback(hapticEffectToConstant(effect))
            }
            VibrationType.VIBRATION_EFFECT -> {
                val duration = (if (isPress) s.vibrationPressDuration else s.vibrationReleaseDuration).coerceAtLeast(1)
                val intensity = if (isPress) s.vibrationPressIntensity else s.vibrationReleaseIntensity
                val frequency = if (isPress) s.vibrationPressFrequency else s.vibrationReleaseFrequency
                if (PhoneHdHaptics.playEffect(intensity, duration, frequency)) return
                val effect = VibrationEffect.createOneShot(duration.toLong(), intensity.coerceIn(0, 255))
                vibrator.cancel()
                vibrator.vibrate(effect)
            }
        }
    }

    internal fun hapticEffectToConstant(effect: HapticEffect): Int {
        val fallback = HapticFeedbackConstants.KEYBOARD_TAP
        return when (effect) {
            HapticEffect.KEYBOARD_TAP -> HapticFeedbackConstants.KEYBOARD_TAP
            HapticEffect.CONFIRM -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.CONFIRM else fallback
            HapticEffect.REJECT -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.REJECT else fallback
            HapticEffect.CLOCK_TICK -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.CLOCK_TICK else fallback
            HapticEffect.CONTEXT_CLICK -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.CONTEXT_CLICK else fallback
            HapticEffect.LONG_PRESS -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.LONG_PRESS else fallback
            HapticEffect.KEYBOARD_PRESS -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.KEYBOARD_PRESS else fallback
            HapticEffect.KEYBOARD_RELEASE -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.KEYBOARD_RELEASE else fallback
            HapticEffect.GESTURE_START -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.GESTURE_START else fallback
            HapticEffect.GESTURE_END -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.GESTURE_END else fallback
            HapticEffect.VIRTUAL_KEY -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.VIRTUAL_KEY else fallback
            HapticEffect.VIRTUAL_KEY_RELEASE -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.VIRTUAL_KEY_RELEASE else fallback
        }
    }

    /** Drives the phone motors for adaptive-trigger conversion. Left/right map to the two
     *  actuators when the device exposes multiple vibrators, otherwise the loudest side is used.
     *  [leftFrequencyHz]/[rightFrequencyHz] are each trigger's native cycling frequency (0 when
     *  unspecified); the phone LRA is a single actuator so the louder side's rate is used. */
    internal fun vibratePhoneForAdaptive(
        left: Int,
        right: Int,
        leftFrequencyHz: Double = 0.0,
        rightFrequencyHz: Double = 0.0,
    ) {
        val l = left.coerceIn(0, 255)
        val r = right.coerceIn(0, 255)
        if (l <= 0 && r <= 0) {
            phoneHdAdaptiveOwned = false
            PhoneHdHaptics.stop(HapticSource.ADAPTIVE_TRIGGER)
            try { vibrator.cancel() } catch (_: Exception) {}
            return
        }
        val frequencyHz = if (l >= r) {
            if (leftFrequencyHz > 0.0) leftFrequencyHz else rightFrequencyHz
        } else {
            if (rightFrequencyHz > 0.0) rightFrequencyHz else leftFrequencyHz
        }
        // The fallback path below drives the same system Vibrator that RichTap HD uses.
        // Clear its residue *before* submitting HD: the HD effect is committed synchronously
        // by playMotors(), so cancelling afterwards raced and dropped the first frame.
        if (!phoneHdAdaptiveOwned) {
            try { vibrator.cancel() } catch (_: Exception) {}
        }
        if (PhoneHdHaptics.playMotors(l, r, frequencyHz, HapticSource.ADAPTIVE_TRIGGER)) {
            phoneHdAdaptiveOwned = true
            return
        }
        phoneHdAdaptiveOwned = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            val ids = vm?.vibratorIds
            if (vm != null && ids != null && ids.size >= 2) {
                try {
                    vm.cancel()
                    val combo = android.os.CombinedVibration.startParallel()
                    if (l > 0) combo.addVibrator(ids[0], VibrationEffect.createOneShot(60000, l))
                    if (r > 0) combo.addVibrator(ids[1], VibrationEffect.createOneShot(60000, r))
                    vm.vibrate(combo.combine())
                } catch (_: Exception) {}
                return
            }
        }
        try {
            vibrator.cancel()
            vibrator.vibrate(VibrationEffect.createOneShot(60000, maxOf(l, r)))
        } catch (_: Exception) {}
    }

    /** Drives the adaptive-trigger target controller's grip haptics. Controllers with native
     *  HD rumble (Switch Pro / Pro 2) or voice-coil audio haptics (DualSense) receive each
     *  trigger's own native frequency through [audioPlaybackService]; anything else falls back to
     *  the amplitude-only motor path. The DualSense voice coil also synthesises a tone for
     *  effects that carry no native frequency (Feedback/Weapon/Bow), at a default rate. */
    internal fun vibrateControllerForAdaptive(
        controllerIndex: Int,
        left: Int,
        right: Int,
        leftFrequencyHz: Double = 0.0,
        rightFrequencyHz: Double = 0.0,
    ) {
        val l = left.coerceIn(0, 255)
        val r = right.coerceIn(0, 255)
        if (l <= 0 && r <= 0) {
            physicalControllerHandler.setAdaptiveTriggerActive(controllerIndex, false)
            audioPlaybackService.clearAdaptiveTriggerHaptic()
            physicalControllerHandler.setControllerMotorsVibration(controllerIndex, 0, 0)
            return
        }
        val supportsHd = physicalControllerHandler.controllerSupportsHdRumble(controllerIndex)
        val supportsVc = physicalControllerHandler.controllerSupportsVoiceCoilPcm(controllerIndex)
        // A voice-coil target (DualSense, USB driver) can synthesise a tone even without a
        // native frequency, so it always takes the PCM path; HD rumble still needs the rate.
        if (supportsVc || ((leftFrequencyHz > 0.0 || rightFrequencyHz > 0.0) && supportsHd)) {
            // The trigger's HD/voice-coil output takes priority over the game's motor rumble.
            physicalControllerHandler.setAdaptiveTriggerActive(controllerIndex, true)
            audioPlaybackService.setAdaptiveTriggerHaptic(
                controllerIndex, l, r, leftFrequencyHz, rightFrequencyHz,
            )
        } else {
            physicalControllerHandler.setAdaptiveTriggerActive(controllerIndex, false)
            audioPlaybackService.clearAdaptiveTriggerHaptic()
            physicalControllerHandler.setControllerMotorsVibration(controllerIndex, l, r)
        }
    }

    // ── Chip Group ─────────────────────────────────────────

    /** Applies appearance only when the settings actually changed, to skip redundant
     *  full-tree restyles when opening/closing settings or on duplicate emissions. */
    internal fun applyAppearanceIfChanged(settings: AppSettings) {
        if (lastAppliedSettings != settings) {
            gamepadLayout.applyAppearance(settings)
            lastAppliedSettings = settings
        }
    }

    internal fun selectChipGroup(ids: List<Int>, selected: Int) {
        ids.forEachIndexed { i, id ->
            findViewById<Button>(id).setBackgroundResource(
                if (i == selected) R.drawable.bg_chip_selected else R.drawable.bg_chip
            )
        }
    }

    // ── Volume mapping helpers ─────────────────────────────

    /** Persists the volume-key remapping into the layout being edited. */
    internal fun updateVolumeBits(volumeUp: List<Int>, volumeDown: List<Int>) {
        gamepadLayout.setVolumeBits(volumeUp, volumeDown)
        viewModel.updatePresetButtons(gamepadLayout.getPreset())
    }

    internal fun populateVolumeMapping(container: LinearLayout) {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        container.removeAllViews()

        container.addView(TextView(this).apply {
            text = "Mapeamento dos botões de volume"
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            textSize = 15f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(12)
        })

        fun currentUp() = gamepadLayout.currentVolumeUpBits
        fun currentDown() = gamepadLayout.currentVolumeDownBits

        container.addView(
            buildVolumeMappingRow(
                label = "Volume +",
                bits = currentUp(),
                density = density,
                onAdd = {
                    showOutputValuePicker(currentUp()) { newBits ->
                        updateVolumeBits(newBits, currentDown())
                        populateVolumeMapping(container)
                    }
                },
                onClear = {
                    updateVolumeBits(emptyList(), currentDown())
                    populateVolumeMapping(container)
                },
                onRemove = { bit ->
                    updateVolumeBits(currentUp() - bit, currentDown())
                    populateVolumeMapping(container)
                },
            ),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(12)
            },
        )

        container.addView(
            buildVolumeMappingRow(
                label = "Volume -",
                bits = currentDown(),
                density = density,
                onAdd = {
                    showOutputValuePicker(currentDown()) { newBits ->
                        updateVolumeBits(currentUp(), newBits)
                        populateVolumeMapping(container)
                    }
                },
                onClear = {
                    updateVolumeBits(currentUp(), emptyList())
                    populateVolumeMapping(container)
                },
                onRemove = { bit ->
                    updateVolumeBits(currentUp(), currentDown() - bit)
                    populateVolumeMapping(container)
                },
            ),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT),
        )
    }

    private fun buildVolumeMappingRow(
        label: String,
        bits: List<Int>,
        density: Float,
        onAdd: () -> Unit,
        onClear: () -> Unit,
        onRemove: (Int) -> Unit,
    ): View {
        fun dp(v: Int) = (v * density).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            textSize = 14f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            rightMargin = dp(8)
        })

        val chips = com.zyz4.gkme.view.FlowLayout(this)
        row.addView(chips, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = dp(8)
        })
        fillVolumeChips(chips, bits, density, onRemove)

        row.addView(Button(this, null, 0, R.style.GamepadChip).apply {
            text = "Adicionar"
            setOnClickListener { onAdd() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)).apply {
            rightMargin = dp(4)
        })

        row.addView(Button(this, null, 0, R.style.GamepadChip).apply {
            text = "Limpar"
            setOnClickListener { onClear() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)))

        return row
    }

    private fun fillVolumeChips(
        container: com.zyz4.gkme.view.FlowLayout,
        bits: List<Int>,
        density: Float,
        onRemove: (Int) -> Unit,
    ) {
        container.removeAllViews()
        if (bits.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "Sem mapeamento"
                setTextColor(-0x777778)
                textSize = 13f
                setPadding(0, (4f * density).toInt(), 0, (4f * density).toInt())
            })
            return
        }
        bits.forEach { bit ->
            container.addView(TextView(this).apply {
                text = BitNameMapper.getBitName(bit)
                setTextColor(-0x1)
                textSize = 11f
                gravity = android.view.Gravity.CENTER
                setBackgroundResource(R.drawable.bg_chip)
                setPadding((6f * density).toInt(), (2f * density).toInt(), (6f * density).toInt(), (2f * density).toInt())
                setOnClickListener { onRemove(bit) }
            }, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }
}
