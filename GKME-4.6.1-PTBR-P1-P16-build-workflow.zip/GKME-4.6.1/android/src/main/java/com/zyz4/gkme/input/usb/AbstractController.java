package com.zyz4.gkme.input.usb;

import com.zyz4.gkme.input.usb.GkmeBridge;

public abstract class AbstractController {

    private final int deviceId;
    private final int vendorId;
    private final int productId;

    private UsbDriverListener listener;

    protected int buttonFlags, supportedButtonFlags;
    protected float leftTrigger, rightTrigger;
    protected float rightStickX, rightStickY;
    protected float leftStickX, leftStickY;
    protected short capabilities;
    protected byte type;
    protected float gyroX, gyroY, gyroZ;
    protected float accelX, accelY, accelZ;
    public int getControllerId() {
        return deviceId;
    }

    public int getVendorId() {
        return vendorId;
    }

    public int getProductId() {
        return productId;
    }

    public int getSupportedButtonFlags() {
        return supportedButtonFlags;
    }

    public short getCapabilities() {
        return capabilities;
    }

    public byte getType() {
        return type;
    }

    protected void setButtonFlag(int buttonFlag, int data) {
        if (data != 0) {
            buttonFlags |= buttonFlag;
        }
        else {
            buttonFlags &= ~buttonFlag;
        }
    }

    protected void reportInput() {
        listener.reportControllerState(deviceId, buttonFlags, leftStickX, leftStickY,
                rightStickX, rightStickY, leftTrigger, rightTrigger);
    }

    public abstract boolean start();
    public abstract void stop();

    // New method to report motion events
    protected void reportMotion() {
        listener.reportControllerMotion(deviceId, GkmeBridge.LI_MOTION_TYPE_GYRO, gyroX, gyroY, gyroZ);
        listener.reportControllerMotion(deviceId, GkmeBridge.LI_MOTION_TYPE_ACCEL, accelX, accelY, accelZ);
    }

    /** Reports one motion sample (used by transport-neutral controllers such as the wireless bridge). */
    protected void notifyControllerMotion(byte motionType, float x, float y, float z) {
        listener.reportControllerMotion(deviceId, motionType, x, y, z);
    }

    /** Reports a battery state/percentage update. */
    protected void notifyBatteryState(byte batteryState, byte batteryPercentage) {
        listener.reportControllerBattery(deviceId, batteryState, batteryPercentage);
    }

    /** True when arrival metadata has been accepted and the driver may emit stateful transitions. */
    protected boolean isControllerReady() {
        return listener.isControllerReady(deviceId);
    }

    /** Reports a touchpad contact without pressure (transport-neutral controllers). */
    protected void notifyControllerTouch(byte eventType, int pointerId, float x, float y) {
        listener.reportControllerTouchpadEvent(deviceId, eventType, pointerId, x, y, 0f);
    }

    /** Reset driver-side touch state after the host has received a cancellation. */
    public void resetTouchState() {
    }

    protected void reportTouchpadEvent(byte eventType, int pointerId, float x, float y, float pressure) {
        listener.reportControllerTouchpadEvent(deviceId, eventType, pointerId, x, y, pressure);
    }

    public AbstractController(int deviceId, UsbDriverListener listener, int vendorId, int productId) {
        this.deviceId = deviceId;
        this.listener = listener;
        this.vendorId = vendorId;
        this.productId = productId;
    }

    public abstract void rumble(short lowFreqMotor, short highFreqMotor);

    public abstract void rumbleTriggers(short leftTrigger, short rightTrigger);

    /**
     * True when this controller exposes natively programmable adaptive triggers
     * (e.g. DualSense). Used to list controller triggers in the adaptive-trigger UI.
     *
     * @return true when adaptive-trigger effects can be applied natively.
     */
    public boolean hasAdaptiveTriggerSupport() {
        return false;
    }

    /**
     * Applies native adaptive-trigger effects when supported by this controller.
     *
     * @param eventFlags Bitmask identifying the triggers to update.
     * @param typeLeft Left trigger effect type.
     * @param typeRight Right trigger effect type.
     * @param left Left trigger effect payload.
     * @param right Right trigger effect payload.
     */
    public void setAdaptiveTriggerEffects(byte eventFlags, byte typeLeft, byte typeRight,
                                          byte[] left, byte[] right) {
    }

    /**
     * Sets the controller RGB LED when supported.
     *
     * @param red Red component.
     * @param green Green component.
     * @param blue Blue component.
     */
    public void setControllerLED(byte red, byte green, byte blue) {
    }

    /**
     * Sets the controller player indicator LEDs when supported.
     *
     * @param playerIndicator Native controller LED bitmask.
     */
    public void setPlayerIndicator(byte playerIndicator) {
    }

    /**
     * True when this controller exposes native HD rumble (Nintendo Switch family).
     * When set, {@link #setHdRumble} drives the linear actuators with per-band
     * frequency and amplitude instead of the amplitude-only {@link #rumble} path.
     */
    public boolean hasHdRumbleSupport() {
        return false;
    }

    /**
     * Drives both linear actuators with HD rumble bands.
     *
     * @param leftHighFreq  left high-band frequency in Hz.
     * @param leftHighAmp   left high-band amplitude, 0..1.
     * @param leftLowFreq   left low-band frequency in Hz.
     * @param leftLowAmp    left low-band amplitude, 0..1.
     * @param rightHighFreq right high-band frequency in Hz.
     * @param rightHighAmp  right high-band amplitude, 0..1.
     * @param rightLowFreq  right low-band frequency in Hz.
     * @param rightLowAmp   right low-band amplitude, 0..1.
     */
    public void setHdRumble(float leftHighFreq, float leftHighAmp,
                            float leftLowFreq, float leftLowAmp,
                            float rightHighFreq, float rightHighAmp,
                            float rightLowFreq, float rightLowAmp) {
    }

    public boolean hasAdvancedAudioHapticsSupport() {
        return false;
    }

    public boolean startAdvancedAudioHaptics() {
        return false;
    }

    public void stopAdvancedAudioHaptics() {
    }

    public boolean isAdvancedAudioHapticsActive() {
        return false;
    }

    public boolean submitAdvancedAudioHapticsFrame(byte[] frame, float intensityGain) {
        return false;
    }

    /**
     * Submits authored controller PCM without resampling or channel remapping.
     *
     * @param frame Interleaved four-channel, 48 kHz, signed 16-bit little-endian PCM.
     * @return true when queued for the controller USB audio endpoint.
     */
    public boolean submitNativeAudioHapticsFrame(byte[] frame) {
        return false;
    }

    protected void notifyDeviceRemoved() {
        listener.deviceRemoved(this);
    }

    protected void notifyDeviceAdded() {
        listener.deviceAdded(this);
    }

    /**
     * True when this controller exposes physical back (paddle) buttons. The USB backend uses
     * this to advertise the paddle remapping inputs, matching the SDL3 backend.
     */
    public boolean hasPaddleSupport() {
        return false;
    }

    public void sendCommand(byte[] data){};
}
