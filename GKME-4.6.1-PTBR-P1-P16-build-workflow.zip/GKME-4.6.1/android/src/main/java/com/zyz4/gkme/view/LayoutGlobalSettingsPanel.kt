package com.zyz4.gkme.view

import android.content.Context
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.zyz4.gkme.CATEGORY_SWITCH_DURATION
import com.zyz4.gkme.PAGE_SWITCH_OFFSET_DP
import com.zyz4.gkme.R
import com.zyz4.gkme.easeOutQuint
import com.zyz4.gkme.input.SensitivityCurve
import com.zyz4.gkme.model.GyroActivateMode
import com.zyz4.gkme.model.GyroBaseDirection
import com.zyz4.gkme.model.GyroCoordinateSystem
import com.zyz4.gkme.model.GyroMode
import com.zyz4.gkme.model.GyroOrientation
import com.zyz4.gkme.model.LayoutPreset
import com.zyz4.gkme.model.PhysicalInputs
import com.zyz4.gkme.model.PhysicalStickSettings

/**
 * Full-screen, per-layout "全局设置" page opened from the layout editor.
 *
 * Mirrors the structure of the app-level settings panel (left category sidebar +
 * right content) but only acts on the layout preset currently being edited. The
 * whole page is rendered at 80% opacity so the gamepad layout stays faintly
 * visible behind it.
 */
class LayoutGlobalSettingsPanel(context: Context) : FrameLayout(context) {

    interface Listener {
        fun onClose()
        fun onGyroOrientationChanged(orientation: GyroOrientation?)
        fun onGyroBaseDirectionChanged(direction: GyroBaseDirection)
        fun onGyroCoordinateSystemChanged(coordinateSystem: GyroCoordinateSystem)
        fun onGyroModeChanged(mode: GyroMode)
        fun onGyroModeSensitivityChanged(value: Int)
        fun onGyroDeadZoneChanged(value: Int)
        fun onGyroReverseDeadZoneChanged(value: Int)
        fun onGyroStickCurveChanged(curve: List<Float>?)
        fun onGyroActivateModeChanged(mode: GyroActivateMode)
        fun onPopulatePhysicalMapping(container: LinearLayout)
        fun onPopulateVolumeMapping(container: LinearLayout)
        fun onPhysicalStickSettingsChanged(left: PhysicalStickSettings, right: PhysicalStickSettings)
    }

    var listener: Listener? = null

    /** Page opacity: 80% opaque so the layout behind remains faintly visible. */
    private val pageAlpha = 0.8f

    private var gyroOrientation: GyroOrientation? = null
    private var gyroBaseDirection = GyroBaseDirection.VERTICAL
    private var gyroCoordinateSystem = GyroCoordinateSystem.YAW_ROLL
    private var gyroMode = GyroMode.HANDHELD
    private var gyroModeSensitivity = 20
    private var gyroDeadZone = 0
    private var gyroReverseDeadZone = 0
    private var gyroStickCurve: List<Float>? = null
    private var gyroActivateMode = GyroActivateMode.ALWAYS
    private var physicalLeftStick = PhysicalStickSettings()
    private var physicalRightStick = PhysicalStickSettings()

    private var contentContainer: LinearLayout? = null
    private var physicalContainer: LinearLayout? = null
    private var volumeContainer: LinearLayout? = null
    private var gyroScroll: ScrollView? = null
    private var physicalScroll: ScrollView? = null
    private var volumeScroll: ScrollView? = null
    private var tabButtons: List<Button> = emptyList()
    private val tabButtonDrawables = mutableMapOf<Button, SidebarItemDrawable>()
    private val tabButtonAnimators = mutableMapOf<Button, AnimatorSet>()
    private var currentTab = 0
    private var physicalDirty = true
    private var volumeDirty = true
    private var gyroAdvancedContainer: LinearLayout? = null
    private var gyroCoordinateSystemSpinner: Spinner? = null
    private var gyroBaseDirectionSpinner: Spinner? = null
    private var gyroBaseDirectionLabel: TextView? = null
    private var gyroStickCurveContainer: LinearLayout? = null
    private var gyroStickCurveView: CurveEditorView? = null
    private var curveZoom: CurveZoomOverlay? = null

    private val baseDirectionValues = listOf(
        GyroBaseDirection.VERTICAL,
        GyroBaseDirection.HORIZONTAL,
    )

    private val coordinateSystemValues = listOf(
        GyroCoordinateSystem.YAW,
        GyroCoordinateSystem.ROLL,
        GyroCoordinateSystem.YAW_ROLL,
        GyroCoordinateSystem.WORLD,
    )

    private val mappingModeValues = listOf(
        GyroMode.HANDHELD,
        GyroMode.MOUSE,
        GyroMode.LEFT_STICK,
        GyroMode.RIGHT_STICK,
        GyroMode.ACCELEROMETER_LEFT_STICK,
        GyroMode.ACCELEROMETER_RIGHT_STICK,
    )

    init {
        visibility = View.GONE
        alpha = 0f
        isClickable = true
        isFocusable = true
        background = ColorDrawable(ColorUtils.setAlphaComponent(Color.BLACK, (pageAlpha * 255).toInt()))
        buildShell()
        curveZoom = CurveZoomOverlay(context).also {
            addView(it, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    // ── Show / hide ─────────────────────────────────────────

    fun showForPreset(
        preset: LayoutPreset,
        baseDirection: GyroBaseDirection,
        coordinateSystem: GyroCoordinateSystem,
    ) {
        bindFromPreset(preset, baseDirection, coordinateSystem)
        animate().cancel()
        alpha = 0f
        visibility = View.VISIBLE
        animate()
            .alpha(1f)
            .setDuration(SHOW_DURATION_MS)
            .setInterpolator(easeOutQuint())
            .withEndAction { prebuildMappingTabs() }
            .start()
    }

    /**
     * Builds the two mapping tabs ahead of time (split across frames) so that when the user
     * switches to them the views are already cached and the page-switch animation can run
     * without any view creation blocking it. Runs after the open fade-in to keep that smooth.
     */
    private fun prebuildMappingTabs() {
        if (currentTab != 0) return
        post {
            populateTab(1)
            post { populateTab(2) }
        }
    }

    fun hide(onEnd: (() -> Unit)? = null) {
        animate().cancel()
        animate()
            .alpha(0f)
            .setDuration(HIDE_DURATION_MS)
            .setInterpolator(easeOutQuint())
            .withEndAction {
                visibility = View.GONE
                alpha = 1f
                onEnd?.invoke()
            }
            .start()
    }

    private fun bindFromPreset(
        preset: LayoutPreset,
        baseDirection: GyroBaseDirection,
        coordinateSystem: GyroCoordinateSystem,
    ) {
        gyroOrientation = preset.gyroOrientation
        gyroBaseDirection = baseDirection
        gyroCoordinateSystem = coordinateSystem
        gyroMode = preset.gyroMode ?: GyroMode.HANDHELD
        gyroModeSensitivity = preset.gyroModeSensitivity ?: 20
        gyroDeadZone = preset.gyroDeadZone ?: 0
        gyroReverseDeadZone = preset.gyroReverseDeadZone ?: 0
        gyroStickCurve = preset.gyroStickCurve
        gyroActivateMode = preset.gyroActivateMode ?: GyroActivateMode.ALWAYS
        physicalLeftStick = preset.leftStickSettings ?: PhysicalStickSettings()
        physicalRightStick = preset.rightStickSettings ?: PhysicalStickSettings()
        hideCurveOverlay()
        physicalContainer?.removeAllViews()
        volumeContainer?.removeAllViews()
        physicalDirty = true
        volumeDirty = true
        rebuildContent()
        selectTab(0)
    }

    /** Repopulates whichever tab is currently visible (used after external state changes). */
    fun refreshCurrentTab() {
        physicalDirty = true
        volumeDirty = true
        populateTab(currentTab)
    }

    private fun selectTab(index: Int, animate: Boolean = false) {
        val pages = listOfNotNull(gyroScroll, physicalScroll, volumeScroll)
        val oldPage = pages.getOrNull(currentTab)
        val newPage = pages.getOrNull(index)
        currentTab = index
        animateTabHighlights(index, animate)
        if (animate && oldPage != null && newPage != null && oldPage !== newPage) {
            // Animate the switch; building is a no-op when the tab is already cached, otherwise it
            // runs after the animation so view creation never blocks the animation frames.
            animatePageSwitch(pages, oldPage, newPage) { populateTab(index) }
            return
        }
        pages.forEachIndexed { i, page ->
            page.animate().cancel()
            page.translationY = 0f
            page.alpha = 1f
            page.visibility = if (i == index) View.VISIBLE else View.GONE
        }
        populateTab(index)
    }

    /** (Re)builds the mapping list for [index] only when needed, so switching tabs reuses cached views. */
    private fun populateTab(index: Int) {
        when (index) {
            1 -> physicalContainer?.let {
                if (physicalDirty || it.childCount == 0) {
                    physicalDirty = false
                    listener?.onPopulatePhysicalMapping(it)
                }
            }
            2 -> volumeContainer?.let {
                if (volumeDirty || it.childCount == 0) {
                    volumeDirty = false
                    listener?.onPopulateVolumeMapping(it)
                }
            }
        }
    }

    /** Slides the old tab up while fading it out, and the new tab up while fading it in. Mirrors the app settings page switch. */
    private fun animatePageSwitch(pages: List<View>, oldPage: View, newPage: View, onEnd: (() -> Unit)? = null) {
        val offset = PAGE_SWITCH_OFFSET_DP * resources.displayMetrics.density
        pages.forEach { it.animate().cancel() }
        pages.forEach { p ->
            if (p !== oldPage && p !== newPage) {
                p.visibility = View.GONE
                p.translationY = 0f
                p.alpha = 1f
            }
        }
        if (oldPage.visibility == View.VISIBLE) {
            oldPage.animate()
                .translationY(-offset)
                .alpha(0f)
                .setDuration(CATEGORY_SWITCH_DURATION)
                .setInterpolator(easeOutQuint())
                .withEndAction {
                    oldPage.visibility = View.GONE
                    oldPage.translationY = 0f
                    oldPage.alpha = 1f
                }
                .start()
        }
        newPage.visibility = View.VISIBLE
        newPage.translationY = offset
        newPage.alpha = 0f
        newPage.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(CATEGORY_SWITCH_DURATION)
            .setInterpolator(easeOutQuint())
            .withEndAction { onEnd?.invoke() }
            .start()
    }

    /** Wipes the tab highlight from left to right while cross-fading its text color. Mirrors the app settings sidebar. */
    private fun animateTabHighlights(selectedIndex: Int, animate: Boolean) {
        tabButtons.forEachIndexed { i, btn ->
            val drawable = tabButtonDrawables[btn] ?: return@forEachIndexed
            val selected = i == selectedIndex
            val targetFill = if (selected) 1f else 0f
            val targetColor = if (selected) 0xFFFFFFFF.toInt() else 0xFF888888.toInt()
            tabButtonAnimators.remove(btn)?.cancel()
            if (!animate) {
                drawable.fill = targetFill
                drawable.invalidateSelf()
                btn.setTextColor(targetColor)
                return@forEachIndexed
            }
            val fillAnimator = ValueAnimator.ofFloat(drawable.fill, targetFill).apply {
                addUpdateListener { anim ->
                    drawable.fill = anim.animatedValue as Float
                    drawable.invalidateSelf()
                }
            }
            val colorAnimator = ValueAnimator.ofArgb(btn.currentTextColor, targetColor).apply {
                addUpdateListener { anim -> btn.setTextColor(anim.animatedValue as Int) }
            }
            val set = AnimatorSet()
            set.playTogether(fillAnimator, colorAnimator)
            set.duration = CATEGORY_SWITCH_DURATION
            set.interpolator = easeOutQuint()
            set.start()
            tabButtonAnimators[btn] = set
        }
    }

    // ── Shell (sidebar + content) ───────────────────────────

    private fun buildShell() {
        val density = resources.displayMetrics.density
        val sidebarWidth = (120f * density).toInt()

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // ── Left sidebar ──
        val sidebar = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = ColorDrawable(
                ColorUtils.setAlphaComponent(
                    androidx.core.content.ContextCompat.getColor(context, R.color.bg_surface),
                    (pageAlpha * 255).toInt()
                )
            )
            setPadding(0, (16f * density).toInt(), 0, 0)
        }
        root.addView(sidebar, LinearLayout.LayoutParams(sidebarWidth, ViewGroup.LayoutParams.MATCH_PARENT))

        val btnBack = Button(context).apply {
            text = "Voltar"
            gravity = Gravity.CENTER
            setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.text_primary))
            textSize = 13f
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_back, 0, 0, 0)
            compoundDrawablePadding = (4f * density).toInt()
            background = androidx.core.content.ContextCompat.getDrawable(context, R.drawable.bg_sidebar_item)
            stateListAnimator = null
            isSelected = false
            setOnClickListener { listener?.onClose() }
        }
        sidebar.addView(btnBack, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (44f * density).toInt()))

        sidebar.addView(View(context).apply {
            setBackgroundColor(androidx.core.content.ContextCompat.getColor(context, R.color.bg_surface_light))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (1f * density).toInt()).apply {
            topMargin = (8f * density).toInt()
            bottomMargin = (8f * density).toInt()
        })

        fun tabButton(label: String): Button = Button(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.text_secondary))
            textSize = 13f
            val drawable = SidebarItemDrawable()
            tabButtonDrawables[this] = drawable
            background = drawable
            stateListAnimator = null
        }

        val btnGyro = tabButton("陀螺仪")
        val btnPhysical = tabButton("Controle físico")
        val btnVolume = tabButton("音量键")
        tabButtons = listOf(btnGyro, btnPhysical, btnVolume)
        tabButtons.forEach { btn ->
            sidebar.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (48f * density).toInt()))
        }
        btnGyro.setOnClickListener { selectTab(0, animate = true) }
        btnPhysical.setOnClickListener { selectTab(1, animate = true) }
        btnVolume.setOnClickListener { selectTab(2, animate = true) }

        // ── Right content ──
        val contentHost = FrameLayout(context).apply {
            setPadding((16f * density).toInt(), (16f * density).toInt(), (16f * density).toInt(), (16f * density).toInt())
        }
        root.addView(contentHost, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        fun page(): LinearLayout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        fun scroll(content: LinearLayout): ScrollView = ScrollView(context).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            isFillViewport = true
            addView(content)
        }

        contentContainer = page()
        physicalContainer = page()
        volumeContainer = page()
        gyroScroll = scroll(contentContainer!!)
        physicalScroll = scroll(physicalContainer!!)
        volumeScroll = scroll(volumeContainer!!)
        contentHost.addView(gyroScroll)
        contentHost.addView(physicalScroll)
        contentHost.addView(volumeScroll)
        physicalScroll?.visibility = View.GONE
        volumeScroll?.visibility = View.GONE

        addView(root)
    }

    private fun rebuildContent() {
        val container = contentContainer ?: return
        container.removeAllViews()
        gyroAdvancedContainer = null
        gyroCoordinateSystemSpinner = null
        gyroBaseDirectionSpinner = null
        gyroBaseDirectionLabel = null
        gyroStickCurveContainer = null
        gyroStickCurveView = null

        val density = resources.displayMetrics.density

        // ── Gyro orientation ──
        buildGyroSelector(density, container)

        container.addView(View(context).apply {
            background = GradientDrawable().apply { setColor(-0x444445) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (1f * density).toInt()).apply {
            topMargin = (4f * density).toInt()
            bottomMargin = (8f * density).toInt()
        })

        // ── Gyro activation mode ──
        container.addView(sectionLabel("陀螺仪激活方式", density))

        val gyroActivateItems = listOf("Sempre ativado", "Ativar ao pressionar um botão específico")
        val gyroActivateSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, gyroActivateItems).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(gyroActivateMode.ordinal)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    val mode = if (pos == 1) GyroActivateMode.BUTTON else GyroActivateMode.ALWAYS
                    if (mode != gyroActivateMode) {
                        gyroActivateMode = mode
                        listener?.onGyroActivateModeChanged(mode)
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        container.addView(gyroActivateSpinner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4f * density).toInt()
            bottomMargin = (12f * density).toInt()
        })

        // ── Gyro mapping mode ──
        container.addView(sectionLabel("陀螺仪行为", density))

        val modeSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, gyroModeItems).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(mappingModeValues.indexOf(gyroMode).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    val mode = mappingModeValues.getOrNull(pos) ?: GyroMode.HANDHELD
                    if (mode != gyroMode) {
                        gyroMode = mode
                        listener?.onGyroModeChanged(mode)
                    }
                    updateGyroModeVisibility()
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        container.addView(modeSpinner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4f * density).toInt()
            bottomMargin = (12f * density).toInt()
        })

        // ── Advanced settings (hidden for 手柄陀螺仪) ──
        gyroAdvancedContainer = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val advanced = gyroAdvancedContainer!!

        // Gyro base direction
        gyroBaseDirectionLabel = sectionLabel("基准方向", density)
        advanced.addView(gyroBaseDirectionLabel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4f * density).toInt()
            bottomMargin = (2f * density).toInt()
        })

        val baseDirectionItems = listOf("Vertical", "Horizontal")
        gyroBaseDirectionSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, baseDirectionItems).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(baseDirectionValues.indexOf(gyroBaseDirection).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    val direction = baseDirectionValues.getOrNull(pos) ?: GyroBaseDirection.VERTICAL
                    if (direction != gyroBaseDirection) {
                        gyroBaseDirection = direction
                        listener?.onGyroBaseDirectionChanged(direction)
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        advanced.addView(gyroBaseDirectionSpinner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4f * density).toInt()
            bottomMargin = (12f * density).toInt()
        })

        // Gyro coordinate system
        advanced.addView(sectionLabel("坐标系", density))

        val gyroCoordinateSystemItems = listOf("Guinada", "Rolagem", "Guinada + rolagem", "Espaço mundial")
        gyroCoordinateSystemSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, gyroCoordinateSystemItems).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(coordinateSystemValues.indexOf(gyroCoordinateSystem).coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    val coordinateSystem = coordinateSystemValues.getOrNull(pos) ?: GyroCoordinateSystem.YAW_ROLL
                    if (coordinateSystem != gyroCoordinateSystem) {
                        gyroCoordinateSystem = coordinateSystem
                        listener?.onGyroCoordinateSystemChanged(coordinateSystem)
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        advanced.addView(gyroCoordinateSystemSpinner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (4f * density).toInt()
            bottomMargin = (12f * density).toInt()
        })

        // Sensitivity / dead zones
        addSeekbar(advanced, "灵敏度", gyroModeSensitivity, 1, 100) {
            gyroModeSensitivity = it
            listener?.onGyroModeSensitivityChanged(it)
        }

        // Shared sensitivity curve for the gyro / accel -> stick modes.
        gyroStickCurveContainer = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        gyroStickCurveView = buildCurveSection(
            gyroStickCurveContainer!!,
            density,
            gyroStickCurve,
            onChanged = { applyCurve(it, fromOverlay = false) },
            onOverlayChanged = { applyCurve(it, fromOverlay = true) },
        )
        advanced.addView(gyroStickCurveContainer!!)

        addSeekbar(advanced, "陀螺仪死区(%)", gyroDeadZone, 0, 100) {
            gyroDeadZone = it
            listener?.onGyroDeadZoneChanged(it)
        }
        addSeekbar(advanced, "陀螺仪反死区(%)", gyroReverseDeadZone, 0, 100) {
            gyroReverseDeadZone = it
            listener?.onGyroReverseDeadZoneChanged(it)
        }

        container.addView(advanced)
        updateGyroModeVisibility()
    }

    private val gyroModeItems = listOf(
        "Giroscópio do controle", "Giroscópio para mouse", "Giroscópio para câmera no analógico esquerdo", "Giroscópio para câmera no analógico direito",
        "Giroscópio para direção no analógico esquerdo", "Giroscópio para direção no analógico direito",
    )

    private fun sectionLabel(text: String, density: Float): TextView = TextView(context).apply {
        this.text = text
        setTextColor(-0x1)
        textSize = 15f
        setPadding(0, (8f * density).toInt(), 0, 0)
    }

    private fun buildGyroSelector(density: Float, container: LinearLayout) {
        val tv = TextView(context).apply {
            text = "体感握持方向"
            setTextColor(-0x1)
            textSize = 14f
        }
        container.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (6f * density).toInt()
        })

        val items = listOf("不指定", "Paisagem", "Retrato", "Retrato invertido")
        val spinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, items).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection((gyroOrientation?.ordinal?.plus(1)) ?: 0)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    val orientation = when (pos) {
                        1 -> GyroOrientation.LANDSCAPE
                        2 -> GyroOrientation.PORTRAIT
                        3 -> GyroOrientation.PORTRAIT_INVERTED
                        else -> null
                    }
                    if (orientation != gyroOrientation) {
                        gyroOrientation = orientation
                        listener?.onGyroOrientationChanged(orientation)
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        container.addView(spinner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (8f * density).toInt()
        })
    }

    private fun updateGyroModeVisibility() {
        val vis = if (gyroMode != GyroMode.HANDHELD) View.VISIBLE else View.GONE
        gyroAdvancedContainer?.visibility = vis

        val needCoordSystem = gyroMode == GyroMode.MOUSE ||
            gyroMode == GyroMode.LEFT_STICK ||
            gyroMode == GyroMode.RIGHT_STICK
        gyroCoordinateSystemSpinner?.visibility = if (needCoordSystem) View.VISIBLE else View.GONE

        val needBaseDirection = gyroMode == GyroMode.ACCELEROMETER_LEFT_STICK ||
            gyroMode == GyroMode.ACCELEROMETER_RIGHT_STICK
        gyroBaseDirectionSpinner?.visibility = if (needBaseDirection) View.VISIBLE else View.GONE
        gyroBaseDirectionLabel?.visibility = if (needBaseDirection) View.VISIBLE else View.GONE

        // 转鼠标与转摇杆（含加速度计转向）共用同一条灵敏度曲线。
        val needStickCurve = gyroMode == GyroMode.MOUSE ||
            gyroMode == GyroMode.LEFT_STICK ||
            gyroMode == GyroMode.RIGHT_STICK ||
            gyroMode == GyroMode.ACCELEROMETER_LEFT_STICK ||
            gyroMode == GyroMode.ACCELEROMETER_RIGHT_STICK
        gyroStickCurveContainer?.visibility = if (needStickCurve) View.VISIBLE else View.GONE
    }

    /** Routes a curve edit from either the inline editor or the enlarged overlay to both views. */
    private fun applyCurve(list: List<Float>?, fromOverlay: Boolean) {
        gyroStickCurve = list
        listener?.onGyroStickCurveChanged(list)
        if (fromOverlay) gyroStickCurveView?.setFromFlatList(list) else curveZoom?.setCurve(list)
    }

    /**
     * Builds the standard "灵敏度曲线" editor (preset spinner + inline editor + delete/reset/enlarge
     * buttons) into [container]. [onChanged] receives every edit; when the enlarged overlay edits
     * the curve the inline editor is kept in sync.
     */
    private fun buildCurveSection(
        container: LinearLayout,
        density: Float,
        initial: List<Float>?,
        onChanged: (List<Float>?) -> Unit,
        onOverlayChanged: ((List<Float>?) -> Unit)? = null,
    ): CurveEditorView {
        container.addView(sectionLabel("灵敏度曲线", density))
        val presetLabels = listOf("Personalizado") + SensitivityCurve.PRESETS.map { it.label }
        val presetSpinner = Spinner(context).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, presetLabels).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(0)
        }
        container.addView(presetSpinner, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        ).apply { bottomMargin = (4f * density).toInt() })

        val curveView = CurveEditorView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (200f * density).toInt(),
            )
            setFromFlatList(initial)
        }
        curveView.onPointsChanged = { list ->
            onChanged(list)
            presetSpinner.setSelection(0)
        }
        container.addView(curveView)

        val btnRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { bottomMargin = (4f * density).toInt() }
        }
        fun curveButton(label: String, onClick: () -> Unit): Button = Button(context).apply {
            text = label
            setTextColor(-0x1)
            textSize = 12f
            setBackgroundResource(R.drawable.button_flat)
            setOnClickListener { onClick() }
        }
        btnRow.addView(curveButton("删除选中点") { curveView.deleteSelected() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = (4f * density).toInt()
            })
        btnRow.addView(curveButton("重置为直线") {
            curveView.setFromFlatList(null)
            onChanged(null)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            rightMargin = (4f * density).toInt()
        })
        btnRow.addView(curveButton("放大") {
            curveZoom?.show(curveView.flatList()) { list ->
                if (onOverlayChanged != null) {
                    onOverlayChanged(list)
                } else {
                    onChanged(list)
                    curveView.setFromFlatList(list)
                }
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        container.addView(btnRow)

        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position <= 0) return
                val preset = SensitivityCurve.PRESETS[position - 1]
                curveView.setFromFlatList(preset.points)
                onChanged(preset.points)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        return curveView
    }

    // ── Physical-controller stick tuning ────────────────────

    /**
     * Appends the analog shaping controls (dead zone / anti dead zone / curve) for the physical
     * joystick named by [key] into its mapping card, right below the gyro-activation checkbox.
     */
    fun appendStickTuning(container: LinearLayout, key: String) {
        val density = resources.displayMetrics.density
        val isLeft = key == PhysicalInputs.KEY_LEFT_JOYSTICK
        val get: () -> PhysicalStickSettings = if (isLeft) ({ physicalLeftStick }) else ({ physicalRightStick })
        val set: (PhysicalStickSettings) -> Unit =
            if (isLeft) ({ physicalLeftStick = it }) else ({ physicalRightStick = it })

        addSeekbar(container, "Zona morta (%)", get().deadZone, 0, 100) {
            set(get().copy(deadZone = it))
            notifyStickSettings()
        }
        addSeekbar(container, "Zona morta inversa (%)", get().reverseDeadZone, 0, 100) {
            set(get().copy(reverseDeadZone = it))
            notifyStickSettings()
        }
        buildCurveSection(container, density, get().curve, onChanged = { list ->
            set(get().copy(curve = list))
            notifyStickSettings()
        })
    }

    private fun notifyStickSettings() {
        listener?.onPhysicalStickSettingsChanged(physicalLeftStick, physicalRightStick)
    }

    /** True while the enlarged curve editor is covering the page (used to consume the back key). */
    fun isCurveOverlayVisible(): Boolean = curveZoom?.isOverlayVisible == true

    fun hideCurveOverlay() {
        curveZoom?.hide()
    }

    private fun addSeekbar(container: LinearLayout, label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
        val density = resources.displayMetrics.density
        val btnSize = (32f * density).toInt()
        var currentValue = value.coerceIn(min, max)

        var et: EditText? = null
        var seek: SeekBar? = null

        val tv = TextView(context).apply {
            text = label
            setTextColor(-0x444445)
            textSize = 13f
        }

        et = EditText(context).apply {
            setText("$currentValue")
            inputType = InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(-0x444445)
            setBackgroundResource(R.drawable.bg_small_btn)
            setPadding((4f * density).toInt(), 0, (4f * density).toInt(), 0)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT) {
                    val parsed = text.toString().toIntOrNull() ?: currentValue
                    val clamped = parsed.coerceIn(min, max)
                    if (clamped != currentValue) {
                        currentValue = clamped
                        seek?.progress = clamped - min
                        onChange(clamped)
                    }
                    clearFocus()
                }
                false
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val parsed = text.toString().toIntOrNull() ?: currentValue
                    val clamped = parsed.coerceIn(min, max)
                    if (clamped != currentValue) {
                        currentValue = clamped
                        seek?.progress = clamped - min
                        onChange(clamped)
                    }
                }
            }
        }

        val btnMinus = TextView(context).apply {
            text = "-"
            setTextColor(-0x1)
            textSize = 16f
            gravity = Gravity.CENTER
            isClickable = true
            setBackgroundResource(R.drawable.button_flat)
            setOnClickListener {
                val clamped = (currentValue - 1).coerceIn(min, max)
                if (clamped != currentValue) {
                    currentValue = clamped
                    et?.setText("$clamped")
                    seek?.progress = clamped - min
                    onChange(clamped)
                }
            }
        }

        val btnPlus = TextView(context).apply {
            text = "+"
            setTextColor(-0x1)
            textSize = 16f
            gravity = Gravity.CENTER
            isClickable = true
            setBackgroundResource(R.drawable.button_flat)
            setOnClickListener {
                val clamped = (currentValue + 1).coerceIn(min, max)
                if (clamped != currentValue) {
                    currentValue = clamped
                    et?.setText("$clamped")
                    seek?.progress = clamped - min
                    onChange(clamped)
                }
            }
        }

        seek = SeekBar(context).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            this.max = max - min
            progress = currentValue - min
            setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        var p = v.parent
                        while (p != null) {
                            p.requestDisallowInterceptTouchEvent(true)
                            p = p.parent
                        }
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        var p = v.parent
                        while (p != null) {
                            p.requestDisallowInterceptTouchEvent(false)
                            p = p.parent
                        }
                    }
                }
                false
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val newVal = progress + min
                        currentValue = newVal
                        et?.setText("$newVal")
                        onChange(newVal)
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }

        val row1 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        row1.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_VERTICAL
        })
        row1.addView(et, LinearLayout.LayoutParams(0, btnSize, 1f).apply {
            leftMargin = (8f * density).toInt()
            rightMargin = (4f * density).toInt()
        })
        row1.addView(btnMinus, LinearLayout.LayoutParams(btnSize, btnSize).apply { rightMargin = (4f * density).toInt() })
        row1.addView(btnPlus, LinearLayout.LayoutParams(btnSize, btnSize))
        container.addView(row1)

        val row2 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (4f * density).toInt()
            }
        }
        row2.addView(seek)
        container.addView(row2)
    }

    companion object {
        const val SHOW_DURATION_MS = 200L
        const val HIDE_DURATION_MS = 150L
    }
}
