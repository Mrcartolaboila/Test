package com.zyz4.gkme

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zyz4.gkme.data.LayoutRepository
import com.zyz4.gkme.input.AccelSteeringMapper
import com.zyz4.gkme.input.SensitivityCurve
import com.zyz4.gkme.input.SensorHandler
import com.zyz4.gkme.input.StickShaping
import com.zyz4.gkme.input.toProto
import com.zyz4.gkme.model.AudioDevice
import com.zyz4.gkme.model.AppSettings
import com.zyz4.gkme.model.ConnectionMode
import com.zyz4.gkme.model.ControllerDriver
import com.zyz4.gkme.model.DisplayMode
import com.zyz4.gkme.model.FillType
import com.zyz4.gkme.model.GamepadState
import com.zyz4.gkme.model.GyroMode
import com.zyz4.gkme.model.GyroBaseDirection
import com.zyz4.gkme.model.GyroCoordinateSystem
import com.zyz4.gkme.model.GyroOrientation
import com.zyz4.gkme.model.GyroActivateMode
import com.zyz4.gkme.model.GyroSource
import com.zyz4.gkme.model.GyroSourceType
import com.zyz4.gkme.model.gyroMasterEnabledFor
import com.zyz4.gkme.model.ButtonPosition
import com.zyz4.gkme.model.HapticEffect
import com.zyz4.gkme.model.LayoutPreset
import com.zyz4.gkme.model.LedAppearance
import com.zyz4.gkme.model.PhysicalInputs
import com.zyz4.gkme.model.TargetPlatform
import com.zyz4.gkme.model.VirtualGamepadType
import com.zyz4.gkme.model.VibrationDevice
import com.zyz4.gkme.model.TouchPoint
import com.zyz4.gkme.model.VibrationType
import com.zyz4.gkme.service.ConnectionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject
import kotlin.math.round
import kotlin.math.sqrt
import kotlin.time.Duration.Companion.milliseconds

@OptIn(ExperimentalUnsignedTypes::class)
@HiltViewModel
class GkViewModel @Inject constructor(
    val connectionManager: ConnectionManager,
    private val layoutRepository: LayoutRepository,
    app: Application,
) : AndroidViewModel(app) {

    val connectionState = connectionManager.connectionState
    val settings = connectionManager.settings
    val ledState = connectionManager.ledState
    val pairedDeviceName = connectionManager.pairedDeviceName
    val isBluetoothRunning: Boolean get() = connectionManager.isBluetoothRunning

    internal val _gamepadState = MutableStateFlow(GamepadState())
    internal val gamepadState: StateFlow<GamepadState> = _gamepadState

    private val _displayMode = MutableStateFlow(DisplayMode.XBOX)
    val displayMode: StateFlow<DisplayMode> = _displayMode.asStateFlow()

    private val _currentPreset = MutableStateFlow(LayoutPreset())
    val currentPreset: StateFlow<LayoutPreset> = _currentPreset.asStateFlow()

    data class PresetInfo(val name: String, val buttons: List<ButtonPosition>)

    private val _presetInfos = MutableStateFlow<List<PresetInfo>>(emptyList())
    val presetInfos: StateFlow<List<PresetInfo>> = _presetInfos.asStateFlow()

    private val _selectedButtonId = MutableStateFlow<String?>(null)

    private val _gyroDisplay = MutableStateFlow(Triple(0f, 0f, 0f))
    val gyroDisplay: StateFlow<Triple<Float, Float, Float>> = _gyroDisplay.asStateFlow()

    private val _physicalControllerConnected = MutableStateFlow(false)
    val physicalControllerConnected: StateFlow<Boolean> = _physicalControllerConnected.asStateFlow()

    private val sensorHandler = SensorHandler(app)
    private var sendJob: Job? = null
    private var sensorDisplayJob: Job? = null
    private var _gyroActivateCount: Int = 0
    private val _gyroOverrideEnabled = MutableStateFlow(false)
    val gyroOverrideEnabled: StateFlow<Boolean> = _gyroOverrideEnabled.asStateFlow()

    /** Reference angular rate (rad/s) used to normalize the gyro dead zone / reverse dead zone. */
    private val gyroDeadZoneMaxRate = 5f

    private fun updateGyroOverrideFromCount() {
        _gyroOverrideEnabled.value = _gyroActivateCount > 0
    }

    var currentPresetGyroOrientation: GyroOrientation? = null
        set(value) {
            field = value
            val orientation = value ?: settings.value.gyroOrientation
            sensorHandler.gyroOrientation = orientation
        }

    fun setDeviceInverted(inverted: Boolean) {
        sensorHandler.isDeviceInverted = inverted
    }

    fun setPhysicalControllerConnected(connected: Boolean) {
        _physicalControllerConnected.value = connected
    }
    private var _dpadBits = 0
    private var _physicalDpadBits = 0
    private var phoneButtons: UInt = 0u
    private var phoneTouches: List<TouchPoint> = emptyList()
    private var phoneStickX: Short = 0
    private var phoneStickY: Short = 0
    private var phoneRStickX: Short = 0
    private var phoneRStickY: Short = 0
    private var phoneLT: Short = 0
    private var phoneRT: Short = 0
    private var physicalStickX: Short = 0
    private var physicalStickY: Short = 0
    private var physicalRStickX: Short = 0
    private var physicalRStickY: Short = 0
    private var _keyboardModifier = 0u
    private var _keyboardKeys = UShortArray(6)

    // ── Physical-controller remapping ──
    /** Output bits produced by the current physical button mappings. */
    private var physicalMappedButtonBits: UInt = 0u
    /** Analog trigger values routed through the physical trigger mappings. */
    private var physicalLeftTriggerAnalog: Int = 0
    private var physicalRightTriggerAnalog: Int = 0
    /** Mouse buttons (bit0=LMB, bit1=RMB, bit2=MMB) produced by the physical mappings. */
    private var physicalMappedMouseButtons: Int = 0
    /** Keyboard scan codes currently emitted by the physical button mappings. */
    private var physicalMappedKbCodes: List<Int> = emptyList()
    /** Whether any physical input currently asks to activate the gyro. */
    private var physicalGyroActive = false

    private val _keyboardShiftActive = MutableStateFlow(false)
    val keyboardShiftActive: StateFlow<Boolean> = _keyboardShiftActive.asStateFlow()

    var onHapticFeedbackPress: (() -> Unit)? = null
    var onHapticFeedbackRelease: (() -> Unit)? = null

    init {
        // ConnectionManager 异步加载持久化设置；在加载完成前 settings 仍是默认值，
        // 若此时初始化会把默认设置写回持久化，覆盖用户配置。故等待加载完成再初始化。
        viewModelScope.launch {
            connectionManager.settingsLoaded.first { it }
            applyInitialSettings()
        }
    }

    private fun applyInitialSettings() {
        _displayMode.value = settings.value.displayMode
        initializeLayouts()
        if (settings.value.gyroEnabled) {
            startSensorDisplay()
        }
        // 启动时如果外观颜色绑定了LED，立即同步初始LED颜色
        if (settings.value.ledBoundColors.isNotEmpty()) {
            val updated = LedAppearance.applyLedColor(settings.value, 0)
            if (updated != settings.value) {
                connectionManager.updateSettings(updated)
            }
        }
    }

    private fun initializeLayouts() {
        val name = settings.value.currentPresetName
        val loaded = layoutRepository.loadPreset(name)
        if (loaded != null) {
            _currentPreset.value = loaded
        } else {
            val presets = layoutRepository.listPresets()
            if (presets.isNotEmpty()) {
                val first = layoutRepository.loadPreset(presets[0])
                if (first != null) {
                    _currentPreset.value = first
                    connectionManager.updateSettings(
                        settings.value.copy(currentPresetName = presets[0])
                    )
                }
            }
        }
        refreshPresetList()
    }

    private fun refreshPresetList() {
        _presetInfos.value = layoutRepository.listPresets().map { name ->
            val preset = layoutRepository.loadPreset(name)
            PresetInfo(name = name, buttons = preset?.buttons ?: emptyList())
        }
    }

    fun isBuiltInPreset(name: String): Boolean = layoutRepository.isBuiltInPreset(name)

    /**
     * 将指定内置预设恢复为出厂内置内容，覆盖用户此前的修改。
     * 若当前正选中该预设，则同步刷新界面上的布局。
     */
    fun restoreBuiltInPreset(name: String): LayoutPreset? {
        val fresh = layoutRepository.reloadBuiltInPreset(name) ?: return null
        layoutRepository.savePreset(name, fresh)
        refreshPresetList()
        if (settings.value.currentPresetName == name) {
            _currentPreset.value = fresh
        }
        return fresh
    }

    fun loadPreset(name: String): Boolean {
        val loaded = layoutRepository.loadPreset(name) ?: return false
        _currentPreset.value = loaded
        connectionManager.updateSettings(settings.value.copy(currentPresetName = name))
        return true
    }

    fun savePreset(name: String, preset: LayoutPreset) {
        val existingPresets = layoutRepository.listPresets()
        var finalName = name
        if (finalName in existingPresets) {
            var suffix = 1
            while ("${finalName}_${suffix}" in existingPresets) suffix++
            finalName = "${finalName}_${suffix}"
        }
        _currentPreset.value = preset
        layoutRepository.savePreset(finalName, preset)
        connectionManager.updateSettings(settings.value.copy(currentPresetName = finalName))
        refreshPresetList()
    }

    fun saveCurrentPreset(preset: LayoutPreset) {
        val name = settings.value.currentPresetName
        _currentPreset.value = preset
        layoutRepository.savePreset(name, preset)
        refreshPresetList()
    }

    fun deletePreset(name: String) {
        if (layoutRepository.isBuiltInPreset(name)) return
        layoutRepository.deletePreset(name)
        refreshPresetList()
        val current = settings.value.currentPresetName
        if (current == name) {
            val presets = layoutRepository.listPresets()
            if (presets.isNotEmpty()) {
                loadPreset(presets[0])
            }
        }
    }

    fun renamePreset(oldName: String, newName: String) {
        if (layoutRepository.isBuiltInPreset(oldName)) return
        layoutRepository.renamePreset(oldName, newName)
        refreshPresetList()
        if (settings.value.currentPresetName == oldName) {
            connectionManager.updateSettings(settings.value.copy(currentPresetName = newName))
        }
    }

    fun updatePresetButtons(preset: LayoutPreset) {
        _currentPreset.value = preset
    }

    fun applyLayoutGyroSettings(preset: LayoutPreset) {
        // 切换布局时旧 View 会被销毁，若陀螺仪激活按钮正被按住，其抬起事件不会再到达，
        // 计数器会泄漏并让陀螺仪一直处于激活状态，故在应用新布局时归零。
        _gyroActivateCount = 0
        updateGyroOverrideFromCount()
        preset.gyroOrientation?.let {
            currentPresetGyroOrientation = it
        }
        preset.gyroActivateMode?.let {
            val updated = settings.value.copy(gyroActivateMode = it)
            connectionManager.updateSettings(updated)
        }
        preset.gyroMode?.let {
            val updated = settings.value.copy(gyroMode = it)
            connectionManager.updateSettings(updated)
        }
        preset.gyroModeSensitivity?.let {
            val updated = settings.value.copy(gyroModeSensitivity = it)
            connectionManager.updateSettings(updated)
        }
        preset.gyroDeadZone?.let {
            val updated = settings.value.copy(gyroDeadZone = it)
            connectionManager.updateSettings(updated)
        }
        preset.gyroReverseDeadZone?.let {
            val updated = settings.value.copy(gyroReverseDeadZone = it)
            connectionManager.updateSettings(updated)
        }
        if (settings.value.gyroStickCurve != preset.gyroStickCurve) {
            connectionManager.updateSettings(settings.value.copy(gyroStickCurve = preset.gyroStickCurve))
        }
    }

    fun setSelectedButtonId(id: String?) {
        _selectedButtonId.value = id
    }

    fun updateDisplayMode(mode: DisplayMode) {
        connectionManager.updateSettings(settings.value.copy(displayMode = mode))
        _displayMode.value = mode
    }

    fun updateConnectionMode(mode: ConnectionMode) {
        connectionManager.updateSettings(settings.value.copy(connectionMode = mode))
    }

    fun updateControlType(type: com.zyz4.gkme.model.ControlType) {
        connectionManager.updateSettings(settings.value.copy(controlType = type))
    }

    fun updatePollingRate(rate: Int) {
        connectionManager.updateSettings(settings.value.copy(pollingRate = rate))
    }

    fun updateAutoStartEnabled(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(autoStartEnabled = enabled))
    }

    fun updateTargetPlatform(platform: TargetPlatform) {
        connectionManager.updateSettings(settings.value.copy(targetPlatform = platform))
    }

    fun switchTargetPlatform(platform: TargetPlatform) {
        connectionManager.switchTargetPlatform(platform)
    }

    fun updateVirtualGamepadType(type: VirtualGamepadType) {
        connectionManager.updateSettings(settings.value.copy(virtualGamepadType = type))
    }

    fun createDefaultLayout(): LayoutPreset {
        return LayoutPreset()
    }

    fun getServerIp(): String = connectionManager.getAllLocalIpAddresses().joinToString(", ")

    fun getServerIpFirst(): String = connectionManager.getServerIp()

    fun unpairDevice() {
        connectionManager.unpairDevice()
    }

    fun updateEditMode(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(isEditMode = enabled))
    }

    fun updateVibrationPressType(type: VibrationType) {
        connectionManager.updateSettings(settings.value.copy(vibrationPressType = type))
    }

    fun updateVibrationReleaseType(type: VibrationType) {
        connectionManager.updateSettings(settings.value.copy(vibrationReleaseType = type))
    }

    fun updateVibrationPressViewEffect(effect: HapticEffect) {
        connectionManager.updateSettings(settings.value.copy(vibrationPressViewEffect = effect))
    }

    fun updateVibrationReleaseViewEffect(effect: HapticEffect) {
        connectionManager.updateSettings(settings.value.copy(vibrationReleaseViewEffect = effect))
    }

    fun updateVibrationPressDuration(duration: Int) {
        connectionManager.updateSettings(settings.value.copy(vibrationPressDuration = duration))
    }

    fun updateVibrationReleaseDuration(duration: Int) {
        connectionManager.updateSettings(settings.value.copy(vibrationReleaseDuration = duration))
    }

    fun updateVibrationPressIntensity(intensity: Int) {
        connectionManager.updateSettings(settings.value.copy(vibrationPressIntensity = intensity))
    }

    fun updateVibrationReleaseIntensity(intensity: Int) {
        connectionManager.updateSettings(settings.value.copy(vibrationReleaseIntensity = intensity))
    }

    fun updateVibrationPressFrequency(frequency: Int) {
        connectionManager.updateSettings(settings.value.copy(vibrationPressFrequency = frequency))
    }

    fun updateVibrationReleaseFrequency(frequency: Int) {
        connectionManager.updateSettings(settings.value.copy(vibrationReleaseFrequency = frequency))
    }

    fun updateGameVibrationDevice(device: VibrationDevice) {
        val updated = if (_physicalControllerConnected.value) {
            settings.value.copy(gameVibrationDeviceConnected = device)
        } else {
            settings.value.copy(gameVibrationDevice = device)
        }
        connectionManager.updateSettings(updated)
    }

    fun updateSwapPhoneMotors(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(swapPhoneMotors = enabled))
    }

    fun updateSwapControllerMotors(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(swapControllerMotors = enabled))
    }

    fun updateHdVibrationEnabled(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(hdVibrationEnabled = enabled))
    }

    /**
     * Selects the gyro source for the active set (connected or disconnected), writing only
     * to that set so the two are remembered independently.
     */
    fun updateGyroSource(source: GyroSource) {
        val connected = _physicalControllerConnected.value
        val cur = settings.value
        val updated = when (source.type) {
            GyroSourceType.CONTROLLER -> if (connected) cur.copy(
                gyroEnabledConnected = true,
                controllerGyroEnabledConnected = true,
                gyroControllerIndexConnected = source.controllerIndex,
            ) else cur.copy(
                gyroEnabled = true,
                controllerGyroEnabled = true,
                gyroControllerIndex = source.controllerIndex,
            )
            GyroSourceType.PHONE -> if (connected) cur.copy(
                gyroEnabledConnected = true,
                controllerGyroEnabledConnected = false,
            ) else cur.copy(
                gyroEnabled = true,
                controllerGyroEnabled = false,
            )
            GyroSourceType.NONE -> if (connected) cur.copy(
                gyroEnabledConnected = false,
                controllerGyroEnabledConnected = false,
            ) else cur.copy(
                gyroEnabled = false,
                controllerGyroEnabled = false,
            )
        }
        connectionManager.updateSettings(updated)
        refreshGyroLoops(updated, connected)
    }

    private fun refreshGyroLoops(s: AppSettings, connected: Boolean) {
        if (s.gyroMasterEnabledFor(connected) || s.gyroMode != GyroMode.NONE) {
            startSensorDisplay()
            if (s.connectionMode == ConnectionMode.WIFI ||
                s.connectionMode == ConnectionMode.BLUETOOTH ||
                s.connectionMode == ConnectionMode.USB ||
                s.connectionMode == ConnectionMode.LOCAL
            ) {
                startSensorSendLoop()
            }
        } else {
            stopSensorDisplay()
            sendJob?.cancel()
            _gamepadState.value = _gamepadState.value.copy(
                gyroX = 0f, gyroY = 0f, gyroZ = 0f,
                accelX = 0f, accelY = 0f, accelZ = 0f,
            )
            startPeriodicSendLoop()
        }
    }

    fun updateKeepScreenOn(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(keepScreenOn = enabled))
    }

    fun updateFloatingOpacity(opacity: Int) {
        connectionManager.updateSettings(settings.value.copy(floatingOpacity = opacity.coerceIn(0, 100)))
    }

    fun updateFloatingKeepAlive(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(floatingKeepAlive = enabled))
    }

    // ── Physical-controller remapping ──

    fun updateGyroOrientation(orientation: GyroOrientation) {
        val updated = settings.value.copy(gyroOrientation = orientation)
        connectionManager.updateSettings(updated)
        if (currentPresetGyroOrientation == null) {
            sensorHandler.gyroOrientation = orientation
        }
    }

    fun updateGyroMode(mode: GyroMode) {
        val updated = settings.value.copy(gyroMode = mode)
        connectionManager.updateSettings(updated)
        if (settings.value.connectionMode == ConnectionMode.WIFI ||
            settings.value.connectionMode == ConnectionMode.BLUETOOTH ||
            settings.value.connectionMode == ConnectionMode.USB ||
            settings.value.connectionMode == ConnectionMode.LOCAL
        ) {
            if (mode != GyroMode.NONE || settings.value.gyroMasterEnabledFor(_physicalControllerConnected.value)) {
                startSensorSendLoop()
            } else {
                sendJob?.cancel()
                startPeriodicSendLoop()
            }
        }
    }

    fun updateGyroBaseDirection(direction: GyroBaseDirection) {
        val updated = settings.value.copy(gyroBaseDirection = direction)
        connectionManager.updateSettings(updated)
    }

    fun updateGyroCoordinateSystem(coordinateSystem: GyroCoordinateSystem) {
        val updated = settings.value.copy(gyroCoordinateSystem = coordinateSystem)
        connectionManager.updateSettings(updated)
    }

    fun updateGyroModeSensitivity(value: Int) {
        val updated = settings.value.copy(gyroModeSensitivity = value)
        connectionManager.updateSettings(updated)
    }

    fun updateGyroDeadZone(value: Int) {
        val updated = settings.value.copy(gyroDeadZone = value)
        connectionManager.updateSettings(updated)
    }

    fun updateGyroReverseDeadZone(value: Int) {
        val updated = settings.value.copy(gyroReverseDeadZone = value)
        connectionManager.updateSettings(updated)
    }

    fun updateGyroStickCurve(curve: List<Float>?) {
        val updated = settings.value.copy(gyroStickCurve = curve)
        connectionManager.updateSettings(updated)
    }

    fun updateGyroActivateMode(mode: GyroActivateMode) {
        val updated = settings.value.copy(gyroActivateMode = mode)
        connectionManager.updateSettings(updated)
        if (mode == GyroActivateMode.ALWAYS) {
            _gyroActivateCount = 0
            updateGyroOverrideFromCount()
        }
    }

    fun onGyroActivateButtonDown() {
        _gyroActivateCount = _gyroActivateCount + 1
        updateGyroOverrideFromCount()
    }

    fun onGyroActivateButtonUp() {
        _gyroActivateCount = maxOf(0, _gyroActivateCount - 1)
        updateGyroOverrideFromCount()
    }

    fun updateInputControllerIndex(index: Int) {
        connectionManager.updateSettings(settings.value.copy(inputControllerIndex = index))
    }

    fun updateControllerDriver(driver: ControllerDriver) {
        connectionManager.updateSettings(settings.value.copy(controllerDriver = driver))
    }

    fun updateVoiceCoilDevice(device: AudioDevice) {
        val updated = if (_physicalControllerConnected.value) {
            settings.value.copy(voiceCoilDeviceConnected = device)
        } else {
            settings.value.copy(voiceCoilDevice = device)
        }
        connectionManager.updateSettings(updated)
    }

    fun updateSwapVoiceCoilMotors(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(swapVoiceCoilMotors = enabled))
    }

    fun updateAdaptiveTriggerDevice(device: com.zyz4.gkme.model.AdaptiveTriggerDevice) {
        val updated = if (_physicalControllerConnected.value) {
            settings.value.copy(adaptiveTriggerDeviceConnected = device)
        } else {
            settings.value.copy(adaptiveTriggerDevice = device)
        }
        connectionManager.updateSettings(updated)
    }

    fun updateSwapAdaptiveTriggers(enabled: Boolean) {
        connectionManager.updateSettings(settings.value.copy(swapAdaptiveTriggers = enabled))
    }

    fun updateControllerAudioDevice(device: AudioDevice) {
        connectionManager.updateSettings(settings.value.copy(controllerAudioDevice = device))
    }

    // ── Appearance updates ──
    fun updateAppearance(transform: (AppSettings) -> AppSettings) {
        connectionManager.updateSettings(transform(settings.value))
    }

    private var lastAppliedLedColor = Int.MIN_VALUE

    /** Pushes the live controller LED color into every appearance field bound to it. */
    fun applyLedColorToAppearance(ledColor: Int) {
        if (ledColor == lastAppliedLedColor) return
        lastAppliedLedColor = ledColor
        val current = settings.value
        if (current.ledBoundColors.isEmpty()) return
        val updated = LedAppearance.applyLedColor(current, ledColor)
        if (updated != current) updateAppearance { updated }
    }

    fun onPhysicalControllerInput(
        buttons: UInt,
        leftStickX: Short, leftStickY: Short,
        rightStickX: Short, rightStickY: Short,
        leftTrigger: Int, rightTrigger: Int,
        dpad: Int,
        touchpadX: Float = 0f, touchpadY: Float = 0f,
        touchpadTouch: Boolean = false,
        touchpadClick: Boolean = false,
        touches: List<TouchPoint> = emptyList(),
    ) {

        val tx = (touchpadX * 1919).toInt().coerceIn(0, 1919)
        val ty = (touchpadY * 942).toInt().coerceIn(0, 942)
        val hasPhoneTouch = phoneTouches.any { it.active }
        val hasPhoneLT = phoneLT.toInt() > 0
        val hasPhoneRT = phoneRT.toInt() > 0
        val previousPhysicalMouse = physicalMappedMouseButtons
        val stickPreset = _currentPreset.value
        val (shapedLx, shapedLy) = shapePhysicalStick(stickPreset.leftStickSettings, leftStickX, leftStickY)
        val (shapedRx, shapedRy) = shapePhysicalStick(stickPreset.rightStickSettings, rightStickX, rightStickY)
        applyPhysicalMappings(
            buttons, leftTrigger, rightTrigger,
            shapedLx, shapedLy, shapedRx, shapedRy, touchpadTouch,
        )
        val mouseButtonsChanged = physicalMappedMouseButtons != previousPhysicalMouse
        val combinedMouseButtons =
            (_gamepadState.value.mouseButtons and previousPhysicalMouse.inv()) or physicalMappedMouseButtons
        _physicalDpadBits = 0
        if ((physicalMappedButtonBits and GamepadState.DPAD_BIT_UP.toUInt()) != 0u) {
            _physicalDpadBits = _physicalDpadBits or GamepadState.DPAD_UP
        }
        if ((physicalMappedButtonBits and GamepadState.DPAD_BIT_DOWN.toUInt()) != 0u) {
            _physicalDpadBits = _physicalDpadBits or GamepadState.DPAD_DOWN
        }
        if ((physicalMappedButtonBits and GamepadState.DPAD_BIT_LEFT.toUInt()) != 0u) {
            _physicalDpadBits = _physicalDpadBits or GamepadState.DPAD_LEFT
        }
        if ((physicalMappedButtonBits and GamepadState.DPAD_BIT_RIGHT.toUInt()) != 0u) {
            _physicalDpadBits = _physicalDpadBits or GamepadState.DPAD_RIGHT
        }
        val combinedBits = _dpadBits or _physicalDpadBits
        val hatValue = when (combinedBits) {
            0 -> 0
            GamepadState.DPAD_UP -> GamepadState.DPAD_UP
            GamepadState.DPAD_DOWN -> GamepadState.DPAD_DOWN
            GamepadState.DPAD_LEFT -> GamepadState.DPAD_LEFT
            GamepadState.DPAD_RIGHT -> GamepadState.DPAD_RIGHT
            GamepadState.DPAD_UP or GamepadState.DPAD_LEFT -> GamepadState.DPAD_UP_LEFT
            GamepadState.DPAD_UP or GamepadState.DPAD_RIGHT -> GamepadState.DPAD_UP_RIGHT
            GamepadState.DPAD_DOWN or GamepadState.DPAD_LEFT -> GamepadState.DPAD_DOWN_LEFT
            GamepadState.DPAD_DOWN or GamepadState.DPAD_RIGHT -> GamepadState.DPAD_DOWN_RIGHT
            else -> 0
        }
        
        _gamepadState.value = _gamepadState.value.copy(
            buttons = phoneButtons or physicalMappedButtonBits,
            mouseButtons = combinedMouseButtons,
            leftStickX = (phoneStickX.toInt() + shapedLx).coerceIn(-32768, 32767).toShort(),
            leftStickY = (phoneStickY.toInt() + shapedLy).coerceIn(-32768, 32767).toShort(),
            rightStickX = (phoneRStickX.toInt() + shapedRx).coerceIn(-32768, 32767).toShort(),
            rightStickY = (phoneRStickY.toInt() + shapedRy).coerceIn(-32768, 32767).toShort(),
            leftTrigger = if (hasPhoneLT) maxOf(phoneLT.toInt(), physicalLeftTriggerAnalog) else physicalLeftTriggerAnalog,
            rightTrigger = if (hasPhoneRT) maxOf(phoneRT.toInt(), physicalRightTriggerAnalog) else physicalRightTriggerAnalog,
            dpad = hatValue,
            touchpadX = if (hasPhoneTouch) _gamepadState.value.touchpadX else tx,
            touchpadY = if (hasPhoneTouch) _gamepadState.value.touchpadY else ty,
            touchpadTouch = if (hasPhoneTouch) _gamepadState.value.touchpadTouch else touchpadTouch,
            touchpadClick = touchpadClick || hasPhoneTouch,
            touches = if (hasPhoneTouch) phoneTouches else touches,
        )
        physicalStickX = shapedLx.toShort()
        physicalStickY = shapedLy.toShort()
        physicalRStickX = shapedRx.toShort()
        physicalRStickY = shapedRy.toShort()
        if (mouseButtonsChanged && settings.value.connectionMode == ConnectionMode.BLUETOOTH) {
            viewModelScope.launch {
                connectionManager.sendMouseReport(
                    button = effectiveMouseButtons(combinedMouseButtons).toByte(),
                    dx = 0, dy = 0, wheel = 0, hWheel = 0,
                )
            }
        }
    }

    /** Applies the per-layout dead zone / anti dead zone / curve to a raw physical stick vector. */
    private fun shapePhysicalStick(
        settings: com.zyz4.gkme.model.PhysicalStickSettings?,
        x: Short,
        y: Short,
    ): Pair<Int, Int> {
        if (settings == null || settings.isDefault()) return x.toInt() to y.toInt()
        val (sx, sy) = StickShaping.apply(
            x.toFloat(), y.toFloat(), PHYSICAL_STICK_FULL_SCALE,
            settings.deadZone, settings.reverseDeadZone, settings.curve,
        )
        return sx.toInt() to sy.toInt()
    }

    /**
     * Recomputes the outputs produced by the physical-controller mappings for the current input,
     * then applies the delta: the mapped bitmask replaces the raw physical buttons (so a remapped
     * button no longer emits its original output), while mapped keyboard keys and the
     * gyro-activation flag are toggled on the press/release edges.
     *
     * [leftStickX]/[leftStickY]/[rightStickX]/[rightStickY] are the already-shaped stick values, so
     * a joystick only activates the gyro once it has left its configured dead zone.
     */
    private fun applyPhysicalMappings(
        buttons: UInt,
        leftTrigger: Int, rightTrigger: Int,
        leftStickX: Int, leftStickY: Int,
        rightStickX: Int, rightStickY: Int,
        touchpadTouch: Boolean,
    ) {
        val mappings = _currentPreset.value.physicalInputMappings
        var outputBits = 0u
        val kbCodes = LinkedHashSet<Int>()
        var gyroActive = false
        // Analog trigger values are routed by the mapping: a trigger only drives the trigger
        // axis it is mapped to. An unmapped/cleared trigger no longer moves its own axis.
        var leftTriggerAnalog = 0
        var rightTriggerAnalog = 0

        for (input in PhysicalInputs.BUTTONS) {
            val isTrigger = input.key == PhysicalInputs.KEY_LT || input.key == PhysicalInputs.KEY_RT
            val rawTrigger = when (input.key) {
                PhysicalInputs.KEY_LT -> leftTrigger
                PhysicalInputs.KEY_RT -> rightTrigger
                else -> 0
            }
            val mapping = mappings[input.key]
            val outputs = mapping?.outputs ?: input.defaultOutputs

            if (isTrigger) {
                for (out in outputs) {
                    if (out == GamepadState.LT) leftTriggerAnalog = maxOf(leftTriggerAnalog, rawTrigger)
                    if (out == GamepadState.RT) rightTriggerAnalog = maxOf(rightTriggerAnalog, rawTrigger)
                }
            }

            val pressed = when (input.key) {
                PhysicalInputs.KEY_LT -> leftTrigger > PHYSICAL_TRIGGER_MAP_THRESHOLD
                PhysicalInputs.KEY_RT -> rightTrigger > PHYSICAL_TRIGGER_MAP_THRESHOLD
                else -> input.bitMask != 0 && (buttons.toInt() and input.bitMask) != 0
            }
            if (!pressed) continue
            if (mapping?.gyroActivate == true) gyroActive = true
            for (out in outputs) {
                if (out < 0) kbCodes.add(-out) else outputBits = outputBits or out.toUInt()
            }
        }

        for (input in PhysicalInputs.GYRO_ONLY) {
            if (mappings[input.key]?.gyroActivate != true) continue
            // A joystick activates the gyro only once it has left its dead zone: the shaping above
            // outputs exactly 0 while inside the dead zone.
            val active = when (input.key) {
                PhysicalInputs.KEY_LEFT_JOYSTICK -> leftStickX != 0 || leftStickY != 0
                PhysicalInputs.KEY_RIGHT_JOYSTICK -> rightStickX != 0 || rightStickY != 0
                PhysicalInputs.KEY_TOUCHPAD -> touchpadTouch
                else -> false
            }
            if (active) gyroActive = true
        }

        physicalMappedButtonBits = outputBits
        physicalLeftTriggerAnalog = leftTriggerAnalog
        physicalRightTriggerAnalog = rightTriggerAnalog
        var mouseButtons = 0
        val outputBitsInt = outputBits.toInt()
        if ((outputBitsInt and GamepadState.MOUSE_LMB) != 0) mouseButtons = mouseButtons or 1
        if ((outputBitsInt and GamepadState.MOUSE_RMB) != 0) mouseButtons = mouseButtons or 2
        if ((outputBitsInt and GamepadState.MOUSE_MMB) != 0) mouseButtons = mouseButtons or 4
        if ((outputBitsInt and GamepadState.MOUSE_BACK) != 0) mouseButtons = mouseButtons or 8
        if ((outputBitsInt and GamepadState.MOUSE_FORWARD) != 0) mouseButtons = mouseButtons or 16
        physicalMappedMouseButtons = mouseButtons
        syncPhysicalMappedKeyboard(kbCodes.toList())
        if (gyroActive != physicalGyroActive) {
            physicalGyroActive = gyroActive
            if (gyroActive) onGyroActivateButtonDown() else onGyroActivateButtonUp()
        }
    }

    /** Applies the press/release delta of the keyboard keys produced by the physical mappings. */
    private fun syncPhysicalMappedKeyboard(desired: List<Int>) {
        val previous = physicalMappedKbCodes
        for (code in previous) {
            if (code !in desired) onKeyUp(code)
        }
        for (code in desired) {
            if (code !in previous) onKeyDown(code)
        }
        physicalMappedKbCodes = desired
    }

    // Raw (unscaled) controller gyro in rad/s, kept for accelerometer->stick gyro fusion.
    private val controllerGyroRaw = FloatArray(3)

    fun onPhysicalControllerGyro(gyroX: Float, gyroY: Float, gyroZ: Float, accelX: Float, accelY: Float, accelZ: Float) {
        controllerGyroRaw[0] = gyroX
        controllerGyroRaw[1] = gyroY
        controllerGyroRaw[2] = gyroZ
        val s = settings.value
        val (worldDx, worldDy) = SensorHandler.computeWorldDelta(gyroX, gyroY, gyroZ, accelX, accelY, accelZ)
        _gamepadState.value = _gamepadState.value.copy(
            gyroX = gyroX * s.gyroSensitivityX / 100f,
            gyroY = gyroY * s.gyroSensitivityY / 100f,
            gyroZ = gyroZ * s.gyroSensitivityZ / 100f,
            accelX = accelX,
            accelY = accelY,
            accelZ = accelZ,
            mouseDx = 0,
            mouseDy = 0,
        )
        _controllerWorldDx = worldDx
        _controllerWorldDy = worldDy
    }

    private var _controllerWorldDx = 0f
    private var _controllerWorldDy = 0f

    // Fractional carry for gyro->mouse so slow rotation is not truncated to zero (no fixed dead zone).
    private var gyroMouseAccumX = 0f
    private var gyroMouseAccumY = 0f

    // Accelerometer -> stick (steering wheel) mappers; one per sensor source.
    private val phoneAccelMapper = AccelSteeringMapper()
    private val controllerAccelMapper = AccelSteeringMapper()
    private var accelMapperKey: String? = null

    fun startServer() {
        connectionManager.startServer(viewModelScope)
        connectionManager.onMouseReport = { _, dx, dy, wheel, hWheel ->
            // 累加值不再截断到 ±127：快速滑动会在一个发送周期内累计出上百像素，
            // 旧的 ±127 截断会丢弃溢出部分，导致“滑得越快转得越少”。协议字段是
            // sint32，按 Short 范围保留即可，由每个发送周期整体下发。
            // 注意：这里不再写入 mouseButtons，鼠标键位只由 onButtonDown/onButtonUp
            // 与 onMouseGestureButton 维护，避免移动/滚轮包覆盖按住的键。
            _gamepadState.value = _gamepadState.value.copy(
                mouseDx = (dx.toInt() + _gamepadState.value.mouseDx.toInt()).coerceIn(-32768, 32767).toShort(),
                mouseDy = (dy.toInt() + _gamepadState.value.mouseDy.toInt()).coerceIn(-32768, 32767).toShort(),
                mouseWheel = (wheel.toInt() + _gamepadState.value.mouseWheel.toInt()).coerceIn(-32768, 32767).toShort(),
                mousePan = (hWheel.toInt() + _gamepadState.value.mousePan.toInt()).coerceIn(-32768, 32767).toShort(),
            )
        }
        val gyroOn = settings.value.gyroMasterEnabledFor(_physicalControllerConnected.value)
        if (settings.value.connectionMode == ConnectionMode.WIFI ||
            settings.value.connectionMode == ConnectionMode.BLUETOOTH ||
            settings.value.connectionMode == ConnectionMode.USB ||
            settings.value.connectionMode == ConnectionMode.LOCAL
        ) {
            if (gyroOn || settings.value.gyroMode != GyroMode.NONE) {
                startSensorSendLoop()
            } else {
                startPeriodicSendLoop()
            }
        }
        if (gyroOn || settings.value.gyroMode != GyroMode.NONE) {
            startSensorDisplay()
        }
    }

    private fun readBattery() {
        val intent = getApplication<Application>().registerReceiver(null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (intent == null) return
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = (level * 100) / scale
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        _gamepadState.value = _gamepadState.value.copy(
            batteryLevel = pct,
            isCharging = plugged != 0,
        )
    }

    private fun startPeriodicSendLoop() {
        sendJob?.cancel()
        var lastBatteryRead = 0L
        sendJob = CoroutineScope(Dispatchers.IO + SupervisorJob()).launch {
            var nextSendTime = System.currentTimeMillis()
            while (true) {
                if (System.currentTimeMillis() - lastBatteryRead > 2000) {
                    readBattery()
                    lastBatteryRead = System.currentTimeMillis()
                }
                val combinedLx = (phoneStickX.toInt() + physicalStickX.toInt()).coerceIn(-32768, 32767).toShort()
                val combinedLy = (phoneStickY.toInt() + physicalStickY.toInt()).coerceIn(-32768, 32767).toShort()
                val combinedRx = (phoneRStickX.toInt() + physicalRStickX.toInt()).coerceIn(-32768, 32767).toShort()
                val combinedRy = (phoneRStickY.toInt() + physicalRStickY.toInt()).coerceIn(-32768, 32767).toShort()
                val currentState = _gamepadState.value
                val input = currentState.copy(
                    leftStickX = combinedLx,
                    leftStickY = combinedLy,
                    rightStickX = combinedRx,
                    rightStickY = combinedRy,
                ).toProto(
                    keyboardModifier = _keyboardModifier,
                    keyboardKeys = _keyboardKeys.filter { it != 0u.toUShort() }.map { it.toUInt() }
                )
                connectionManager.sendGamepadState(input)
                val pMx = _gamepadState.value.mouseDx
                val pMy = _gamepadState.value.mouseDy
                val pMw = _gamepadState.value.mouseWheel
                val pMp = _gamepadState.value.mousePan
                if (settings.value.connectionMode == ConnectionMode.BLUETOOTH && (pMx != 0.toShort() || pMy != 0.toShort() || pMw != 0.toShort() || pMp != 0.toShort() || _gamepadState.value.mouseButtons != 0)) {
                    viewModelScope.launch {
                        connectionManager.sendMouseReport(
                            button = effectiveMouseButtons().toByte(),
                            dx = pMx,
                            dy = pMy,
                            wheel = pMw,
                            hWheel = pMp,
                        )
                    }
                }
                if (pMx != 0.toShort() || pMy != 0.toShort() || pMw != 0.toShort() || pMp != 0.toShort()) {
                    _gamepadState.value = _gamepadState.value.copy(
                        mouseDx = 0, mouseDy = 0,
                        mouseWheel = 0, mousePan = 0,
                    )
                }
                val intervalMs = round(1000.0 / settings.value.pollingRate).toLong().coerceAtLeast(1L)
                nextSendTime += intervalMs
                val waitTime = nextSendTime - System.currentTimeMillis()
                if (waitTime > 0) {
                    delay(waitTime)
                } else {
                    nextSendTime = System.currentTimeMillis()
                }
            }
        }
    }

    fun stopServer() {
        sendJob?.cancel()
        connectionManager.stopServer()
    }

    /** 更新服务未运行时的状态栏文案（本机模式 Shizuku 授权进度 / 失败）。 */
    fun setLocalModeStatus(text: String) {
        connectionManager.setIdleStatus(text)
    }

    private fun startSensorDisplay() {
        sensorHandler.gyroOrientation = currentPresetGyroOrientation ?: settings.value.gyroOrientation
        sensorHandler.start()
        sensorDisplayJob?.cancel()
        sensorDisplayJob = viewModelScope.launch {
            while (true) {
                val sensor = sensorHandler.sensorData.value
                _gyroDisplay.value = Triple(sensor.gyroX, sensor.gyroY, sensor.gyroZ)
                delay(8)
            }
        }
    }

    private fun stopSensorDisplay() {
        sensorDisplayJob?.cancel()
        sensorDisplayJob = null
        sensorHandler.stop()
    }

    private fun startSensorSendLoop() {
        sendJob?.cancel()
        var lastBatteryRead = 0L
        sendJob = CoroutineScope(Dispatchers.IO + SupervisorJob()).launch {
            var nextSendTime = System.currentTimeMillis()
            var lastAccelNanos = System.nanoTime()
            while (true) {
                if (System.currentTimeMillis() - lastBatteryRead > 2000) {
                    readBattery()
                    lastBatteryRead = System.currentTimeMillis()
                }
                val s = settings.value
                val sensor = sensorHandler.sensorData.value
                _gyroDisplay.value = Triple(sensor.gyroX, sensor.gyroY, sensor.gyroZ)
                val connected = _physicalControllerConnected.value
                val useControllerGyro = if (connected) s.controllerGyroEnabledConnected else s.controllerGyroEnabled
                val actualGyroEnabled = if (s.gyroActivateMode == GyroActivateMode.BUTTON) {
                    _gyroOverrideEnabled.value
                } else {
                    s.gyroMasterEnabledFor(connected)
                }
                if (!useControllerGyro && actualGyroEnabled) {
                    _gamepadState.value = _gamepadState.value.copy(
                        gyroX = sensor.gyroX * s.gyroSensitivityX / 100f,
                        gyroY = sensor.gyroY * s.gyroSensitivityY / 100f,
                        gyroZ = sensor.gyroZ * s.gyroSensitivityZ / 100f,
                        accelX = sensor.accelX,
                        accelY = sensor.accelY,
                        accelZ = sensor.accelZ,
                    )
                }

                // Apply gyro coordinate system transformation
                // sensor.gyroX = 俯仰(Pitch), sensor.gyroY = 偏航(Yaw), sensor.gyroZ = 滚转(Roll)
                // Original mapping: mouseX = -gyroY(Yaw→水平), mouseY = -gyroX(Pitch→垂直)
                // mappedX = 最终输出到水平轴的值, mappedY = 最终输出到垂直轴的值
                val coordinateSystem = s.gyroCoordinateSystem
                val (gx, gy, gz) = if (actualGyroEnabled) {
                    if (!useControllerGyro) {
                        Triple(
                            sensor.gyroX * s.gyroSensitivityX / 100f,
                            sensor.gyroY * s.gyroSensitivityY / 100f,
                            sensor.gyroZ * s.gyroSensitivityZ / 100f
                        )
                    } else {
                        Triple(
                            _gamepadState.value.gyroX,
                            _gamepadState.value.gyroY,
                            _gamepadState.value.gyroZ
                        )
                    }
                } else {
                    Triple(0f, 0f, 0f)
                }

                var mappedX: Float    // 水平 = 偏航yaw (原始默认行为: gyroMx = -gy = -mappedX)
                var mappedY: Float    // 垂直 = 俯仰pitch (原始默认行为: gyroMy = -gx = -mappedY)

                when (coordinateSystem) {
                    GyroCoordinateSystem.YAW -> {
                        mappedX = gy
                        mappedY = gx
                    }
                    GyroCoordinateSystem.ROLL -> {
                        mappedX = -gz
                        mappedY = gx
                    }
                    GyroCoordinateSystem.YAW_ROLL -> {
                        val yawComponent = gy
                        val rollComponent = -gz
                        mappedX = yawComponent + rollComponent
                        mappedY = gx
                    }
                    GyroCoordinateSystem.WORLD -> {
                        val worldDx = if (!useControllerGyro) sensor.worldDx * s.gyroSensitivityX / 100f
                        else _controllerWorldDx * s.gyroSensitivityX / 100f
                        val worldDy = if (!useControllerGyro) sensor.worldDy * s.gyroSensitivityY / 100f
                        else _controllerWorldDy * s.gyroSensitivityY / 100f
                        mappedX = worldDx
                        mappedY = worldDy
                    }
                }

                // Apply gyro dead zone / reverse dead zone (radial, mirrors joystick behavior)
                val gyroDeadZone = (s.gyroDeadZone / 100f).coerceIn(0f, 0.99f)
                val gyroReverseDeadZone = (s.gyroReverseDeadZone / 100f).coerceIn(0f, 0.99f)
                if (gyroDeadZone > 0f || gyroReverseDeadZone > 0f) {
                    val mag = sqrt(mappedX * mappedX + mappedY * mappedY)
                    if (mag > 0f) {
                        val normalized = (mag / gyroDeadZoneMaxRate).coerceIn(0f, 1f)
                        // 死区优先：死区内恒输出 0，反死区只在死区之外抬升下限。
                        val afterDeadZone = if (normalized <= gyroDeadZone) 0f
                                            else (normalized - gyroDeadZone) / (1f - gyroDeadZone)
                        val afterReverseDeadZone = if (afterDeadZone == 0f) 0f
                                                   else afterDeadZone * (1f - gyroReverseDeadZone) + gyroReverseDeadZone
                        val scale = (afterReverseDeadZone * gyroDeadZoneMaxRate) / mag
                        mappedX *= scale
                        mappedY *= scale
                    }
                }

                // 陀螺仪转摇杆/转鼠标共用的灵敏度曲线：在死区之后、灵敏度之前，按满量程径向映射。
                // 其它模式把 mappedX/Y 当角速度使用，不做曲线。
                if (s.gyroMode == GyroMode.MOUSE ||
                    s.gyroMode == GyroMode.LEFT_STICK ||
                    s.gyroMode == GyroMode.RIGHT_STICK
                ) {
                    val (curvedX, curvedY) = SensitivityCurve.applyRadial(
                        s.gyroStickCurve, mappedX, mappedY, gyroDeadZoneMaxRate,
                    )
                    mappedX = curvedX
                    mappedY = curvedY
                }

                // Apply gyro mapping mode (world coordinate system)
                val sens = s.gyroModeSensitivity / 100f
                if (actualGyroEnabled) {
                    when (s.gyroMode) {
                        GyroMode.MOUSE -> {
                            gyroMouseAccumX += -mappedX * sens * 50f
                            gyroMouseAccumY += -mappedY * sens * 50f
                            val rawMx = gyroMouseAccumX.toInt()
                            val rawMy = gyroMouseAccumY.toInt()
                            val gyroMx = rawMx.coerceIn(-127, 127)
                            val gyroMy = rawMy.coerceIn(-127, 127)
                            gyroMouseAccumX -= rawMx
                            gyroMouseAccumY -= rawMy
                            val totalDx = (gyroMx + _gamepadState.value.mouseDx.toInt()).coerceIn(-32768, 32767).toShort()
                            val totalDy = (gyroMy + _gamepadState.value.mouseDy.toInt()).coerceIn(-32768, 32767).toShort()
                            _gamepadState.value = _gamepadState.value.copy(
                                mouseDx = totalDx,
                                mouseDy = totalDy,
                            )
                        }
                        else -> {}
                    }
                }

                val gyroMode = s.gyroMode
                val accelMode = gyroMode == GyroMode.ACCELEROMETER_LEFT_STICK ||
                    gyroMode == GyroMode.ACCELEROMETER_RIGHT_STICK

                // Re-arm the wheel trackers whenever the hold/orientation/mode changes so the
                // accumulated angle and low-pass state start from the current posture.
                val accelKey = "${s.gyroBaseDirection}|${sensorHandler.gyroOrientation}|" +
                    "${sensorHandler.isDeviceInverted}|$accelMode"
                if (accelKey != accelMapperKey) {
                    phoneAccelMapper.reset()
                    controllerAccelMapper.reset()
                    accelMapperKey = accelKey
                }

                var accelLx = 0f
                var accelLy = 0f
                var accelRx = 0f
                var accelRy = 0f
                if (actualGyroEnabled && accelMode) {
                    val mapper = if (useControllerGyro) controllerAccelMapper else phoneAccelMapper
                    val (aX, aY, aZ) = if (useControllerGyro) {
                        Triple(_gamepadState.value.accelX, _gamepadState.value.accelY, _gamepadState.value.accelZ)
                    } else {
                        Triple(sensor.accelX, sensor.accelY, sensor.accelZ)
                    }
                    // Raw gyro in the same (for the phone: remapped) frame as the accel above,
                    // so translation-only motion is rejected instead of steering the stick.
                    val (accelGyroX, accelGyroY, accelGyroZ) = if (useControllerGyro) {
                        Triple(controllerGyroRaw[0], controllerGyroRaw[1], controllerGyroRaw[2])
                    } else {
                        Triple(sensor.gyroX, sensor.gyroY, sensor.gyroZ)
                    }
                    val nowNanos = System.nanoTime()
                    val dtSec = ((nowNanos - lastAccelNanos) / 1_000_000_000.0)
                        .toFloat().coerceIn(0f, 0.05f)
                    lastAccelNanos = nowNanos
                    val stick = mapper.update(
                        aX, aY, aZ,
                        s.gyroBaseDirection,
                        sensorHandler.gyroOrientation,
                        sensorHandler.isDeviceInverted,
                        s.gyroModeSensitivity,
                        deadZone = s.gyroDeadZone,
                        reverseDeadZone = s.gyroReverseDeadZone,
                        gyroX = accelGyroX,
                        gyroY = accelGyroY,
                        gyroZ = accelGyroZ,
                        curve = s.gyroStickCurve,
                        dt = dtSec,
                    )
                    val ix = (stick.x * 32767f).toInt().coerceIn(-32768, 32767)
                    val iy = (stick.y * 32767f).toInt().coerceIn(-32768, 32767)
                    accelLx = ix.toFloat()
                    accelLy = iy.toFloat()
                    accelRx = ix.toFloat()
                    accelRy = iy.toFloat()
                } else {
                    phoneAccelMapper.reset()
                    controllerAccelMapper.reset()
                }

                val combinedLx = when (gyroMode) {
                    GyroMode.LEFT_STICK -> {
                        val gyroLx = (-mappedX * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        val gyroLy = (-mappedY * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        (phoneStickX.toInt() + physicalStickX.toInt() + gyroLx.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    GyroMode.ACCELEROMETER_LEFT_STICK -> {
                        (phoneStickX.toInt() + physicalStickX.toInt() + accelLx.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    else -> (phoneStickX.toInt() + physicalStickX.toInt()).coerceIn(-32768, 32767).toShort()
                }
                val combinedLy = when (gyroMode) {
                    GyroMode.LEFT_STICK -> {
                        val gyroLx = (-mappedX * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        val gyroLy = (-mappedY * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        (phoneStickY.toInt() + physicalStickY.toInt() + gyroLy.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    GyroMode.ACCELEROMETER_LEFT_STICK -> {
                        (phoneStickY.toInt() + physicalStickY.toInt() + accelLy.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    else -> (phoneStickY.toInt() + physicalStickY.toInt()).coerceIn(-32768, 32767).toShort()
                }
                val combinedRx = when (gyroMode) {
                    GyroMode.RIGHT_STICK -> {
                        val gyroRx = (-mappedX * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        val gyroRy = (-mappedY * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        (phoneRStickX.toInt() + physicalRStickX.toInt() + gyroRx.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    GyroMode.ACCELEROMETER_RIGHT_STICK -> {
                        (phoneRStickX.toInt() + physicalRStickX.toInt() + accelRx.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    else -> (phoneRStickX.toInt() + physicalRStickX.toInt()).coerceIn(-32768, 32767).toShort()
                }
                val combinedRy = when (gyroMode) {
                    GyroMode.RIGHT_STICK -> {
                        val gyroRx = (-mappedX * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        val gyroRy = (-mappedY * sens * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                        (phoneRStickY.toInt() + physicalRStickY.toInt() + gyroRy.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    GyroMode.ACCELEROMETER_RIGHT_STICK -> {
                        (phoneRStickY.toInt() + physicalRStickY.toInt() + accelRy.toInt()).coerceIn(-32768, 32767).toShort()
                    }
                    else -> (phoneRStickY.toInt() + physicalRStickY.toInt()).coerceIn(-32768, 32767).toShort()
                }
                val currentState = _gamepadState.value
                val input = currentState.copy(
                    leftStickX = combinedLx,
                    leftStickY = combinedLy,
                    rightStickX = combinedRx,
                    rightStickY = combinedRy,
                ).toProto(
                    keyboardModifier = _keyboardModifier,
                    keyboardKeys = _keyboardKeys.filter { it != 0u.toUShort() }.map { it.toUInt() }
                )
                connectionManager.sendGamepadState(input)
                val mDx = _gamepadState.value.mouseDx
                val mDy = _gamepadState.value.mouseDy
                val mWheel = _gamepadState.value.mouseWheel
                val mPan = _gamepadState.value.mousePan
                if (s.connectionMode == ConnectionMode.BLUETOOTH && (mDx != 0.toShort() || mDy != 0.toShort() || mWheel != 0.toShort() || mPan != 0.toShort() || _gamepadState.value.mouseButtons != 0)) {
                    viewModelScope.launch {
                        connectionManager.sendMouseReport(
                            button = effectiveMouseButtons().toByte(),
                            dx = mDx,
                            dy = mDy,
                            wheel = mWheel,
                            hWheel = mPan,
                        )
                    }
                }
                if (mDx != 0.toShort() || mDy != 0.toShort() || mWheel != 0.toShort() || mPan != 0.toShort()) {
                    _gamepadState.value = _gamepadState.value.copy(
                        mouseDx = 0, mouseDy = 0,
                        mouseWheel = 0, mousePan = 0,
                    )
                }
                val intervalMs = round(1000.0 / settings.value.pollingRate).toLong().coerceAtLeast(1L)
                nextSendTime += intervalMs
                val waitTime = nextSendTime - System.currentTimeMillis()
                if (waitTime > 0) {
                    delay(waitTime)
                } else {
                    nextSendTime = System.currentTimeMillis()
                }
            }
        }
    }

    fun onButtonDown(bit: Int) {
        val wasDown = (_gamepadState.value.buttons and bit.toUInt()) != 0u
        phoneButtons = phoneButtons or bit.toUInt()
        val newButtons = _gamepadState.value.buttons or bit.toUInt()
        val newMouseButtons = when (bit) {
            GamepadState.MOUSE_LMB -> _gamepadState.value.mouseButtons or 1
            GamepadState.MOUSE_RMB -> _gamepadState.value.mouseButtons or 2
            GamepadState.MOUSE_MMB -> _gamepadState.value.mouseButtons or 4
            GamepadState.MOUSE_BACK -> _gamepadState.value.mouseButtons or 8
            GamepadState.MOUSE_FORWARD -> _gamepadState.value.mouseButtons or 16
            else -> _gamepadState.value.mouseButtons
        }
        _gamepadState.value = _gamepadState.value.copy(
            buttons = newButtons,
            mouseButtons = newMouseButtons,
        )
        val isMouseButton = (bit == GamepadState.MOUSE_LMB || bit == GamepadState.MOUSE_RMB || bit == GamepadState.MOUSE_MMB || bit == GamepadState.MOUSE_BACK || bit == GamepadState.MOUSE_FORWARD)
        if (settings.value.connectionMode == ConnectionMode.BLUETOOTH && isMouseButton) {
            viewModelScope.launch {
                connectionManager.sendMouseReport(
                    button = effectiveMouseButtons(newMouseButtons).toByte(),
                    dx = 0, dy = 0, wheel = 0, hWheel = 0,
                )
            }
        }
    }

    fun onButtonUp(bit: Int) {
        val wasUp = (_gamepadState.value.buttons and bit.toUInt()) == 0u
        phoneButtons = phoneButtons and (bit.toUInt().inv())
        val newButtons = _gamepadState.value.buttons and (bit.toUInt().inv())
        val newMouseButtons = when (bit) {
            GamepadState.MOUSE_LMB -> _gamepadState.value.mouseButtons and 1.inv()
            GamepadState.MOUSE_RMB -> _gamepadState.value.mouseButtons and 2.inv()
            GamepadState.MOUSE_MMB -> _gamepadState.value.mouseButtons and 4.inv()
            GamepadState.MOUSE_BACK -> _gamepadState.value.mouseButtons and 8.inv()
            GamepadState.MOUSE_FORWARD -> _gamepadState.value.mouseButtons and 16.inv()
            else -> _gamepadState.value.mouseButtons
        }
        _gamepadState.value = _gamepadState.value.copy(
            buttons = newButtons,
            mouseButtons = newMouseButtons,
        )
        val isMouseButton = (bit == GamepadState.MOUSE_LMB || bit == GamepadState.MOUSE_RMB || bit == GamepadState.MOUSE_MMB || bit == GamepadState.MOUSE_BACK || bit == GamepadState.MOUSE_FORWARD)
        if (settings.value.connectionMode == ConnectionMode.BLUETOOTH && isMouseButton) {
            viewModelScope.launch {
                connectionManager.sendMouseReport(
                    button = effectiveMouseButtons(newMouseButtons).toByte(),
                    dx = 0, dy = 0, wheel = 0, hWheel = 0,
                )
            }
        }
    }

    /** 上报用的鼠标键位：屏幕按钮/物理映射（[GamepadState.mouseButtons]）与鼠标板
     *  手势键位（[GamepadState.mouseGestureButtons]）取并集。 */
    fun effectiveMouseButtons(userButtons: Int = _gamepadState.value.mouseButtons): Int =
        userButtons or _gamepadState.value.mouseGestureButtons

    /** 鼠标板手势/拖拽键位（bit0=LMB, bit1=RMB, bit2=MMB）的按下/抬起。 */
    fun onMouseGestureButton(bit: Int, down: Boolean) {
        val cur = _gamepadState.value.mouseGestureButtons
        val next = if (down) cur or bit else cur and bit.inv()
        if (next == cur) return
        _gamepadState.value = _gamepadState.value.copy(mouseGestureButtons = next)
        if (settings.value.connectionMode == ConnectionMode.BLUETOOTH) {
            viewModelScope.launch {
                connectionManager.sendMouseReport(
                    button = effectiveMouseButtons().toByte(),
                    dx = 0, dy = 0, wheel = 0, hWheel = 0,
                )
            }
        }
    }

    fun triggerHapticPress() {
        onHapticFeedbackPress?.invoke()
    }

    fun triggerHapticRelease() {
        onHapticFeedbackRelease?.invoke()
    }

    fun onCustomButtonDown(bits: List<Int>) {
        val kbCodes = mutableListOf<Int>()
        val normalBits = mutableListOf<Int>()
        for (bit in bits) {
            if (bit < 0) {
                kbCodes.add(-bit)
            } else {
                normalBits.add(bit)
            }
        }
        if (kbCodes.isNotEmpty()) {
            for (code in kbCodes) {
                onKeyDown(code)
            }
        }
        if (normalBits.isNotEmpty()) {
            var pb = phoneButtons
            for (bit in normalBits) { pb = pb or bit.toUInt() }
            phoneButtons = pb
            var prevButtons = _gamepadState.value.buttons
            var b = prevButtons
            for (bit in normalBits) { b = b or bit.toUInt() }
            _gamepadState.value = _gamepadState.value.copy(buttons = b)
            if (normalBits.any { dpadDirOf(it) != null }) syncDpadFromButtons()
            for (bit in normalBits) {
                val wasDown = (prevButtons and bit.toUInt()) != 0u
                if (!wasDown) {
                    onHapticFeedbackPress?.invoke()
                    break
                }
            }
        }
    }

    fun onCustomButtonUp(bits: List<Int>) {
        val kbCodes = mutableListOf<Int>()
        val normalBits = mutableListOf<Int>()
        for (bit in bits) {
            if (bit < 0) {
                kbCodes.add(-bit)
            } else {
                normalBits.add(bit)
            }
        }
        if (kbCodes.isNotEmpty()) {
            for (code in kbCodes) {
                onKeyUp(code)
            }
        }
        if (normalBits.isNotEmpty()) {
            var prevButtons = _gamepadState.value.buttons
            var pb = phoneButtons
            for (bit in normalBits) { pb = pb and (bit.toUInt().inv()) }
            phoneButtons = pb
            var b = _gamepadState.value.buttons
            for (bit in normalBits) { b = b and (bit.toUInt().inv()) }
            _gamepadState.value = _gamepadState.value.copy(buttons = b)
            if (normalBits.any { dpadDirOf(it) != null }) syncDpadFromButtons()
            var anyReleased = false
            for (bit in normalBits) {
                if (((prevButtons and bit.toUInt()) != 0u) && ((b and bit.toUInt()) == 0u)) {
                    anyReleased = true
                    break
                }
            }
            if (anyReleased) {
                onHapticFeedbackRelease?.invoke()
            }
        }
    }

    /** D-pad hat value (GamepadState.DPAD_UP/DOWN/LEFT/�?or 0) for a single output bit,
     *  or null when the bit is not a D-pad direction bit. */
    private fun dpadDirOf(bit: Int): Int? {
        return when (bit) {
            GamepadState.DPAD_BIT_UP -> GamepadState.DPAD_UP
            GamepadState.DPAD_BIT_DOWN -> GamepadState.DPAD_DOWN
            GamepadState.DPAD_BIT_LEFT -> GamepadState.DPAD_LEFT
            GamepadState.DPAD_BIT_RIGHT -> GamepadState.DPAD_RIGHT
            else -> null
        }
    }

    /** Recomputes the D-pad hat value from the currently held output bits. Any bit that maps to a
     *  D-pad direction (DPAD_BIT_UP/DOWN/LEFT/RIGHT, held by any button or keypad region) is folded
     *  into the combined hat value so Android/Linux HID outputs react despite a single-flight
     *  `dpad` field. Corner states (e.g. up|left) produce their diagonal hat value. */
    private fun syncDpadFromButtons() {
        val b = _gamepadState.value.buttons
        var combined = 0
        if ((b and GamepadState.DPAD_BIT_UP.toUInt()) != 0u) combined = combined or GamepadState.DPAD_UP
        if ((b and GamepadState.DPAD_BIT_DOWN.toUInt()) != 0u) combined = combined or GamepadState.DPAD_DOWN
        if ((b and GamepadState.DPAD_BIT_LEFT.toUInt()) != 0u) combined = combined or GamepadState.DPAD_LEFT
        if ((b and GamepadState.DPAD_BIT_RIGHT.toUInt()) != 0u) combined = combined or GamepadState.DPAD_RIGHT
        _gamepadState.value = _gamepadState.value.copy(dpad = when (combined) {
            0 -> 0
            GamepadState.DPAD_UP -> GamepadState.DPAD_UP
            GamepadState.DPAD_DOWN -> GamepadState.DPAD_DOWN
            GamepadState.DPAD_LEFT -> GamepadState.DPAD_LEFT
            GamepadState.DPAD_RIGHT -> GamepadState.DPAD_RIGHT
            GamepadState.DPAD_UP or GamepadState.DPAD_LEFT -> GamepadState.DPAD_UP_LEFT
            GamepadState.DPAD_UP or GamepadState.DPAD_RIGHT -> GamepadState.DPAD_UP_RIGHT
            GamepadState.DPAD_DOWN or GamepadState.DPAD_LEFT -> GamepadState.DPAD_DOWN_LEFT
            GamepadState.DPAD_DOWN or GamepadState.DPAD_RIGHT -> GamepadState.DPAD_DOWN_RIGHT
            else -> 0
        })
    }

    fun onVolumeKeyDown(bits: List<Int>) {
        var pb = phoneButtons
        for (bit in bits) { pb = pb or bit.toUInt() }
        phoneButtons = pb
        var b = _gamepadState.value.buttons
        for (bit in bits) { b = b or bit.toUInt() }
        _gamepadState.value = _gamepadState.value.copy(buttons = b)
    }

    fun onVolumeKeyUp(bits: List<Int>) {
        var pb = phoneButtons
        for (bit in bits) { pb = pb and (bit.toUInt().inv()) }
        phoneButtons = pb
        var b = _gamepadState.value.buttons
        for (bit in bits) { b = b and (bit.toUInt().inv()) }
        _gamepadState.value = _gamepadState.value.copy(buttons = b)
    }

    

    fun onLeftStick(x: Short, y: Short) {
        phoneStickX = x
        phoneStickY = y
    }

    fun onRightStick(x: Short, y: Short) {
        phoneRStickX = x
        phoneRStickY = y
    }

    fun onDpad(dir: Int, pressed: Boolean) {
        val dirValue = when (dir) {
            GamepadState.DPAD_BIT_UP -> GamepadState.DPAD_UP
            GamepadState.DPAD_BIT_DOWN -> GamepadState.DPAD_DOWN
            GamepadState.DPAD_BIT_LEFT -> GamepadState.DPAD_LEFT
            GamepadState.DPAD_BIT_RIGHT -> GamepadState.DPAD_RIGHT
            else -> dir
        }
        if (pressed) {
            _dpadBits = _dpadBits or dirValue
            onHapticFeedbackPress?.invoke()
        } else {
            _dpadBits = _dpadBits and dirValue.inv()
            onHapticFeedbackRelease?.invoke()
        }
        val hat = when (_dpadBits) {
            GamepadState.DPAD_UP, GamepadState.DPAD_DOWN,
            GamepadState.DPAD_LEFT, GamepadState.DPAD_RIGHT,
            GamepadState.DPAD_UP_LEFT, GamepadState.DPAD_UP_RIGHT,
            GamepadState.DPAD_DOWN_LEFT, GamepadState.DPAD_DOWN_RIGHT -> _dpadBits
            else -> 0
        }
        _gamepadState.value = _gamepadState.value.copy(dpad = hat)
    }

    /** Batched D-pad update for multi-direction controls (e.g. the integrated d-pad). Fires the
     *  press haptic whenever the reported direction changes to another non-zero direction
     *  (including corner �?cardinal switches), never on release to zero. */
    fun updateDpad(pressed: Int, released: Int) {
        _dpadBits = (_dpadBits or pressed) and released.inv()
        if (_dpadBits != 0) onHapticFeedbackPress?.invoke()
        val hat = when (_dpadBits) {
            GamepadState.DPAD_UP, GamepadState.DPAD_DOWN,
            GamepadState.DPAD_LEFT, GamepadState.DPAD_RIGHT,
            GamepadState.DPAD_UP_LEFT, GamepadState.DPAD_UP_RIGHT,
            GamepadState.DPAD_DOWN_LEFT, GamepadState.DPAD_DOWN_RIGHT -> _dpadBits
            else -> 0
        }
        _gamepadState.value = _gamepadState.value.copy(dpad = hat)
    }

    /** Full release of a multi-direction control: plays the key-release haptic and clears all
     *  D-pad bits. Only invoked by the control when a direction was actually being held. */
    fun updateDpadRelease() {
        onHapticFeedbackRelease?.invoke()
        if (_dpadBits != 0) {
            _dpadBits = 0
            _gamepadState.value = _gamepadState.value.copy(dpad = 0)
        }
    }

    fun onLeftTrigger(value: Int) {
        phoneLT = value.toShort()
        _gamepadState.value = _gamepadState.value.copy(leftTrigger = value)
    }

    fun onRightTrigger(value: Int) {
        phoneRT = value.toShort()
        _gamepadState.value = _gamepadState.value.copy(rightTrigger = value)
    }

    fun onKeyDown(code: Int) {
        when (code) {
            in 0xE0..0xE7 -> {
                _keyboardModifier = _keyboardModifier or (1u shl (code - 0xE0))
            }
            0xE8 -> {
                _keyboardModifier = _keyboardModifier or 0x10u
            }
            0xE9 -> {
                _keyboardModifier = _keyboardModifier or 0x20u
            }
            0xEA -> {
                _keyboardModifier = _keyboardModifier or 0x40u
            }
            0xEB -> {
                _keyboardModifier = _keyboardModifier or 0x80u
            }
            else -> {
                for (i in _keyboardKeys.indices) {
                    if (_keyboardKeys[i].toInt() == 0) {
                        _keyboardKeys[i] = code.toUShort()
                        break
                    }
                }
            }
        }
        updateKeyboardShiftState()
        sendKeyboardReport()
    }

    fun onKeyUp(code: Int) {
        when (code) {
            in 0xE0..0xE7 -> {
                _keyboardModifier = _keyboardModifier and (1u shl (code - 0xE0)).inv()
            }
            0xE8 -> {
                _keyboardModifier = _keyboardModifier and 0x10u.inv()
            }
            0xE9 -> {
                _keyboardModifier = _keyboardModifier and 0x20u.inv()
            }
            0xEA -> {
                _keyboardModifier = _keyboardModifier and 0x40u.inv()
            }
            0xEB -> {
                _keyboardModifier = _keyboardModifier and 0x80u.inv()
            }
            else -> {
                for (i in _keyboardKeys.indices) {
                    if (_keyboardKeys[i] == code.toUShort()) {
                        _keyboardKeys[i] = 0u
                        break
                    }
                }
            }
        }
        updateKeyboardShiftState()
        sendKeyboardReport()
    }

    private fun updateKeyboardShiftState() {
        val shift = (_keyboardModifier and 0x02u) != 0u || (_keyboardModifier and 0x20u) != 0u
        _keyboardShiftActive.value = shift
    }

    fun clearAllKeyboardKeys() {
        _keyboardModifier = 0u
        _keyboardKeys = UShortArray(6)
        updateKeyboardShiftState()
        sendKeyboardReport()
    }

    private fun sendKeyboardReport() {
        if (settings.value.connectionMode != ConnectionMode.BLUETOOTH) return
        val modifier = _keyboardModifier.toByte()
        val keys = ByteArray(6)
        for (i in _keyboardKeys.indices) {
            keys[i] = _keyboardKeys[i].toByte()
        }
        viewModelScope.launch {
            connectionManager.sendKeyboardReport(modifier, keys)
        }
    }

    fun onTouchpadTouches(touches: List<TouchPoint>) {
        phoneTouches = touches
        val primary = touches.firstOrNull { it.active }
        _gamepadState.value = _gamepadState.value.copy(
            touches = touches,
            touchpadX = primary?.x ?: 0,
            touchpadY = primary?.y ?: 0,
            touchpadTouch = primary != null
        )
    }

    
}

/** Trigger value (0..255) above which a remapped LT/RT counts as pressed. */
private const val PHYSICAL_TRIGGER_MAP_THRESHOLD = 128

/** Short-axis magnitude that maps to full deflection for physical stick shaping. */
private const val PHYSICAL_STICK_FULL_SCALE = 32767f
