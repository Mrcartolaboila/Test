package com.zyz4.gkme.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.zyz4.gkme.model.AppSettings
import com.zyz4.gkme.model.ConnectionMode
import com.zyz4.gkme.model.ControlType
import com.zyz4.gkme.model.ControllerDriver
import com.zyz4.gkme.model.DisplayMode
import com.zyz4.gkme.model.FillType
import com.zyz4.gkme.model.GyroOrientation
import com.zyz4.gkme.model.GyroMode
import com.zyz4.gkme.model.GyroBaseDirection
import com.zyz4.gkme.model.GyroCoordinateSystem
import com.zyz4.gkme.model.GyroActivateMode
import com.zyz4.gkme.model.HapticEffect
import com.zyz4.gkme.model.LedAppearance
import com.zyz4.gkme.model.TargetPlatform
import com.zyz4.gkme.model.VirtualGamepadType
import com.zyz4.gkme.model.AudioDevice
import com.zyz4.gkme.model.AudioDeviceType
import com.zyz4.gkme.model.VibrationDevice
import com.zyz4.gkme.model.VibrationDeviceType
import com.zyz4.gkme.model.VibrationType
import com.zyz4.gkme.model.AdaptiveTriggerDevice
import com.zyz4.gkme.model.AdaptiveTriggerTargetType
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "app_settings")

@Singleton
class SettingsRepository @Inject constructor(
    @param:ApplicationContext private val context: Context,
) {
    private object Keys {
        val DISPLAY_MODE = intPreferencesKey("display_mode")
        val CONNECTION_MODE = intPreferencesKey("connection_mode")
        val CONTROL_TYPE = intPreferencesKey("control_type")
        val TARGET_PLATFORM = intPreferencesKey("target_platform")
        val VIRTUAL_GAMEPAD_TYPE = intPreferencesKey("virtual_gamepad_type")
        // 旧版本遗留键，仅用于一次性迁移到 VIRTUAL_GAMEPAD_TYPE。
        val LEGACY_VIRTUAL_GAMEPAD_BACKEND = intPreferencesKey("virtual_gamepad_backend")
        val LEGACY_UHID_PROFILE = intPreferencesKey("uhid_profile")
        val POLLING_RATE = intPreferencesKey("polling_rate")
        val DEVICE_NAME = stringPreferencesKey("device_name")
        val CURRENT_PRESET_NAME = stringPreferencesKey("current_preset_name")
        val VIBRATION_PRESS_TYPE = intPreferencesKey("vibration_press_type")
        val VIBRATION_RELEASE_TYPE = intPreferencesKey("vibration_release_type")
        val VIBRATION_PRESS_VIEW_EFFECT = intPreferencesKey("vibration_press_view_effect")
        val VIBRATION_RELEASE_VIEW_EFFECT = intPreferencesKey("vibration_release_view_effect")
        val VIBRATION_PRESS_DURATION = intPreferencesKey("vibration_press_duration")
        val VIBRATION_RELEASE_DURATION = intPreferencesKey("vibration_release_duration")
        val VIBRATION_PRESS_INTENSITY = intPreferencesKey("vibration_press_intensity")
        val VIBRATION_RELEASE_INTENSITY = intPreferencesKey("vibration_release_intensity")
        val VIBRATION_PRESS_FREQUENCY = intPreferencesKey("vibration_press_frequency")
        val VIBRATION_RELEASE_FREQUENCY = intPreferencesKey("vibration_release_frequency")
        val GAME_VIBRATION_DEVICE_TYPE = intPreferencesKey("game_vibration_device_type")
        val GAME_VIBRATION_CONTROLLER_INDEX = intPreferencesKey("game_vibration_controller_index")
        val GAME_VIBRATION_DEVICE_CONNECTED_TYPE = intPreferencesKey("game_vibration_device_connected_type")
        val GAME_VIBRATION_CONTROLLER_CONNECTED_INDEX = intPreferencesKey("game_vibration_controller_connected_index")
        val SWAP_PHONE_MOTORS = booleanPreferencesKey("swap_phone_motors")
        val SWAP_CONTROLLER_MOTORS = booleanPreferencesKey("swap_controller_motors")
        val HD_VIBRATION_ENABLED = booleanPreferencesKey("hd_vibration_enabled")
        val ADAPTIVE_TRIGGER_DEVICE_TYPE = intPreferencesKey("adaptive_trigger_device_type")
        val ADAPTIVE_TRIGGER_CONTROLLER_INDEX = intPreferencesKey("adaptive_trigger_controller_index")
        val ADAPTIVE_TRIGGER_DEVICE_CONNECTED_TYPE = intPreferencesKey("adaptive_trigger_device_connected_type")
        val ADAPTIVE_TRIGGER_CONTROLLER_CONNECTED_INDEX = intPreferencesKey("adaptive_trigger_controller_connected_index")
        val SWAP_ADAPTIVE_TRIGGERS = booleanPreferencesKey("swap_adaptive_triggers")
        val AUTO_START_ENABLED = booleanPreferencesKey("auto_start_enabled")
        val GYRO_ENABLED = booleanPreferencesKey("gyro_enabled")
        val GYRO_SENSITIVITY_X = intPreferencesKey("gyro_sensitivity_x")
        val GYRO_SENSITIVITY_Y = intPreferencesKey("gyro_sensitivity_y")
        val GYRO_SENSITIVITY_Z = intPreferencesKey("gyro_sensitivity_z")
        val GYRO_ORIENTATION = intPreferencesKey("gyro_orientation")
        val GYRO_MODE = intPreferencesKey("gyro_mode")
        val GYRO_MODE_SENSITIVITY = intPreferencesKey("gyro_mode_sensitivity")
        val GYRO_BASE_DIRECTION = intPreferencesKey("gyro_base_direction")
        val GYRO_COORDINATE_SYSTEM = intPreferencesKey("gyro_coordinate_system")
        val GYRO_DEAD_ZONE = intPreferencesKey("gyro_dead_zone")
        val GYRO_REVERSE_DEAD_ZONE = intPreferencesKey("gyro_reverse_dead_zone")
        val GYRO_STICK_CURVE = stringPreferencesKey("gyro_stick_curve")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val FLOATING_OPACITY = intPreferencesKey("floating_opacity")
        val FLOATING_KEEP_ALIVE = booleanPreferencesKey("floating_keep_alive")
        val GYRO_ACTIVATE_MODE = intPreferencesKey("gyro_activate_mode")
        val CONTROLLER_GYRO_ENABLED = booleanPreferencesKey("controller_gyro_enabled")
        val CONTROLLER_GYRO_ENABLED_CONNECTED = booleanPreferencesKey("controller_gyro_enabled_connected")
        val GYRO_ENABLED_CONNECTED = booleanPreferencesKey("gyro_enabled_connected")
        val GYRO_CONTROLLER_INDEX = intPreferencesKey("gyro_controller_index")
        val GYRO_CONTROLLER_INDEX_CONNECTED = intPreferencesKey("gyro_controller_index_connected")
        val VOLUME_UP_BITS = stringPreferencesKey("volume_up_bits")
        val VOLUME_DOWN_BITS = stringPreferencesKey("volume_down_bits")
        val PHYSICAL_INPUT_MAPPINGS = stringPreferencesKey("physical_input_mappings")
        val CONTROLLER_DRIVER = intPreferencesKey("controller_driver")
        val INPUT_CONTROLLER_INDEX = intPreferencesKey("input_controller_index")
        // Audio
        val LEFT_VOICE_COIL_OUTPUT = intPreferencesKey("left_voice_coil_output")
        val RIGHT_VOICE_COIL_OUTPUT = intPreferencesKey("right_voice_coil_output")
        val VOICE_COIL_DEVICE_TYPE = intPreferencesKey("voice_coil_device_type")
        val VOICE_COIL_CONTROLLER_INDEX = intPreferencesKey("voice_coil_controller_index")
        val VOICE_COIL_DEVICE_ID = intPreferencesKey("voice_coil_device_id")
        val VOICE_COIL_DEVICE_NAME = stringPreferencesKey("voice_coil_device_name")
        val VOICE_COIL_DEVICE_CONNECTED_TYPE = intPreferencesKey("voice_coil_device_connected_type")
        val VOICE_COIL_CONTROLLER_CONNECTED_INDEX = intPreferencesKey("voice_coil_controller_connected_index")
        val VOICE_COIL_DEVICE_CONNECTED_ID = intPreferencesKey("voice_coil_device_connected_id")
        val VOICE_COIL_DEVICE_CONNECTED_NAME = stringPreferencesKey("voice_coil_device_connected_name")
        val SWAP_VOICE_COIL_MOTORS = booleanPreferencesKey("swap_voice_coil_motors")
        val CONTROLLER_AUDIO_OUTPUT = intPreferencesKey("controller_audio_output")
        val CONTROLLER_AUDIO_DEVICE_TYPE = intPreferencesKey("controller_audio_device_type")
        val CONTROLLER_AUDIO_DEVICE_CONTROLLER_INDEX = intPreferencesKey("controller_audio_device_controller_index")
        val CONTROLLER_AUDIO_DEVICE_ID = intPreferencesKey("controller_audio_device_id")
        val CONTROLLER_AUDIO_DEVICE_NAME = stringPreferencesKey("controller_audio_device_name")
        // Appearance
        val BG_FILL_TYPE = intPreferencesKey("bg_fill_type")
        val BG_COLOR = intPreferencesKey("bg_color")
        val BG_IMAGE_PATH = stringPreferencesKey("bg_image_path")
        val BTN_FILL_TYPE = intPreferencesKey("btn_fill_type")
        val BTN_COLOR = intPreferencesKey("btn_color")
        val BTN_IMAGE_PATH = stringPreferencesKey("btn_image_path")
        val BTN_OUTLINE_COLOR = intPreferencesKey("btn_outline_color")
        val BTN_OUTLINE_WIDTH = intPreferencesKey("btn_outline_width")
        val JOY_BASE_FILL_TYPE = intPreferencesKey("joy_base_fill_type")
        val JOY_BASE_COLOR = intPreferencesKey("joy_base_color")
        val JOY_BASE_IMAGE_PATH = stringPreferencesKey("joy_base_image_path")
        val JOY_BASE_OUTLINE_COLOR = intPreferencesKey("joy_base_outline_color")
        val JOY_BASE_OUTLINE_WIDTH = intPreferencesKey("joy_base_outline_width")
        val JOY_CAP_FILL_TYPE = intPreferencesKey("joy_cap_fill_type")
        val JOY_CAP_COLOR = intPreferencesKey("joy_cap_color")
        val JOY_CAP_IMAGE_PATH = stringPreferencesKey("joy_cap_image_path")
        val JOY_CAP_OUTLINE_COLOR = intPreferencesKey("joy_cap_outline_color")
        val JOY_CAP_OUTLINE_WIDTH = intPreferencesKey("joy_cap_outline_width")
        val JOY_TRIGGER_OUTLINE_COLOR = intPreferencesKey("joy_trigger_outline_color")
        val JOY_TRIGGER_OUTLINE_WIDTH = intPreferencesKey("joy_trigger_outline_width")
        val TP_TRIGGER_OUTLINE_COLOR = intPreferencesKey("tp_trigger_outline_color")
        val TP_TRIGGER_OUTLINE_WIDTH = intPreferencesKey("tp_trigger_outline_width")
        val TP_FILL_TYPE = intPreferencesKey("tp_fill_type")
        val TP_COLOR = intPreferencesKey("tp_color")
        val TP_IMAGE_PATH = stringPreferencesKey("tp_image_path")
        val TP_OUTLINE_COLOR = intPreferencesKey("tp_outline_color")
        val TP_OUTLINE_WIDTH = intPreferencesKey("tp_outline_width")
        val LINEAR_TRIGGER_BOX_OUTLINE_COLOR = intPreferencesKey("linear_trigger_box_outline_color")
        val LINEAR_TRIGGER_BOX_OUTLINE_WIDTH = intPreferencesKey("linear_trigger_box_outline_width")
        val DPAD_PAD_FILL_TYPE = intPreferencesKey("dpad_pad_fill_type")
        val DPAD_PAD_COLOR = intPreferencesKey("dpad_pad_color")
        val DPAD_PAD_IMAGE_PATH = stringPreferencesKey("dpad_pad_image_path")
        val DPAD_PAD_OUTLINE_COLOR = intPreferencesKey("dpad_pad_outline_color")
        val DPAD_PAD_OUTLINE_WIDTH = intPreferencesKey("dpad_pad_outline_width")
        val DPAD_PAD_TRIGGER_OUTLINE_COLOR = intPreferencesKey("dpad_pad_trigger_outline_color")
        val DPAD_PAD_TRIGGER_OUTLINE_WIDTH = intPreferencesKey("dpad_pad_trigger_outline_width")
        val BTN_ICON_COLOR = intPreferencesKey("btn_icon_color")
        val JOY_ICON_COLOR = intPreferencesKey("joy_icon_color")
        val TP_ICON_COLOR = intPreferencesKey("tp_icon_color")
        val DPAD_PAD_ICON_COLOR = intPreferencesKey("dpad_pad_icon_color")
        val ICON_MAX_SIZE = intPreferencesKey("icon_max_size")
        val LED_BOUND_COLORS = stringPreferencesKey("led_bound_colors")
    }

    private val gson = Gson()
    private val stringSetType = object : TypeToken<Set<String>>() {}.type
    private val floatListType = object : TypeToken<List<Float>>() {}.type

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            displayMode = DisplayMode.entries.getOrElse(
                prefs[Keys.DISPLAY_MODE] ?: 0
            ) { DisplayMode.XBOX },
            connectionMode = ConnectionMode.entries.getOrElse(
                prefs[Keys.CONNECTION_MODE] ?: 0
            ) { ConnectionMode.WIFI },
            controlType = ControlType.entries.getOrElse(
                prefs[Keys.CONTROL_TYPE] ?: ControlType.CONTROLLER.ordinal
            ) { ControlType.CONTROLLER },
            targetPlatform = TargetPlatform.entries.getOrElse(
                prefs[Keys.TARGET_PLATFORM] ?: 0
            ) { TargetPlatform.WINDOWS },
            virtualGamepadType = prefs[Keys.VIRTUAL_GAMEPAD_TYPE]?.let { v ->
                VirtualGamepadType.entries.getOrElse(v) { VirtualGamepadType.XBOX_ONE_S }
            } ?: run {
                val legacyBackend = prefs[Keys.LEGACY_VIRTUAL_GAMEPAD_BACKEND] ?: 0
                val legacyProfile = prefs[Keys.LEGACY_UHID_PROFILE] ?: 0
                if (legacyBackend == 1) when (legacyProfile) {
                    1 -> VirtualGamepadType.DUALSENSE
                    2 -> VirtualGamepadType.SWITCH_PRO
                    else -> VirtualGamepadType.DS4
                } else VirtualGamepadType.XBOX_ONE_S
            },
            pollingRate = prefs[Keys.POLLING_RATE] ?: 120,
            deviceName = prefs[Keys.DEVICE_NAME] ?: "GKME",
            currentPresetName = prefs[Keys.CURRENT_PRESET_NAME] ?: "Controle completo",
            vibrationPressType = VibrationType.entries.getOrElse(
                prefs[Keys.VIBRATION_PRESS_TYPE] ?: VibrationType.VIEW.ordinal
            ) { VibrationType.VIEW },
            vibrationReleaseType = VibrationType.entries.getOrElse(
                prefs[Keys.VIBRATION_RELEASE_TYPE] ?: VibrationType.VIEW.ordinal
            ) { VibrationType.VIEW },
            vibrationPressViewEffect = HapticEffect.entries.getOrElse(
                prefs[Keys.VIBRATION_PRESS_VIEW_EFFECT] ?: HapticEffect.KEYBOARD_TAP.ordinal
            ) { HapticEffect.KEYBOARD_TAP },
            vibrationReleaseViewEffect = HapticEffect.entries.getOrElse(
                prefs[Keys.VIBRATION_RELEASE_VIEW_EFFECT] ?: HapticEffect.CLOCK_TICK.ordinal
            ) { HapticEffect.CLOCK_TICK },
            vibrationPressDuration = prefs[Keys.VIBRATION_PRESS_DURATION] ?: 50,
            vibrationReleaseDuration = prefs[Keys.VIBRATION_RELEASE_DURATION] ?: 20,
            vibrationPressIntensity = prefs[Keys.VIBRATION_PRESS_INTENSITY] ?: 128,
            vibrationReleaseIntensity = prefs[Keys.VIBRATION_RELEASE_INTENSITY] ?: 64,
            vibrationPressFrequency = prefs[Keys.VIBRATION_PRESS_FREQUENCY] ?: 56,
            vibrationReleaseFrequency = prefs[Keys.VIBRATION_RELEASE_FREQUENCY] ?: 56,
            gameVibrationDevice = VibrationDevice(
                type = VibrationDeviceType.entries.getOrElse(
                    prefs[Keys.GAME_VIBRATION_DEVICE_TYPE] ?: VibrationDeviceType.PHONE.ordinal
                ) { VibrationDeviceType.PHONE },
                controllerIndex = prefs[Keys.GAME_VIBRATION_CONTROLLER_INDEX] ?: 0,
            ),
            gameVibrationDeviceConnected = VibrationDevice(
                type = VibrationDeviceType.entries.getOrElse(
                    prefs[Keys.GAME_VIBRATION_DEVICE_CONNECTED_TYPE] ?: VibrationDeviceType.CONTROLLER.ordinal
                ) { VibrationDeviceType.CONTROLLER },
                controllerIndex = prefs[Keys.GAME_VIBRATION_CONTROLLER_CONNECTED_INDEX] ?: 0,
            ),
            swapPhoneMotors = prefs[Keys.SWAP_PHONE_MOTORS] ?: false,
            swapControllerMotors = prefs[Keys.SWAP_CONTROLLER_MOTORS] ?: false,
            hdVibrationEnabled = prefs[Keys.HD_VIBRATION_ENABLED] ?: true,
            adaptiveTriggerDevice = AdaptiveTriggerDevice(
                type = AdaptiveTriggerTargetType.entries.getOrElse(
                    prefs[Keys.ADAPTIVE_TRIGGER_DEVICE_TYPE] ?: AdaptiveTriggerTargetType.PHONE_MOTOR.ordinal
                ) { AdaptiveTriggerTargetType.PHONE_MOTOR },
                controllerIndex = prefs[Keys.ADAPTIVE_TRIGGER_CONTROLLER_INDEX] ?: 0,
            ),
            adaptiveTriggerDeviceConnected = AdaptiveTriggerDevice(
                type = AdaptiveTriggerTargetType.entries.getOrElse(
                    prefs[Keys.ADAPTIVE_TRIGGER_DEVICE_CONNECTED_TYPE] ?: AdaptiveTriggerTargetType.CONTROLLER_TRIGGER.ordinal
                ) { AdaptiveTriggerTargetType.CONTROLLER_TRIGGER },
                controllerIndex = prefs[Keys.ADAPTIVE_TRIGGER_CONTROLLER_CONNECTED_INDEX] ?: 0,
            ),
            swapAdaptiveTriggers = prefs[Keys.SWAP_ADAPTIVE_TRIGGERS] ?: false,
            autoStartEnabled = prefs[Keys.AUTO_START_ENABLED] ?: false,
            gyroEnabled = prefs[Keys.GYRO_ENABLED] ?: true,
            gyroSensitivityX = prefs[Keys.GYRO_SENSITIVITY_X] ?: 100,
            gyroSensitivityY = prefs[Keys.GYRO_SENSITIVITY_Y] ?: 100,
            gyroSensitivityZ = prefs[Keys.GYRO_SENSITIVITY_Z] ?: 100,
            gyroOrientation = GyroOrientation.entries.getOrElse(
                prefs[Keys.GYRO_ORIENTATION] ?: 0
            ) { GyroOrientation.LANDSCAPE },
            gyroMode = GyroMode.entries.getOrElse(
                prefs[Keys.GYRO_MODE] ?: GyroMode.HANDHELD.ordinal
            ) { GyroMode.HANDHELD },
            gyroModeSensitivity = prefs[Keys.GYRO_MODE_SENSITIVITY] ?: 20,
            gyroDeadZone = prefs[Keys.GYRO_DEAD_ZONE] ?: 0,
            gyroReverseDeadZone = prefs[Keys.GYRO_REVERSE_DEAD_ZONE] ?: 0,
            gyroStickCurve = parseFloatList(prefs[Keys.GYRO_STICK_CURVE]),
            gyroBaseDirection = GyroBaseDirection.entries.getOrElse(
                prefs[Keys.GYRO_BASE_DIRECTION] ?: GyroBaseDirection.VERTICAL.ordinal
            ) { GyroBaseDirection.VERTICAL },
            gyroCoordinateSystem = GyroCoordinateSystem.entries.getOrElse(
                prefs[Keys.GYRO_COORDINATE_SYSTEM] ?: GyroCoordinateSystem.YAW_ROLL.ordinal
            ) { GyroCoordinateSystem.YAW_ROLL },
            keepScreenOn = prefs[Keys.KEEP_SCREEN_ON] ?: false,
            floatingOpacity = (prefs[Keys.FLOATING_OPACITY] ?: 50).coerceIn(0, 100),
            floatingKeepAlive = prefs[Keys.FLOATING_KEEP_ALIVE] ?: false,
            gyroActivateMode = GyroActivateMode.entries.getOrElse(
                prefs[Keys.GYRO_ACTIVATE_MODE] ?: 0
            ) { GyroActivateMode.ALWAYS },
            controllerGyroEnabled = prefs[Keys.CONTROLLER_GYRO_ENABLED] ?: false,
            controllerGyroEnabledConnected = prefs[Keys.CONTROLLER_GYRO_ENABLED_CONNECTED] ?: true,
            gyroEnabledConnected = prefs[Keys.GYRO_ENABLED_CONNECTED] ?: true,
            gyroControllerIndex = prefs[Keys.GYRO_CONTROLLER_INDEX] ?: 0,
            gyroControllerIndexConnected = prefs[Keys.GYRO_CONTROLLER_INDEX_CONNECTED] ?: 0,
            controllerDriver = ControllerDriver.entries.getOrElse(
                prefs[Keys.CONTROLLER_DRIVER] ?: 0
            ) { ControllerDriver.SDL3 },
            inputControllerIndex = prefs[Keys.INPUT_CONTROLLER_INDEX] ?: 0,
            bgFillType = FillType.entries.getOrElse(prefs[Keys.BG_FILL_TYPE] ?: 0) { FillType.SOLID_COLOR },
            bgColor = prefs[Keys.BG_COLOR] ?: 0xFF000000.toInt(),
            bgImagePath = prefs[Keys.BG_IMAGE_PATH],
            btnFillType = FillType.entries.getOrElse(prefs[Keys.BTN_FILL_TYPE] ?: 0) { FillType.SOLID_COLOR },
            btnColor = prefs[Keys.BTN_COLOR] ?: 0xFF1A1A1A.toInt(),
            btnImagePath = prefs[Keys.BTN_IMAGE_PATH],
            btnOutlineColor = prefs[Keys.BTN_OUTLINE_COLOR] ?: 0xFF666666.toInt(),
            btnOutlineWidth = prefs[Keys.BTN_OUTLINE_WIDTH] ?: 4,
            joyBaseFillType = FillType.entries.getOrElse(prefs[Keys.JOY_BASE_FILL_TYPE] ?: 0) { FillType.SOLID_COLOR },
            joyBaseColor = prefs[Keys.JOY_BASE_COLOR] ?: -0xdddddd,
            joyBaseImagePath = prefs[Keys.JOY_BASE_IMAGE_PATH],
            joyBaseOutlineColor = prefs[Keys.JOY_BASE_OUTLINE_COLOR] ?: -0xaaaaab,
            joyBaseOutlineWidth = prefs[Keys.JOY_BASE_OUTLINE_WIDTH] ?: 4,
            joyCapFillType = FillType.entries.getOrElse(prefs[Keys.JOY_CAP_FILL_TYPE] ?: 0) { FillType.SOLID_COLOR },
            joyCapColor = prefs[Keys.JOY_CAP_COLOR] ?: -0xaaaaab,
            joyCapImagePath = prefs[Keys.JOY_CAP_IMAGE_PATH],
            joyCapOutlineColor = prefs[Keys.JOY_CAP_OUTLINE_COLOR] ?: -0x888889,
            joyCapOutlineWidth = prefs[Keys.JOY_CAP_OUTLINE_WIDTH] ?: 4,
            joyTriggerOutlineColor = prefs[Keys.JOY_TRIGGER_OUTLINE_COLOR] ?: -0x666667,
            joyTriggerOutlineWidth = prefs[Keys.JOY_TRIGGER_OUTLINE_WIDTH] ?: 4,
            tpTriggerOutlineColor = prefs[Keys.TP_TRIGGER_OUTLINE_COLOR] ?: -0x666667,
            tpTriggerOutlineWidth = prefs[Keys.TP_TRIGGER_OUTLINE_WIDTH] ?: 4,
            tpFillType = FillType.entries.getOrElse(prefs[Keys.TP_FILL_TYPE] ?: 0) { FillType.SOLID_COLOR },
            tpColor = prefs[Keys.TP_COLOR] ?: 0xFF121212.toInt(),
            tpImagePath = prefs[Keys.TP_IMAGE_PATH],
            tpOutlineColor = prefs[Keys.TP_OUTLINE_COLOR] ?: 0xFF666666.toInt(),
            tpOutlineWidth = prefs[Keys.TP_OUTLINE_WIDTH] ?: 4,
            linearTriggerBoxOutlineColor = prefs[Keys.LINEAR_TRIGGER_BOX_OUTLINE_COLOR] ?: 0xFF888888.toInt(),
            linearTriggerBoxOutlineWidth = prefs[Keys.LINEAR_TRIGGER_BOX_OUTLINE_WIDTH] ?: 4,
            dpadPadFillType = FillType.entries.getOrElse(prefs[Keys.DPAD_PAD_FILL_TYPE] ?: 0) { FillType.SOLID_COLOR },
            dpadPadColor = prefs[Keys.DPAD_PAD_COLOR] ?: 0xFF1A1A1A.toInt(),
            dpadPadImagePath = prefs[Keys.DPAD_PAD_IMAGE_PATH],
            dpadPadOutlineColor = prefs[Keys.DPAD_PAD_OUTLINE_COLOR] ?: 0xFF666666.toInt(),
            dpadPadOutlineWidth = prefs[Keys.DPAD_PAD_OUTLINE_WIDTH] ?: 4,
            dpadPadTriggerOutlineColor = prefs[Keys.DPAD_PAD_TRIGGER_OUTLINE_COLOR] ?: -0x666667,
            dpadPadTriggerOutlineWidth = prefs[Keys.DPAD_PAD_TRIGGER_OUTLINE_WIDTH] ?: 4,
            btnIconColor = prefs[Keys.BTN_ICON_COLOR] ?: 0xFFCCCCCC.toInt(),
            joyIconColor = prefs[Keys.JOY_ICON_COLOR] ?: 0xFFCCCCCC.toInt(),
            tpIconColor = prefs[Keys.TP_ICON_COLOR] ?: -0x99999a,
            dpadPadIconColor = prefs[Keys.DPAD_PAD_ICON_COLOR] ?: 0xFFCCCCCC.toInt(),
            iconMaxSize = prefs[Keys.ICON_MAX_SIZE] ?: 24,
            ledBoundColors = prefs[Keys.LED_BOUND_COLORS]
                ?.let { parseStringSet(it) }
                ?: LedAppearance.DEFAULT_BOUND_COLORS,
            voiceCoilDevice = prefs[Keys.VOICE_COIL_DEVICE_TYPE]?.let { typeOrdinal ->
                AudioDevice(
                    type = sanitizeVoiceCoilType(
                        AudioDeviceType.fromPersistId(typeOrdinal)
                    ),
                    controllerIndex = prefs[Keys.VOICE_COIL_CONTROLLER_INDEX] ?: 0,
                    deviceId = prefs[Keys.VOICE_COIL_DEVICE_ID] ?: AudioDevice.AUTO_SOUND_DEVICE_ID,
                    deviceName = prefs[Keys.VOICE_COIL_DEVICE_NAME] ?: "",
                )
            } ?: migrateVoiceCoilDevice(
                prefs[Keys.LEFT_VOICE_COIL_OUTPUT],
                prefs[Keys.RIGHT_VOICE_COIL_OUTPUT],
            ),
            voiceCoilDeviceConnected = AudioDevice(
                type = sanitizeVoiceCoilType(
                    AudioDeviceType.fromPersistId(
                        prefs[Keys.VOICE_COIL_DEVICE_CONNECTED_TYPE] ?: AudioDeviceType.CONTROLLER.ordinal,
                        AudioDeviceType.CONTROLLER,
                    )
                ),
                controllerIndex = prefs[Keys.VOICE_COIL_CONTROLLER_CONNECTED_INDEX] ?: 0,
                deviceId = prefs[Keys.VOICE_COIL_DEVICE_CONNECTED_ID] ?: AudioDevice.AUTO_SOUND_DEVICE_ID,
                deviceName = prefs[Keys.VOICE_COIL_DEVICE_CONNECTED_NAME] ?: "",
            ),
            swapVoiceCoilMotors = prefs[Keys.SWAP_VOICE_COIL_MOTORS] ?: false,
            controllerAudioDevice = restoreControllerAudioDevice(prefs),
        )
    }

    suspend fun saveSettings(settings: AppSettings) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.DISPLAY_MODE] = settings.displayMode.ordinal
            prefs[Keys.CONNECTION_MODE] = settings.connectionMode.ordinal
            prefs[Keys.CONTROL_TYPE] = settings.controlType.ordinal
            prefs[Keys.TARGET_PLATFORM] = settings.targetPlatform.ordinal
            prefs[Keys.VIRTUAL_GAMEPAD_TYPE] = settings.virtualGamepadType.ordinal
            prefs[Keys.POLLING_RATE] = settings.pollingRate
            prefs[Keys.DEVICE_NAME] = settings.deviceName
            prefs[Keys.CURRENT_PRESET_NAME] = settings.currentPresetName
            prefs[Keys.VIBRATION_PRESS_TYPE] = settings.vibrationPressType.ordinal
            prefs[Keys.VIBRATION_RELEASE_TYPE] = settings.vibrationReleaseType.ordinal
            prefs[Keys.VIBRATION_PRESS_VIEW_EFFECT] = settings.vibrationPressViewEffect.ordinal
            prefs[Keys.VIBRATION_RELEASE_VIEW_EFFECT] = settings.vibrationReleaseViewEffect.ordinal
            prefs[Keys.VIBRATION_PRESS_DURATION] = settings.vibrationPressDuration
            prefs[Keys.VIBRATION_RELEASE_DURATION] = settings.vibrationReleaseDuration
            prefs[Keys.VIBRATION_PRESS_INTENSITY] = settings.vibrationPressIntensity
            prefs[Keys.VIBRATION_RELEASE_INTENSITY] = settings.vibrationReleaseIntensity
            prefs[Keys.VIBRATION_PRESS_FREQUENCY] = settings.vibrationPressFrequency
            prefs[Keys.VIBRATION_RELEASE_FREQUENCY] = settings.vibrationReleaseFrequency
            prefs[Keys.GAME_VIBRATION_DEVICE_TYPE] = settings.gameVibrationDevice.type.ordinal
            prefs[Keys.GAME_VIBRATION_CONTROLLER_INDEX] = settings.gameVibrationDevice.controllerIndex
            prefs[Keys.GAME_VIBRATION_DEVICE_CONNECTED_TYPE] = settings.gameVibrationDeviceConnected.type.ordinal
            prefs[Keys.GAME_VIBRATION_CONTROLLER_CONNECTED_INDEX] = settings.gameVibrationDeviceConnected.controllerIndex
            prefs[Keys.SWAP_PHONE_MOTORS] = settings.swapPhoneMotors
            prefs[Keys.SWAP_CONTROLLER_MOTORS] = settings.swapControllerMotors
            prefs[Keys.HD_VIBRATION_ENABLED] = settings.hdVibrationEnabled
            prefs[Keys.ADAPTIVE_TRIGGER_DEVICE_TYPE] = settings.adaptiveTriggerDevice.type.ordinal
            prefs[Keys.ADAPTIVE_TRIGGER_CONTROLLER_INDEX] = settings.adaptiveTriggerDevice.controllerIndex
            prefs[Keys.ADAPTIVE_TRIGGER_DEVICE_CONNECTED_TYPE] = settings.adaptiveTriggerDeviceConnected.type.ordinal
            prefs[Keys.ADAPTIVE_TRIGGER_CONTROLLER_CONNECTED_INDEX] = settings.adaptiveTriggerDeviceConnected.controllerIndex
            prefs[Keys.SWAP_ADAPTIVE_TRIGGERS] = settings.swapAdaptiveTriggers
            prefs[Keys.AUTO_START_ENABLED] = settings.autoStartEnabled
            prefs[Keys.GYRO_ENABLED] = settings.gyroEnabled
            prefs[Keys.GYRO_SENSITIVITY_X] = settings.gyroSensitivityX
            prefs[Keys.GYRO_SENSITIVITY_Y] = settings.gyroSensitivityY
            prefs[Keys.GYRO_SENSITIVITY_Z] = settings.gyroSensitivityZ
            prefs[Keys.GYRO_ORIENTATION] = settings.gyroOrientation.ordinal
            prefs[Keys.GYRO_MODE] = settings.gyroMode.ordinal
            prefs[Keys.GYRO_MODE_SENSITIVITY] = settings.gyroModeSensitivity
            prefs[Keys.GYRO_DEAD_ZONE] = settings.gyroDeadZone
            prefs[Keys.GYRO_REVERSE_DEAD_ZONE] = settings.gyroReverseDeadZone
            if (settings.gyroStickCurve != null) {
                prefs[Keys.GYRO_STICK_CURVE] = gson.toJson(settings.gyroStickCurve)
            } else {
                prefs.remove(Keys.GYRO_STICK_CURVE)
            }
            prefs[Keys.GYRO_BASE_DIRECTION] = settings.gyroBaseDirection.ordinal
            prefs[Keys.GYRO_COORDINATE_SYSTEM] = settings.gyroCoordinateSystem.ordinal
            prefs[Keys.KEEP_SCREEN_ON] = settings.keepScreenOn
            prefs[Keys.FLOATING_OPACITY] = settings.floatingOpacity
            prefs[Keys.FLOATING_KEEP_ALIVE] = settings.floatingKeepAlive
            prefs[Keys.GYRO_ACTIVATE_MODE] = settings.gyroActivateMode.ordinal
            prefs[Keys.CONTROLLER_GYRO_ENABLED] = settings.controllerGyroEnabled
            prefs[Keys.CONTROLLER_GYRO_ENABLED_CONNECTED] = settings.controllerGyroEnabledConnected
            prefs[Keys.GYRO_ENABLED_CONNECTED] = settings.gyroEnabledConnected
            prefs[Keys.GYRO_CONTROLLER_INDEX] = settings.gyroControllerIndex
            prefs[Keys.GYRO_CONTROLLER_INDEX_CONNECTED] = settings.gyroControllerIndexConnected
            prefs[Keys.CONTROLLER_DRIVER] = settings.controllerDriver.ordinal
            prefs[Keys.INPUT_CONTROLLER_INDEX] = settings.inputControllerIndex
            prefs[Keys.BG_FILL_TYPE] = settings.bgFillType.ordinal
            prefs[Keys.BG_COLOR] = settings.bgColor
            if (settings.bgImagePath != null) prefs[Keys.BG_IMAGE_PATH] = settings.bgImagePath else prefs.remove(Keys.BG_IMAGE_PATH)
            prefs[Keys.BTN_FILL_TYPE] = settings.btnFillType.ordinal
            prefs[Keys.BTN_COLOR] = settings.btnColor
            if (settings.btnImagePath != null) prefs[Keys.BTN_IMAGE_PATH] = settings.btnImagePath else prefs.remove(Keys.BTN_IMAGE_PATH)
            prefs[Keys.BTN_OUTLINE_COLOR] = settings.btnOutlineColor
            prefs[Keys.BTN_OUTLINE_WIDTH] = settings.btnOutlineWidth
            prefs[Keys.JOY_BASE_FILL_TYPE] = settings.joyBaseFillType.ordinal
            prefs[Keys.JOY_BASE_COLOR] = settings.joyBaseColor
            if (settings.joyBaseImagePath != null) prefs[Keys.JOY_BASE_IMAGE_PATH] = settings.joyBaseImagePath else prefs.remove(Keys.JOY_BASE_IMAGE_PATH)
            prefs[Keys.JOY_BASE_OUTLINE_COLOR] = settings.joyBaseOutlineColor
            prefs[Keys.JOY_BASE_OUTLINE_WIDTH] = settings.joyBaseOutlineWidth
            prefs[Keys.JOY_CAP_FILL_TYPE] = settings.joyCapFillType.ordinal
            prefs[Keys.JOY_CAP_COLOR] = settings.joyCapColor
            if (settings.joyCapImagePath != null) prefs[Keys.JOY_CAP_IMAGE_PATH] = settings.joyCapImagePath else prefs.remove(Keys.JOY_CAP_IMAGE_PATH)
            prefs[Keys.JOY_CAP_OUTLINE_COLOR] = settings.joyCapOutlineColor
            prefs[Keys.JOY_CAP_OUTLINE_WIDTH] = settings.joyCapOutlineWidth
            prefs[Keys.JOY_TRIGGER_OUTLINE_COLOR] = settings.joyTriggerOutlineColor
            prefs[Keys.JOY_TRIGGER_OUTLINE_WIDTH] = settings.joyTriggerOutlineWidth
            prefs[Keys.TP_TRIGGER_OUTLINE_COLOR] = settings.tpTriggerOutlineColor
            prefs[Keys.TP_TRIGGER_OUTLINE_WIDTH] = settings.tpTriggerOutlineWidth
            prefs[Keys.TP_FILL_TYPE] = settings.tpFillType.ordinal
            prefs[Keys.TP_COLOR] = settings.tpColor
            if (settings.tpImagePath != null) prefs[Keys.TP_IMAGE_PATH] = settings.tpImagePath else prefs.remove(Keys.TP_IMAGE_PATH)
            prefs[Keys.TP_OUTLINE_COLOR] = settings.tpOutlineColor
            prefs[Keys.TP_OUTLINE_WIDTH] = settings.tpOutlineWidth
            prefs[Keys.LINEAR_TRIGGER_BOX_OUTLINE_COLOR] = settings.linearTriggerBoxOutlineColor
            prefs[Keys.LINEAR_TRIGGER_BOX_OUTLINE_WIDTH] = settings.linearTriggerBoxOutlineWidth
            prefs[Keys.DPAD_PAD_FILL_TYPE] = settings.dpadPadFillType.ordinal
            prefs[Keys.DPAD_PAD_COLOR] = settings.dpadPadColor
            if (settings.dpadPadImagePath != null) prefs[Keys.DPAD_PAD_IMAGE_PATH] = settings.dpadPadImagePath else prefs.remove(Keys.DPAD_PAD_IMAGE_PATH)
            prefs[Keys.DPAD_PAD_OUTLINE_COLOR] = settings.dpadPadOutlineColor
            prefs[Keys.DPAD_PAD_OUTLINE_WIDTH] = settings.dpadPadOutlineWidth
            prefs[Keys.DPAD_PAD_TRIGGER_OUTLINE_COLOR] = settings.dpadPadTriggerOutlineColor
            prefs[Keys.DPAD_PAD_TRIGGER_OUTLINE_WIDTH] = settings.dpadPadTriggerOutlineWidth
            prefs[Keys.BTN_ICON_COLOR] = settings.btnIconColor
            prefs[Keys.JOY_ICON_COLOR] = settings.joyIconColor
            prefs[Keys.TP_ICON_COLOR] = settings.tpIconColor
            prefs[Keys.DPAD_PAD_ICON_COLOR] = settings.dpadPadIconColor
            prefs[Keys.ICON_MAX_SIZE] = settings.iconMaxSize
            prefs[Keys.LED_BOUND_COLORS] = gson.toJson(settings.ledBoundColors)
            prefs[Keys.VOICE_COIL_DEVICE_TYPE] = settings.voiceCoilDevice.type.persistId
            prefs[Keys.VOICE_COIL_CONTROLLER_INDEX] = settings.voiceCoilDevice.controllerIndex
            prefs[Keys.VOICE_COIL_DEVICE_ID] = settings.voiceCoilDevice.deviceId
            prefs[Keys.VOICE_COIL_DEVICE_NAME] = settings.voiceCoilDevice.deviceName
            prefs[Keys.VOICE_COIL_DEVICE_CONNECTED_TYPE] = settings.voiceCoilDeviceConnected.type.persistId
            prefs[Keys.VOICE_COIL_CONTROLLER_CONNECTED_INDEX] = settings.voiceCoilDeviceConnected.controllerIndex
            prefs[Keys.VOICE_COIL_DEVICE_CONNECTED_ID] = settings.voiceCoilDeviceConnected.deviceId
            prefs[Keys.VOICE_COIL_DEVICE_CONNECTED_NAME] = settings.voiceCoilDeviceConnected.deviceName
            prefs[Keys.SWAP_VOICE_COIL_MOTORS] = settings.swapVoiceCoilMotors
            prefs[Keys.CONTROLLER_AUDIO_DEVICE_TYPE] = settings.controllerAudioDevice.type.persistId
            prefs[Keys.CONTROLLER_AUDIO_DEVICE_CONTROLLER_INDEX] = settings.controllerAudioDevice.controllerIndex
            prefs[Keys.CONTROLLER_AUDIO_DEVICE_ID] = settings.controllerAudioDevice.deviceId
            prefs[Keys.CONTROLLER_AUDIO_DEVICE_NAME] = settings.controllerAudioDevice.deviceName
        }
    }

    /**
     * The phone speaker is now an enumerated sound device, so a previously saved
     * [AudioDeviceType.PHONE_SPEAKER] falls back to the phone motor default.
     */
    private fun sanitizeVoiceCoilType(type: AudioDeviceType): AudioDeviceType =
        if (type == AudioDeviceType.PHONE_SPEAKER) AudioDeviceType.PHONE_MOTOR else type

    /**
     * Restores the controller-audio target. The device is stored as a full
     * [AudioDevice] (sound device / controller USB speaker / none); a legacy
     * `controller_audio_output` ordinal is migrated when the new keys are absent.
     */
    private fun restoreControllerAudioDevice(prefs: androidx.datastore.preferences.core.Preferences): AudioDevice {
        val typeOrdinal = prefs[Keys.CONTROLLER_AUDIO_DEVICE_TYPE]
        if (typeOrdinal != null) {
            return AudioDevice(
                type = AudioDeviceType.fromPersistId(typeOrdinal, AudioDeviceType.SOUND_DEVICE),
                controllerIndex = prefs[Keys.CONTROLLER_AUDIO_DEVICE_CONTROLLER_INDEX] ?: 0,
                deviceId = prefs[Keys.CONTROLLER_AUDIO_DEVICE_ID] ?: AudioDevice.AUTO_SOUND_DEVICE_ID,
                deviceName = prefs[Keys.CONTROLLER_AUDIO_DEVICE_NAME] ?: "",
            )
        }
        // Legacy ordinals: 0 = none, 5 = all speakers (phone), 6..9 = controller USB.
        return when (val o = prefs[Keys.CONTROLLER_AUDIO_OUTPUT] ?: 5) {
            0 -> AudioDevice.NONE
            in 6..9 -> AudioDevice.controller(o - 6)
            else -> AudioDevice.AUTO_SOUND_DEVICE
        }
    }

    /** Maps the legacy left/right voice-coil outputs onto the new single-device model. */
    private fun migrateVoiceCoilDevice(leftOrdinal: Int?, rightOrdinal: Int?): AudioDevice {
        val ordinal = leftOrdinal ?: rightOrdinal ?: 1
        return when (ordinal) {
            0 -> AudioDevice.NONE
            1, 2 -> AudioDevice.PHONE_MOTOR
            3, 4, 5 -> AudioDevice.AUTO_SOUND_DEVICE
            in 6..9 -> AudioDevice.controller(0)
            else -> AudioDevice.PHONE_MOTOR
        }
    }

    private fun parseStringSet(json: String?): Set<String> {
        if (json.isNullOrEmpty()) return emptySet()
        return try {
            gson.fromJson<Set<String>>(json, stringSetType) ?: emptySet()
        } catch (_: Exception) { emptySet() }
    }

    private fun parseFloatList(json: String?): List<Float>? {
        if (json.isNullOrEmpty()) return null
        return try {
            gson.fromJson<List<Float>>(json, floatListType)?.takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }
}
