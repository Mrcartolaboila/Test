package com.zyz4.gkme.service

import android.content.Context
import android.os.Build
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import com.zyz4.gkme.controlled.GamepadInjector
import com.zyz4.gkme.data.PairingStateRepository
import com.zyz4.gkme.data.SettingsRepository
import com.zyz4.gkme.haptic.HdPcmStreamer
import com.zyz4.gkme.haptic.PhoneHdHaptics
import com.zyz4.gkme.model.AppSettings
import com.zyz4.gkme.model.ConnectionMode
import com.zyz4.gkme.model.GamepadState
import com.zyz4.gkme.model.TargetPlatform
import com.zyz4.gkme.model.VibrationDeviceType
import com.zyz4.gkme.model.gameVibrationDeviceFor
import com.zyz4.gkme.model.virtualGamepadNativeBackend
import com.zyz4.gkme.model.virtualGamepadUhidProfile
import com.zyz4.gkme.model.voiceCoilDeviceFor
import com.zyz4.gkme.proto.ClientToServer
import com.zyz4.gkme.proto.GamepadInput
import com.zyz4.gkme.proto.Hello
import com.zyz4.gkme.proto.ServerToClient
import com.zyz4.gkme.proto.TriggerEffects
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.yield
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

private enum class ActiveProtocol { NONE, WIFI, EMOTION, USB }

data class ConnectionState(
    val connected: Boolean = false,
    val statusText: String = "Não iniciado",
    val batteryLevel: Int = 100,
    val phase: ConnectionPhase = ConnectionPhase.IDLE,
    val transportType: BluetoothTransportType? = null,
    val restartToken: Int = 0,
)

/** LED state of the emulated controller as reported by the PC. [color] is 0xRRGGBB
 *  (0x000000 for controllers without an LED, e.g. Xbox 360). [playerLed] is the
 *  player-indicator bitmask (bit0 = LED 1 …). */
data class LedState(
    val color: Int = 0,
    val playerLed: Int = 0,
)

@Singleton
class ConnectionManager @Inject constructor(
    private val context: Context,
    private val pairingStateRepository: PairingStateRepository,
    private val settingsRepository: SettingsRepository,
    val audioPlaybackService: AudioPlaybackService,
) {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /**
     * 持久化设置是否已加载完成。在此之前 [settings] 仍是默认 [AppSettings]；任何
     * 基于它构造的 [updateSettings] 都会把默认值写回磁盘、覆盖用户配置，因此必须
     * 丢弃（各调用方在加载完成后会重新应用，见 GkViewModel 的 settingsLoaded 等待）。
     */
    private val _settingsLoaded = MutableStateFlow(false)
    val settingsLoaded: StateFlow<Boolean> = _settingsLoaded.asStateFlow()

    val pairedDeviceName: StateFlow<String?> = pairingStateRepository.pairedDeviceName
        .stateIn(scope, SharingStarted.Eagerly, null)
    private val udpService = UdpService()
    private val usbService = UsbService()
    private var bluetoothService: BluetoothHidService? = null
    val isBluetoothRunning: Boolean get() = bluetoothService != null
    private var dsuService: DsuService? = null
    private var serverJob: Job? = null
    private var btPhaseJob: Job? = null
    private var watchdogJob: Job? = null
    private var reconnectJob: Job? = null

    /**
     * 当前生效的传输协议。WiFi(UDP) 与 Emotion(DSU) 在设计上互斥（只有一个生效），
     * 后连接的真实客户端会接管；@Volatile 保证跨线程可见性。
     */
    @Volatile
    private var activeProtocol = ActiveProtocol.NONE

    // 持久化的鼠标按键电平状态。普通手柄状态包会以较高速率持续发送，
    // 若其中包含 mouse_buttons=0 会把 Windows 端"Manter pressionado"的按键清零，造成连点。
    // 因此在每次发送普通状态包时注入当前真实电平。
    // 鼠标状态更新回调 —— sendMouseReport 通过它把鼠标字段写入 ViewModel 的
    // _gamepadState，使鼠标数据跟普通手柄数据合并到同一个 UDP 包里发送。
    var onMouseReport: ((button: Int, dx: Int, dy: Int, wheel: Int, hWheel: Int) -> Unit)? = null

    private var _lastMouseButtonsBt = 0

    private val _connectionState = MutableStateFlow(ConnectionState())
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    /** Whether a physical gamepad is currently connected; selects the active device set. */
    @Volatile
    var physicalControllerConnected: Boolean = false
        private set

    private val _ledState = MutableStateFlow(LedState())
    val ledState: StateFlow<LedState> = _ledState.asStateFlow()

    // Audio DSP runs on its own thread so a burst of audio frames can never block
    // the UDP receive loop (which also carries vibration/LED/control messages).
    // The write into AudioTrack is blocking, so this thread now paces itself to
    // real time. The queue absorbs WiFi bursts; DiscardOldestPolicy stays as a
    // last-resort latency bound (drop the stalest frame, not the newest).
    private val audioExecutor = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(16),
        { r -> Thread(r, "GkmeAudioDsp").apply { isDaemon = true } },
        ThreadPoolExecutor.DiscardOldestPolicy(),
    )

    // Controller HID output (rumble / adaptive triggers) also performs a blocking
    // bulkTransfer. On a DualSense whose audio-haptics endpoint is streaming, that
    // write can sit in the USB stack until its 1 s timeout. Running it on the
    // receive loop stalled every following frame — including the PCM stream — so it
    // gets its own writer thread. Only the latest state matters, hence DiscardOldest.
    private val controllerOutputExecutor = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(8),
        { r -> Thread(r, "GkmeHidOut").apply { isDaemon = true } },
        ThreadPoolExecutor.DiscardOldestPolicy(),
    )

    init {
        // 异步读取持久化设置，避免在主线程 runBlocking 读 DataStore 触发 ANR。
        scope.launch {
            val loaded = try {
                settingsRepository.settings.first()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // 读取失败不应卡住整个应用：退回默认值并继续，避免 settingsLoaded 永假。
                AppSettings()
            }
            _settings.value = loaded
            _settingsLoaded.value = true
            // 先让设置收集方（MainActivity 的 collect / GkViewModel 的初始化）应用加载结果，
            // 再执行这几个可能阻塞主线程的硬件/音频副作用，避免恢复用户设置被拖慢。
            yield()
            PhoneHdHaptics.enabled = loaded.hdVibrationEnabled
            GamepadInjector.configure(
                loaded.virtualGamepadNativeBackend(),
                loaded.virtualGamepadUhidProfile(),
            )
            applyEffectiveAudioSettings()
        }
        audioPlaybackService.onControllerMotorOutput = { controllerIndex, leftAmp, rightAmp ->
            onControllerVibrationRequest?.invoke(controllerIndex, leftAmp, rightAmp)
        }
        audioPlaybackService.onVoiceCoilAmplitudes = { leftAmp, rightAmp ->
            onVoiceCoilMotorOutputUpdate?.invoke(leftAmp, rightAmp)
        }
    }

    private val vibrator: Vibrator by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        // 首次加载完成前，内存/磁盘都是默认值；此时调用方拿到的 settings.value 也是
        // 默认值，写回会覆盖用户配置。直接丢弃，加载完成后各初始化逻辑会重新应用。
        if (!_settingsLoaded.value) return
        _settings.value = newSettings
        GamepadInjector.configure(
            newSettings.virtualGamepadNativeBackend(),
            newSettings.virtualGamepadUhidProfile(),
        )
        if (PhoneHdHaptics.enabled != newSettings.hdVibrationEnabled) {
            if (!newSettings.hdVibrationEnabled) {
                PhoneHdHaptics.stop()
                HdPcmStreamer.stop()
            }
            PhoneHdHaptics.enabled = newSettings.hdVibrationEnabled
        }
        applyEffectiveAudioSettings()
        stopVibrationIfDisabled()
        scope.launch {
            settingsRepository.saveSettings(newSettings)
        }
    }

    /** Called when a physical controller connects/disconnects so the audio/vibration
     *  settings switch to the matching saved set. */
    fun setPhysicalControllerConnected(connected: Boolean) {
        if (physicalControllerConnected == connected) return
        physicalControllerConnected = connected
        applyEffectiveAudioSettings()
        stopVibrationIfDisabled()
    }

    fun clearTriggerEffects() {
        triggerRumbleStopped = true
        triggerEffectStopped = true
        onTriggerEffectsRequest?.invoke(
            byteArrayOf(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00),
            byteArrayOf(0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00),
        )
    }

    private fun applyEffectiveAudioSettings() {
        val s = _settings.value
        audioPlaybackService.setSettings(
            voiceCoilDevice = s.voiceCoilDeviceFor(physicalControllerConnected),
            voiceCoilSwap = s.swapVoiceCoilMotors,
            controllerAudioDevice = s.controllerAudioDevice,
        )
    }

    private fun stopVibrationIfDisabled() {
        if (_settings.value.gameVibrationDeviceFor(physicalControllerConnected).type == VibrationDeviceType.NONE) {
            vibrator.cancel()
        }
    }

    /**
     * Switches the HID target platform while the Bluetooth service is running. The saved paired
     * device (software-level) is cleared and the HID profile is unregistered/re-registered with the
     * new descriptor — no app restart required.
     */
    fun switchTargetPlatform(platform: TargetPlatform) {
        val newSettings = _settings.value.copy(targetPlatform = platform)
        _settings.value = newSettings
        _connectionState.value = _connectionState.value.copy(
            restartToken = _connectionState.value.restartToken + 1
        )
        scope.launch {
            settingsRepository.saveSettings(newSettings)
            pairingStateRepository.clearPairedDevice()
            bluetoothService?.restart(newSettings) { outputReport -> handleBtOutputReport(outputReport) }
        }
    }

    /** 服务未运行时更新状态栏文案（例如本机模式等待 Shizuku 授权 / 授权失败）。 */
    fun setIdleStatus(text: String) {
        val st = _connectionState.value
        if (st.phase == ConnectionPhase.IDLE) {
            _connectionState.value = st.copy(statusText = text)
        }
    }

    fun startServer(scope: CoroutineScope) {
        val s = _settings.value
        activeProtocol = ActiveProtocol.NONE
        _connectionState.value = _connectionState.value.copy(statusText = "Iniciando serviço…")
        when (s.connectionMode) {
            ConnectionMode.WIFI -> {
                serverJob = scope.launch {
                    // Start both WiFi UDP and DSU servers simultaneously for auto-detection
                    startWifiServer(s)
                    startDsuServer(s)
                    watchdogJob = launch { watchdogLoop() }
                }
            }
            ConnectionMode.BLUETOOTH -> {
                startBluetooth(scope, s)
            }
            ConnectionMode.USB -> {
                serverJob = scope.launch {
                    startUsbServer()
                    watchdogJob = launch { watchdogLoop() }
                }
            }
            ConnectionMode.LOCAL -> {
                // 本机模式：虚拟手柄由 GamepadInjector（Shizuku + uinput）创建，
                // 输入直接在本机注入，不经过网络传输。
                _connectionState.value = _connectionState.value.copy(
                    connected = true,
                    phase = ConnectionPhase.CONNECTED,
                    statusText = "Os dois gamepads virtuais locais estão prontos",
                )
            }
        }
    }

    companion object {
        const val POLLING_INTERVAL_MS = 8
        const val CONNECTION_TIMEOUT_MS = 3000L
        const val EMOTION_TIMEOUT_MS = 5000L

        fun getAllLocalIpAddressesInternal(): List<String> {
            return try {
                val interfaces = java.net.NetworkInterface.getNetworkInterfaces()
                val addresses = mutableListOf<String>()
                while (interfaces.hasMoreElements()) {
                    val intf = interfaces.nextElement()
                    if (intf.isLoopback || !intf.isUp) continue
                    val addrs = intf.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        if (addr is java.net.Inet4Address) {
                            addresses.add(addr.hostAddress ?: "")
                        }
                    }
                }
                addresses
            } catch (_: Exception) { emptyList() }
        }
    }

    private suspend fun watchdogLoop() {
        while (true) {
            delay(1000)
            when (activeProtocol) {
                ActiveProtocol.WIFI -> {
                    if (udpService.pcAddress != null &&
                        System.currentTimeMillis() - udpService.lastReceiveTime > CONNECTION_TIMEOUT_MS) {
                        activeProtocol = ActiveProtocol.NONE
                        // 保留 pcAddress 用于自动重连握手，同时恢复广播让主机端可重新发现
                        udpService.resumeBroadcast()
                        startAutoReconnect()
                        _connectionState.value = _connectionState.value.copy(
                            connected = false, phase = ConnectionPhase.LISTENING,
                            statusText = "Conexão perdida; tentando reconectar…"
                        )
                    }
                }
                ActiveProtocol.EMOTION -> {
                    val dsu = dsuService
                    if (dsu != null && dsu.lastPacketTime != 0L &&
                        System.currentTimeMillis() - dsu.lastPacketTime > EMOTION_TIMEOUT_MS) {
                        activeProtocol = ActiveProtocol.NONE
                        _connectionState.value = _connectionState.value.copy(
                            connected = false, phase = ConnectionPhase.LISTENING,
                            statusText = "Conexão perdida; aguardando reconexão…"
                        )
                    }
                }
                ActiveProtocol.USB -> {
                    if (usbService.peerConnected && usbService.lastReceiveTime != 0L &&
                        System.currentTimeMillis() - usbService.lastReceiveTime > CONNECTION_TIMEOUT_MS) {
                        activeProtocol = ActiveProtocol.NONE
                        _connectionState.value = _connectionState.value.copy(
                            connected = false, phase = ConnectionPhase.LISTENING,
                            statusText = "Conexão perdida"
                        )
                    }
                }
                else -> {}
            }
        }
    }

    private suspend fun startWifiServer(settings: AppSettings) {
        try {
            val ip = getServerIp()
            if (ip.isEmpty()) {
                if (activeProtocol == ActiveProtocol.NONE) {
                    _connectionState.value = _connectionState.value.copy(
                        phase = ConnectionPhase.ERROR,
                        statusText = "Não foi possível obter o IP local"
                    )
                }
                return
            }
            udpService.start(getRealDeviceName(), getDeviceId()) { msg ->
                handleServerToClient(msg)
            }
            if (udpService.portInUse) {
                _connectionState.value = _connectionState.value.copy(
                    phase = ConnectionPhase.ERROR,
                    statusText = "A porta ${UdpService.PORT} está ocupada; talvez outra instância já esteja em execução"
                )
                return
            }
            if (activeProtocol == ActiveProtocol.NONE) {
                _connectionState.value = _connectionState.value.copy(
                    phase = ConnectionPhase.LISTENING,
                    statusText = "Serviço iniciado; aguardando conexão…"
                )
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            if (activeProtocol == ActiveProtocol.NONE) {
                _connectionState.value = _connectionState.value.copy(
                    connected = false, phase = ConnectionPhase.ERROR,
                    statusText = "Erro no serviço: ${e.message}"
                )
            }
        }
    }

    private suspend fun startDsuServer(settings: AppSettings) {
        try {
            val ip = getServerIp()
            if (ip.isEmpty()) return
            dsuService = DsuService(
                scope = scope,
                serverIp = ip,
                onRumble = { largeMotor, smallMotor ->
                    onRumbleRequest?.invoke(largeMotor, smallMotor)
                },
                onError = { msg ->
                    if (activeProtocol == ActiveProtocol.EMOTION) {
                        _connectionState.value = _connectionState.value.copy(
                            statusText = "Erro do Emotion: $msg"
                        )
                    }
                },
                onConnected = {
                    activeProtocol = ActiveProtocol.EMOTION
                    _connectionState.value = _connectionState.value.copy(
                        connected = true,
                        phase = ConnectionPhase.CONNECTED,
                        statusText = "Conectado (compatibilidade Emotion)"
                    )
                }
            )
            dsuService?.start()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private suspend fun startUsbServer() {
        val ok = usbService.start(
            onMessage = { msg -> handleUsbServerToClient(msg) },
            onPeerClosed = {
                if (activeProtocol == ActiveProtocol.USB) {
                    activeProtocol = ActiveProtocol.NONE
                    _connectionState.value = _connectionState.value.copy(
                        connected = false, phase = ConnectionPhase.LISTENING,
                        statusText = "Conexão perdida"
                    )
                }
            },
        )
        if (!ok) {
            _connectionState.value = _connectionState.value.copy(
                connected = false, phase = ConnectionPhase.ERROR,
                statusText = "A porta ${UsbService.PORT} está ocupada; talvez outra instância já esteja em execução"
            )
            return
        }
        if (activeProtocol == ActiveProtocol.NONE) {
            _connectionState.value = _connectionState.value.copy(
                phase = ConnectionPhase.LISTENING,
                statusText = "Serviço iniciado; aguardando conexão…"
            )
        }
    }

    private fun startBluetooth(scope: CoroutineScope, settings: AppSettings) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            _connectionState.value = _connectionState.value.copy(
                connected = false, statusText = "O Bluetooth HID exige Android 9 ou superior"
            )
            return
        }
        if (bluetoothService != null) return

        val transport: BluetoothHidService = ClassicHidTransport(context, pairingStateRepository)
        bluetoothService = transport

        _connectionState.value = _connectionState.value.copy(
            transportType = transport.transportType
        )

        transport.start(settings) { outputReport -> handleBtOutputReport(outputReport) }

        btPhaseJob = scope.launch {
            transport.connectionPhase.collect { phase ->
                updateBtState(phase)
            }
        }
    }

    private fun updateBtState(phase: ConnectionPhase) {
        val (connected, text) = when (phase) {
            ConnectionPhase.IDLE -> false to "Não iniciado"
            ConnectionPhase.REGISTERING_PROFILE -> false to "Registrando o perfil HID…"
            ConnectionPhase.RECONNECTING -> false to "Reconectando automaticamente aos dispositivos pareados…"
            ConnectionPhase.LISTENING -> false to "Aguardando conexão do anfitrião…"
            ConnectionPhase.DISCOVERABLE -> false to "Aguardando conexão — celular visível via Bluetooth"
            ConnectionPhase.CONNECTED -> true to "Conectado (Bluetooth)"
            ConnectionPhase.DISCONNECTED -> false to "O anfitrião desconectou"
            ConnectionPhase.ERROR -> false to "Erro de Bluetooth"
        }
        _connectionState.value = _connectionState.value.copy(
            connected = connected,
            statusText = text,
            phase = phase,
        )
    }

    private fun handleBtOutputReport(data: ByteArray) {
    }

    fun unpairDevice() {
        scope.launch {
            pairingStateRepository.clearPairedDevice()
            stopBluetooth()
            _connectionState.value = ConnectionState()
        }
    }

    fun stopServer() {
        serverJob?.cancel()
        serverJob = null
        watchdogJob?.cancel()
        watchdogJob = null
        btPhaseJob?.cancel()
        btPhaseJob = null
        stopAutoReconnect()
        udpService.stop()
        usbService.stop()
        stopBluetooth()
        dsuService?.stop()
        dsuService = null
        vibrator.cancel()
        audioPlaybackService.stop()
        activeProtocol = ActiveProtocol.NONE
        _connectionState.value = ConnectionState()
        clearTriggerEffects()
        if (_settings.value.connectionMode == ConnectionMode.LOCAL) {
            GamepadInjector.release()
        }
    }

    private fun stopBluetooth() {
        btPhaseJob?.cancel()
        btPhaseJob = null
        bluetoothService?.stop()
        bluetoothService = null
        vibrator.cancel()
    }

    private fun handleServerToClient(msg: ServerToClient) {
        // 电脑发来 Hello（或任何非断开消息）而手机尚未进入 WiFi 协议时，手机再次
        // 发送带设备名和 MAC 的 Hello 完成握手；手动输入 IP 连接时电脑端就是从
        // 这里读取设备名和 MAC。已连接后不再回应，避免与电脑的 Hello 应答形成循环。
        if (msg.payloadCase != ServerToClient.PayloadCase.DISCONNECT &&
            activeProtocol != ActiveProtocol.WIFI
        ) {
            doReconnect()
        }
        if (msg.payloadCase == ServerToClient.PayloadCase.DISCONNECT) {
            stopAutoReconnect()
            udpService.clearPcAddress()
            udpService.resumeBroadcast()
            activeProtocol = ActiveProtocol.NONE
            _connectionState.value = ConnectionState(statusText = "Desconectado")
            clearTriggerEffects()
            return
        }
        processServerToClientPayload(msg)
    }

    private fun handleUsbServerToClient(msg: ServerToClient) {
        if (msg.payloadCase != ServerToClient.PayloadCase.DISCONNECT &&
            activeProtocol != ActiveProtocol.USB
        ) {
            doUsbConnect()
        }
        if (msg.payloadCase == ServerToClient.PayloadCase.DISCONNECT) {
            activeProtocol = ActiveProtocol.NONE
            _connectionState.value = _connectionState.value.copy(
                connected = false, phase = ConnectionPhase.LISTENING,
                statusText = "Conexão perdida"
            )
            clearTriggerEffects()
            return
        }
        processServerToClientPayload(msg)
    }

    private fun processServerToClientPayload(msg: ServerToClient) {
        when (msg.payloadCase) {
            ServerToClient.PayloadCase.COMPACT_FRAME -> {
                val cf = msg.compactFrame
                val rumbleLow = if (cf.hasVibration()) cf.vibration.largeMotor.toInt() else 0
                val rumbleHigh = if (cf.hasVibration()) cf.vibration.smallMotor.toInt() else 0
                val hasVibration = cf.hasVibration() &&
                    _settings.value.gameVibrationDeviceFor(physicalControllerConnected).type != VibrationDeviceType.NONE
                // Rumble and adaptive triggers reach the pad through a blocking HID
                // bulkTransfer; keep them off the receive loop so a slow write cannot
                // hold up the rest of the stream (see controllerOutputExecutor).
                val triggerEffects = if (cf.hasTriggerEffects()) cf.triggerEffects else null
                controllerOutputExecutor.execute {
                    if (hasVibration) {
                        val active = rumbleLow != 0 || rumbleHigh != 0
                        // 仅在非 0 或由动到静时下发；持续重复的 0 不再每帧发停止指令。
                        if (active || !gameRumbleStopped) {
                            gameRumbleStopped = !active
                            onRumbleRequest?.invoke(rumbleLow, rumbleHigh)
                        }
                    }
                    triggerEffects?.let { dispatchTriggerEffects(it) }
                }
                if (cf.hasLedState()) {
                    _ledState.value = LedState(
                        color = cf.ledState.color.toInt() and 0xFFFFFF,
                        playerLed = cf.ledState.playerLed.toInt(),
                    )
                }
                if (cf.hasTestTone()) {
                    audioPlaybackService.setTestTone(cf.testTone.enabled)
                }
            }
            ServerToClient.PayloadCase.AUDIO_FRAME -> {
                val af = msg.audioFrame
                val pcm = af.pcm.toByteArray()
                logAudioFrameDiag(af.frameIndex, af.sampleCount, af.sampleRateHz.toInt(),
                    af.channels.toInt(), pcm.size)
                if (pcm.isNotEmpty()) {
                    val rate = af.sampleRateHz.toInt()
                    val ch = af.channels.toInt()
                    val bits = af.bitsPerSample.toInt()
                    audioExecutor.execute {
                        audioPlaybackService.submitAudio(pcm, rate, ch, bits)
                    }
                }
            }
            ServerToClient.PayloadCase.HD_RUMBLE -> {
                val hr = msg.hdRumble
                // Run on the audio thread so it is serialised with the PCM frames
                // and never blocks the UDP receive loop on a HID write.
                audioExecutor.execute {
                    audioPlaybackService.setHdRumble(
                        hr.leftHighFreqHz, hr.leftHighAmp, hr.leftLowFreqHz, hr.leftLowAmp,
                        hr.rightHighFreqHz, hr.rightHighAmp, hr.rightLowFreqHz, hr.rightLowAmp,
                    )
                }
            }
            ServerToClient.PayloadCase.LED_STATE -> {
                val led = msg.ledState
                _ledState.value = LedState(
                    color = led.color.toInt() and 0xFFFFFF,
                    playerLed = led.playerLed.toInt(),
                )
            }
            ServerToClient.PayloadCase.TEST_TONE -> {
                audioPlaybackService.setTestTone(msg.testTone.enabled)
            }
            ServerToClient.PayloadCase.TRIGGER_EFFECTS -> {
                val triggerEffects = msg.triggerEffects
                controllerOutputExecutor.execute { dispatchTriggerEffects(triggerEffects) }
            }
            else -> {}
        }
    }

    /** Routes a TriggerEffects payload to the adaptive-trigger (DualSense effect bytes)
     *  or the trigger-rumble (Xbox amplitudes) callback depending on which fields are set.
     *  Runs on [controllerOutputExecutor]; repeated all-zero (stopped) payloads are dropped
     *  so a PC streaming 0 values does not re-issue a stop every frame. */
    private fun dispatchTriggerEffects(te: TriggerEffects) {
        if (te.hasLeftTriggerRumble() || te.hasRightTriggerRumble()) {
            val active = te.leftTriggerRumble != 0 || te.rightTriggerRumble != 0
            if (active || !triggerRumbleStopped) {
                triggerRumbleStopped = !active
                onTriggerRumbleRequest?.invoke(te.leftTriggerRumble, te.rightTriggerRumble)
            }
        } else {
            val left = te.leftTriggerEffect.toByteArray()
            val right = te.rightTriggerEffect.toByteArray()
            val active = left.any { it != 0.toByte() } || right.any { it != 0.toByte() }
            if (active || !triggerEffectStopped) {
                triggerEffectStopped = !active
                onTriggerEffectsRequest?.invoke(left, right)
            }
        }
    }

    private var lastAudioDiagAt = 0L
    private var audioFramesSinceDiag = 0
    private var audioBytesSinceDiag = 0L
    private var lastAudioFrameIndex = -1
    private var missingAudioFrames = 0L

    private fun logAudioFrameDiag(frameIndex: Int, sampleCount: Int, rate: Int, channels: Int, bytes: Int) {
        audioFramesSinceDiag++
        audioBytesSinceDiag += bytes
        if (lastAudioFrameIndex >= 0) {
            val gap = frameIndex - lastAudioFrameIndex - 1
            if (gap in 1..10000) missingAudioFrames += gap
        }
        lastAudioFrameIndex = frameIndex
        val now = System.currentTimeMillis()
        if (lastAudioDiagAt == 0L) {
            lastAudioDiagAt = now
            return
        }
        if (now - lastAudioDiagAt < 2000) return
        val elapsed = now - lastAudioDiagAt
        android.util.Log.i(
            "GkmeAudio",
            "Audio in: ${audioFramesSinceDiag * 1000L / elapsed}/s ${audioBytesSinceDiag * 1000L / elapsed} B/s " +
                "missing=$missingAudioFrames frameIndex=$frameIndex samples=$sampleCount rate=$rate ch=$channels pcm=$bytes"
        )
        audioFramesSinceDiag = 0
        audioBytesSinceDiag = 0
        missingAudioFrames = 0
        lastAudioDiagAt = now
    }

    private fun doReconnect() {
        activeProtocol = ActiveProtocol.WIFI
        udpService.setConnected(true)
        stopAutoReconnect()
        _connectionState.value = _connectionState.value.copy(
            connected = true, phase = ConnectionPhase.CONNECTED,
            statusText = "Conectado (Wi-Fi)"
        )
        sendDeviceHello()
    }

    private fun doUsbConnect() {
        activeProtocol = ActiveProtocol.USB
        _connectionState.value = _connectionState.value.copy(
            connected = true, phase = ConnectionPhase.CONNECTED,
            statusText = "Conectado (USB)"
        )
        sendDeviceHelloUsb()
    }

    /** Sends the ClientToServer Hello carrying the device name and MAC. Sent when
     *  the PC's Hello establishes the connection (handshake) and on auto-reconnect,
     *  so the PC can learn the phone identity even for manual IP connections. */
    private fun sendDeviceHello() {
        CoroutineScope(Dispatchers.IO).launch {
            udpService.sendClientToServer(buildDeviceHello())
        }
    }

    private fun sendDeviceHelloUsb() {
        CoroutineScope(Dispatchers.IO).launch {
            usbService.sendClientToServer(buildDeviceHello())
        }
    }

    private fun buildDeviceHello(): ClientToServer {
        val hello = Hello.newBuilder()
            .setProtocolVersion(1)
            .setDeviceName(getRealDeviceName())
            .setMacAddress(getDeviceId())
            .build()
        return ClientToServer.newBuilder()
            .setHello(hello)
            .build()
    }

    private fun startAutoReconnect() {
        if (reconnectJob != null) return
        reconnectJob = scope.launch {
            while (true) {
                // 网络/IP 变化时旧 socket 不再收发，先重新绑定本地 IP 恢复通道
                udpService.refresh()
                val addr = udpService.pcAddress
                if (addr != null && activeProtocol != ActiveProtocol.WIFI) {
                    sendDeviceHello()
                }
                delay(2000)
            }
        }
    }

    private fun stopAutoReconnect() {
        reconnectJob?.cancel()
        reconnectJob = null
    }

    var onRumbleRequest: ((largeMotor: Int, smallMotor: Int) -> Unit)? = null
    var onControllerVibrationRequest: ((controllerIndex: Int, leftAmp: Int, rightAmp: Int) -> Unit)? = null
    var onVoiceCoilMotorOutputUpdate: ((leftAmp: Int, rightAmp: Int) -> Unit)? = null
    var onTriggerEffectsRequest: ((left: ByteArray?, right: ByteArray?) -> Unit)? = null
    var onTriggerRumbleRequest: ((left: Int, right: Int) -> Unit)? = null

    // PC 无震动时仍会每帧下发 0 值。这里缓存每条震动通路的“已停止”状态，只在由动到静
    // （下落沿）时下发一次停止，之后重复的 0 直接丢弃，避免每帧都重复发停止指令。非 0 值
    // 仍每帧下发，保留各后端既有的保活/刷新行为。主要由 controllerOutputExecutor 单线程访问。
    @Volatile
    private var gameRumbleStopped = true

    @Volatile
    private var triggerRumbleStopped = true

    @Volatile
    private var triggerEffectStopped = true

    suspend fun sendGamepadState(state: GamepadInput) {
        when (_settings.value.connectionMode) {
            ConnectionMode.WIFI -> {
                when (activeProtocol) {
                    ActiveProtocol.EMOTION -> {
                        val gs = GamepadState(
                            buttons = state.buttons.toUInt(),
                            leftStickX = state.leftStickX.toShort(),
                            leftStickY = state.leftStickY.toShort(),
                            rightStickX = state.rightStickX.toShort(),
                            rightStickY = state.rightStickY.toShort(),
                            leftTrigger = state.leftTrigger,
                            rightTrigger = state.rightTrigger,
                            dpad = state.dpad,
                            gyroX = state.gyroX,
                            gyroY = state.gyroY,
                            gyroZ = state.gyroZ,
                            accelX = state.accelX,
                            accelY = state.accelY,
                            accelZ = state.accelZ,
                            batteryLevel = state.batteryLevel,
                            isCharging = state.isCharging,
                            touches = state.touchesList.map { tp ->
                                com.zyz4.gkme.model.TouchPoint(
                                    id = tp.id, x = tp.x, y = tp.y, active = tp.active
                                )
                            }
                        )
                        dsuService?.updateGamepadState(gs)
                    }
                    else -> {
                        if (activeProtocol != ActiveProtocol.WIFI) return
                        if (udpService.pcAddress == null) return
                        if (state.pressedScanCodesCount > 0 || state.keyboardModifiers != 0) {
                            android.util.Log.d("ConnectionManager", "sendGamepadState: keyboard pressed=${state.pressedScanCodesList}, mod=${state.keyboardModifiers}")
                        }
                        udpService.sendGamepadInput(state)
                    }
                }
            }
            ConnectionMode.BLUETOOTH -> {
                val phase = _connectionState.value.phase
                if (phase != ConnectionPhase.CONNECTED) return
                val target = _settings.value.targetPlatform
                if (target == TargetPlatform.UNIVERSAL_KM) return
                val report = GamepadStateMapper.map(state, target)
                bluetoothService?.sendReport(report)
            }
            ConnectionMode.USB -> {
                if (activeProtocol != ActiveProtocol.USB) return
                if (!usbService.peerConnected) return
                usbService.sendGamepadInput(state)
            }
            ConnectionMode.LOCAL -> {
                if (GamepadInjector.isReady()) GamepadInjector.update(state)
            }
        }
    }

    /** Send a mouse report for WiFi/UDP or USB mode. */
    fun sendMouseReport(
        button: Byte, dx: Short, dy: Short, wheel: Short, hWheel: Short = 0
    ) {
        when (_settings.value.connectionMode) {
            ConnectionMode.BLUETOOTH -> {
                val phase = _connectionState.value.phase
                if (phase != ConnectionPhase.CONNECTED) return
                var btn = button.toInt()
                if (btn == 0 && (dx != 0.toShort() || dy != 0.toShort())) {
                    btn = _lastMouseButtonsBt
                } else {
                    _lastMouseButtonsBt = btn
                }
                bluetoothService?.sendMouseReport(btn.toByte(), dx, dy, wheel, hWheel)
            }
            ConnectionMode.WIFI -> {
                // 鼠标数据不再走独立 UDP 包，而是写入 ViewModel 的 _gamepadState。
                // 普通手柄循环包（每 ~10ms）自动带上最新的鼠标字段，合并为一个包。
                if (activeProtocol != ActiveProtocol.WIFI) return
                onMouseReport?.invoke(
                    button.toInt(), dx.toInt(), dy.toInt(), wheel.toInt(), hWheel.toInt()
                )
            }
            ConnectionMode.USB -> {
                if (activeProtocol != ActiveProtocol.USB) return
                onMouseReport?.invoke(
                    button.toInt(), dx.toInt(), dy.toInt(), wheel.toInt(), hWheel.toInt()
                )
            }
            // 本机模式不创建虚拟鼠标（会与屏幕触摸冲突），鼠标状态不注入。
            ConnectionMode.LOCAL -> {}
        }
    }

    fun sendKeyboardReport(modifier: Byte, keys: ByteArray) {
        when (_settings.value.connectionMode) {
            ConnectionMode.BLUETOOTH -> {
                val phase = _connectionState.value.phase
                if (phase != ConnectionPhase.CONNECTED) return
                bluetoothService?.sendKeyboardReport(modifier, keys)
            }
            ConnectionMode.WIFI -> {
                if (activeProtocol != ActiveProtocol.WIFI) return
                scope.launch {
                    udpService.sendKeyboardReport(modifier, keys)
                }
            }
            // USB carries the keyboard inside the regular GamepadInput frame
            // (see GkViewModel); no separate HID report is needed.
            ConnectionMode.USB -> {}
            // LOCAL also carries the keyboard inside the GamepadInput frame.
            ConnectionMode.LOCAL -> {}
        }
    }

    private fun getRealDeviceName(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            Settings.Global.getString(context.contentResolver, Settings.Global.DEVICE_NAME)
                ?: Build.MODEL
        } else {
            @Suppress("DEPRECATION")
            android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.name ?: Build.MODEL
        }
    }

    /** Stable identity of the physical phone, broadcast to the PC. Despite the
     *  protocol field being named the "MAC" (`Hello.mac_address` / `GKME|name|mac`),
     *  it actually carries ANDROID_ID, which survives reboots and app updates and
     *  is unique per app-signing-key + user. Renamed from `getMacAddress` to avoid
     *  the false implication of a real hardware MAC. */
    fun getDeviceId(): String {
        return try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?.uppercase()
                ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    fun getServerIp(): String {
        return getAllLocalIpAddresses().firstOrNull() ?: ""
    }

    fun getAllLocalIpAddresses(): List<String> {
        return getAllLocalIpAddressesInternal()
    }
}
