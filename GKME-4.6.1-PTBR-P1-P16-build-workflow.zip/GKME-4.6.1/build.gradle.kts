plugins {
    id("com.android.application") version "9.4.1" apply false
    id("com.google.dagger.hilt.android") version "2.60.1" apply false
    id("com.google.protobuf") version "0.10.0" apply false
    id("com.google.devtools.ksp") version "2.3.11" apply false
}
