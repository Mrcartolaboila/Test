# GKME — Gamepad, teclado e mouse para Android

Esta versão modificada tenta oferecer **dois gamepads virtuais locais independentes**: a entrada recebida pelo aplicativo é enviada para P1 e P2 no mesmo celular. O modo local exige Shizuku e acesso permitido a `/dev/uinput` ou `/dev/uhid`.

> **Estado da modificação:** o código foi alterado para criar dois dispositivos no modo local, mas não foi possível compilar nem testar em um aparelho Android neste ambiente. A compatibilidade depende do firmware, das permissões do Shizuku/SELinux e do jogo. Não considere o APK pronto até compilar e testar.

## Recursos do projeto original

- Controle virtual pelo navegador.
- Entrada por toque, sensores e controles físicos Bluetooth/USB compatíveis.
- Modos Wi-Fi, USB/ADB, Bluetooth HID e modo local com Shizuku.
- Saída de gamepad virtual por `uinput` ou `uhid`.
- Suporte a teclado e mouse virtuais no modo receptor.

## Alteração desta versão

- O modo **Local (Shizuku)** solicita a criação de dois gamepads virtuais separados (P1 e P2).
- Os estados de botões, D-pad, analógicos e gatilhos são enviados para os dois dispositivos.
- Os demais modos continuam criando apenas um gamepad virtual por padrão.
- Algumas mensagens e textos visíveis foram traduzidos para português brasileiro. A tradução ainda não cobre absolutamente todas as telas e comentários do projeto original.

## Requisitos de compilação

- Android Studio recente.
- JDK 17 ou 21 compatível com o Gradle do projeto.
- Android SDK Platform e Build Tools exigidos pelo `android/build.gradle.kts`.
- Android NDK e CMake, necessários para as bibliotecas nativas.
- Para testar o modo local: Shizuku iniciado, autorização concedida e acesso do processo `shell` a `/dev/uinput` ou `/dev/uhid`.

### Compilar

No Linux/macOS:

```bash
./gradlew :android:assembleDebug
```

No Windows:

```bat
gradlew.bat :android:assembleDebug
```

O APK de depuração deverá ser gerado em `android/build/outputs/apk/debug/`, caso a compilação termine sem erros.

## Como testar P1 + P2

1. Instale o APK compilado.
2. Instale e inicie o Shizuku.
3. Conceda ao GKME a autorização solicitada.
4. Conecte o controle Bluetooth às configurações do Android.
5. No GKME, selecione **Modo local (Shizuku)** e inicie o serviço.
6. Confira nas ferramentas de diagnóstico do Android se aparecem dois dispositivos de gamepad e teste num jogo compatível com múltiplos controles.

## Limitações importantes

- O Android pode bloquear `uinput`/`uhid` por permissões ou SELinux, mesmo com Shizuku autorizado.
- Dois dispositivos de entrada separados não garantem que todo jogo Android atribua P1 e P2 corretamente.
- Esta alteração não cria dois periféricos Bluetooth HID simultâneos. O modo Bluetooth HID original serve para apresentar o celular como um controle a outro dispositivo; criar um segundo perfil Bluetooth independente exige uma implementação diferente e suporte do Android.
- O código foi modificado, mas não foi compilado nem testado em hardware nesta sessão.

## Código-fonte original

Projeto GKME: https://github.com/4zyz4/GKME

Licença: consulte o arquivo `LICENSE` e preserve os avisos de copyright do projeto original.
