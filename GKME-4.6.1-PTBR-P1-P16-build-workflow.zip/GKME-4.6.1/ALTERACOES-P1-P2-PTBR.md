# Alterações da versão P1 + P2 / PT-BR

## Implementado no código-fonte

- No modo local com Shizuku, `GamepadInjector.ensureReady` pede dois dispositivos virtuais.
- O serviço cria um segundo FD nativo usando o mesmo backend (`uinput` ou `uhid`).
- Cada atualização de estado é enviada para os dois dispositivos: botões, eixos dos analógicos, D-pad e gatilhos.
- Se a criação do segundo dispositivo falhar, o primeiro é destruído e o erro é retornado; isso evita deixar um P1 órfão.
- No backend `uinput`, os nomes dos dispositivos são diferenciados como P1 e P2.
- Os modos que não solicitam espelhamento continuam com um único gamepad virtual.
- Foram traduzidos para PT-BR o README e diversos textos visíveis da tela principal, configurações e controle web.

## Compilação

Execute na raiz do projeto:

```bash
./gradlew :android:assembleDebug
```

No Windows:

```bat
gradlew.bat :android:assembleDebug
```

## Verificação feita nesta sessão

- O código C de `uinput_gamepad.c` passou na verificação de sintaxe do compilador host (`gcc -fsyntax-only`).
- A compilação Android completa não foi concluída porque o Gradle Wrapper precisa baixar Gradle de `mirrors.aliyun.com`, e este ambiente não tem acesso de rede DNS a esse host.
- Não foi possível testar os dois dispositivos em um aparelho Android físico.

## Limitações que permanecem

- Esta é uma alteração de código-fonte, não um APK já compilado.
- A tradução PT-BR é parcial; algumas telas e mensagens internas ainda podem estar em chinês.
- O modo local tenta criar dois dispositivos de entrada Android. O sucesso depende de Shizuku, permissões de `/dev/uinput`/`/dev/uhid`, SELinux e suporte do firmware.
- A criação de dois dispositivos virtuais locais não significa que todos os jogos vão atribuir P1 e P2 automaticamente.
- O modo Bluetooth HID original continua expondo um controle Bluetooth para outro dispositivo. Este patch não cria dois periféricos Bluetooth HID simultâneos.
